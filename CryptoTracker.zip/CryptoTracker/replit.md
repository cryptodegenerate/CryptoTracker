# Solana Memecoin Telegram Bot

## Overview

This is a full-stack Solana memecoin auto-trading bot that discovers promising new tokens and automatically executes trades via Jupiter. The system combines token discovery, Telegram posting, and automated trading with a React frontend dashboard. It includes comprehensive risk management, position tracking, and performance monitoring.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript and Vite for development
- **UI Library**: Radix UI components with Tailwind CSS for styling
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Design System**: shadcn/ui component library with "new-york" style

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Bot Integration**: node-telegram-bot-api for Telegram interactions
- **Process Management**: Singleton lock system to prevent duplicate instances

### Database Architecture
- **ORM**: Drizzle with PostgreSQL driver
- **Schema Management**: Centralized schema definitions in `shared/schema.ts`
- **Connection**: Neon Database serverless PostgreSQL

## Key Components

### 1. Token Discovery System
- **Multi-source Discovery**: Integrates with Pump.fun, Birdeye, and DexScreener APIs
- **Duplicate Prevention**: Robust filtering to prevent posting the same token multiple times
- **Quality Classification**: Risk-based token classification (green/yellow/red) with scoring
- **Safety Filters**: Comprehensive safety checks including liquidity locks, mint authority, and holder distribution

### 2. Auto-Trading System
- **Jupiter Integration**: Executes trades automatically via Jupiter's swap API
- **Risk Management**: Configurable stop-loss and take-profit levels
- **Position Tracking**: Real-time monitoring of active positions
- **Portfolio Management**: Limits concurrent positions and investment amounts per token

### 3. Telegram Bot Service
- **Singleton Pattern**: Ensures single bot instance with proper connection management
- **Auto-configuration**: Automatically initializes with predefined settings
- **Message Formatting**: Rich token information formatting with risk indicators
- **Error Handling**: Robust error handling with automatic reconnection

### 3. Posting Management
- **Multiple Posting Services**: File-based, persistent, and bulletproof posting strategies
- **Queue Management**: Token queuing system with timing controls
- **State Persistence**: File-based and database state management
- **Rate Limiting**: Configurable posting intervals to avoid spam

### 4. Monitoring & Health
- **Health Monitoring**: System health checks with automatic recovery
- **Activity Logging**: Comprehensive logging of all bot activities
- **Performance Tracking**: Token performance monitoring and leaderboards
- **Process Recovery**: Automatic restart mechanisms for reliability

## Data Flow

1. **Token Discovery**: 
   - Monitoring service queries multiple APIs for new tokens
   - Applies safety filters and quality classification
   - Stores qualified tokens in database/file queue

2. **Token Processing**:
   - Posting service retrieves queued tokens
   - Formats token information with risk indicators
   - Posts to configured Telegram channel

3. **Performance Tracking**:
   - Monitors posted tokens for price performance
   - Updates leaderboard with gains/losses
   - Tracks user achievements and rankings

4. **State Management**:
   - Maintains posting state across restarts
   - Prevents duplicate posts through persistent storage
   - Handles graceful shutdowns and recoveries

## External Dependencies

### APIs & Services
- **Pump.fun API**: Primary token discovery source
- **Birdeye API**: Token metrics and pricing data
- **DexScreener API**: Additional token information
- **Jupiter Token List**: Token validation and metadata
- **Telegram Bot API**: Message posting and channel management

### Database & Storage
- **Neon Database**: Serverless PostgreSQL for production
- **Local File Storage**: Backup state management
- **Session Storage**: Temporary state during operations

### Development Tools
- **Vite**: Development server and build tool
- **Drizzle Kit**: Database schema management
- **ESBuild**: Production bundling
- **TypeScript**: Type checking and compilation

## Deployment Strategy

### Development Environment
- **Replit Integration**: Configured for Replit development environment
- **Hot Reloading**: Vite development server with HMR
- **Database Migrations**: Automatic schema synchronization
- **Environment Variables**: Secure token and configuration management

### Production Deployment
- **Autoscale Target**: Configured for Replit autoscale deployment
- **Build Process**: Vite frontend build + ESBuild backend bundle
- **Port Configuration**: Port 5000 internal, port 80 external
- **Process Management**: Automatic restart and monitoring

### Configuration Management
- **Auto-configuration**: Predefined bot settings for immediate operation
- **Environment-based**: Different configurations for development/production
- **Secret Management**: Secure handling of API keys and tokens
- **Runtime Updates**: Dynamic configuration updates without restart

## Changelog

```
Changelog:
- June 24, 2025. Initial setup
- June 24, 2025. Added memecoin auto-trading with Jupiter integration
- June 24, 2025. Implemented position tracking and risk management
- June 24, 2025. Created trading dashboard interface
- June 24, 2025. Added multiple token discovery sources with fallback system
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```