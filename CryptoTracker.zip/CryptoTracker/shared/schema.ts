import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const botConfigurations = pgTable("bot_configurations", {
  id: serial("id").primaryKey(),
  telegramToken: text("telegram_token").notNull(),
  channelId: text("channel_id").notNull(),
  monitoringInterval: integer("monitoring_interval").notNull().default(5),
  maxTokens: integer("max_tokens").notNull().default(10),
  isActive: boolean("is_active").notNull().default(false),
  // Safety filter configuration
  minLiquidity: integer("min_liquidity").notNull().default(100000), // $100K default
  requireLiquidityLocked: boolean("require_liquidity_locked").notNull().default(true),
  requireMintRevoked: boolean("require_mint_revoked").notNull().default(true),
  requireFreezeRevoked: boolean("require_freeze_revoked").notNull().default(true),
  maxTopHolderPercent: integer("max_top_holder_percent").notNull().default(10),
  minHolders: integer("min_holders").notNull().default(300),
  minDailyVolume: integer("min_daily_volume").notNull().default(10000), // $10K
  minTokenAge: integer("min_token_age").notNull().default(10), // minutes
  maxTokenAge: integer("max_token_age").notNull().default(360), // 6 hours
  minTwitterFollowers: integer("min_twitter_followers").notNull().default(100),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'token_post', 'manual_post', 'config_update', 'bot_start', 'bot_stop'
  message: text("message").notNull(),
  status: text("status").notNull(), // 'success', 'error'
  details: text("details"), // JSON string for additional data
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const tokenPosts = pgTable("token_posts", {
  id: serial("id").primaryKey(),
  tokenAddress: text("token_address").notNull().unique(),
  tokenName: text("token_name").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  liquidity: text("liquidity").notNull(),
  price: text("price").notNull(),
  classification: text("classification").notNull().default("yellow"), // 'green', 'yellow', 'red'
  riskScore: integer("risk_score").notNull().default(50), // 1-100 scale
  qualityMetrics: text("quality_metrics"), // JSON string with detailed metrics
  ageInHours: integer("age_in_hours"), // Token age in hours
  posted: boolean("posted").notNull().default(false),
  postedAt: timestamp("posted_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botStats = pgTable("bot_stats", {
  id: serial("id").primaryKey(),
  totalPosts: integer("total_posts").notNull().default(0),
  todayPosts: integer("today_posts").notNull().default(0),
  weekPosts: integer("week_posts").notNull().default(0),
  successRate: text("success_rate").notNull().default("0"), // stored as string for decimal precision
  avgResponseTime: text("avg_response_time").notNull().default("0s"),
  uptime: text("uptime").notNull().default("0"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const leaderboardEntries = pgTable("leaderboard_entries", {
  id: serial("id").primaryKey(),
  tokenAddress: text("token_address").notNull().unique(),
  tokenName: text("token_name").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  initialPrice: text("initial_price").notNull(),
  currentPrice: text("current_price").notNull(),
  priceChange24h: text("price_change_24h").notNull().default("0"),
  priceChangePercent: text("price_change_percent").notNull().default("0"),
  marketCap: text("market_cap").notNull().default("0"),
  volume24h: text("volume_24h").notNull().default("0"),
  liquidityUsd: text("liquidity_usd").notNull().default("0"),
  holders: integer("holders").notNull().default(0),
  // Performance metrics
  performance1h: text("performance_1h").notNull().default("0"),
  performance24h: text("performance_24h").notNull().default("0"),
  performance7d: text("performance_7d").notNull().default("0"),
  performanceScore: integer("performance_score").notNull().default(0), // 0-1000 scale
  // Gamification elements
  rank: integer("rank").notNull().default(0),
  tier: text("tier").notNull().default("bronze"), // bronze, silver, gold, diamond, legendary
  streak: integer("streak").notNull().default(0), // consecutive days of positive performance
  badges: text("badges").notNull().default("[]"), // JSON array of achievement badges
  discoveryPoints: integer("discovery_points").notNull().default(0), // points for early discovery
  riskCategory: text("risk_category").notNull().default("medium"), // low, medium, high
  safetyScore: integer("safety_score").notNull().default(50), // 0-100 safety rating
  communityScore: integer("community_score").notNull().default(0), // social engagement score
  tradingActivity: text("trading_activity").notNull().default("low"), // low, medium, high, extreme
  volatilityIndex: text("volatility_index").notNull().default("0"), // price volatility measure
  momentumScore: integer("momentum_score").notNull().default(0), // price momentum indicator
  qualityRating: text("quality_rating").notNull().default("C"), // A+, A, B, C, D, F rating
  trendDirection: text("trend_direction").notNull().default("neutral"), // bullish, bearish, neutral
  socialSentiment: text("social_sentiment").notNull().default("neutral"), // positive, negative, neutral
  whaleActivity: boolean("whale_activity").notNull().default(false), // large holder movements
  devActivity: boolean("dev_activity").notNull().default(false), // developer engagement
  firstSeenAt: timestamp("first_seen_at").notNull().defaultNow(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const userScores = pgTable("user_scores", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(), // telegram user ID or session ID
  username: text("username"),
  totalPoints: integer("total_points").notNull().default(0),
  level: integer("level").notNull().default(1),
  streak: integer("streak").notNull().default(0),
  badges: text("badges").notNull().default("[]"), // JSON array of earned badges
  tokensDiscovered: integer("tokens_discovered").notNull().default(0),
  successfulPicks: integer("successful_picks").notNull().default(0),
  accuracyRate: text("accuracy_rate").notNull().default("0"),
  bestPerformance: text("best_performance").notNull().default("0"),
  rank: integer("rank").notNull().default(0),
  tier: text("tier").notNull().default("bronze"),
  achievements: text("achievements").notNull().default("[]"), // JSON array of achievements
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
  lastActive: timestamp("last_active").notNull().defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  icon: text("icon").notNull(), // emoji or icon name
  category: text("category").notNull(), // discovery, performance, streak, social, etc.
  requirement: text("requirement").notNull(), // condition to unlock
  points: integer("points").notNull().default(0),
  rarity: text("rarity").notNull().default("common"), // common, rare, epic, legendary
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const postingState = pgTable("posting_state", {
  id: serial("id").primaryKey(),
  lastPostTime: timestamp("last_post_time").notNull().defaultNow(),
  isActive: boolean("is_active").notNull().default(true),
  postDelay: integer("post_delay").notNull().default(45000), // 45 seconds in ms
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertBotConfigurationSchema = createInsertSchema(botConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

export const insertTokenPostSchema = createInsertSchema(tokenPosts).omit({
  id: true,
  posted: true,
  postedAt: true,
  createdAt: true,
}).extend({
  classification: z.enum(["green", "yellow", "red"]).default("yellow"),
  riskScore: z.number().min(1).max(100).default(50),
});

export const insertBotStatsSchema = createInsertSchema(botStats).omit({
  id: true,
  lastUpdated: true,
});

export const insertLeaderboardEntrySchema = createInsertSchema(leaderboardEntries).omit({
  id: true,
  firstSeenAt: true,
  lastUpdated: true,
}).extend({
  tier: z.enum(["bronze", "silver", "gold", "diamond", "legendary"]).default("bronze"),
  riskCategory: z.enum(["low", "medium", "high"]).default("medium"),
  tradingActivity: z.enum(["low", "medium", "high", "extreme"]).default("low"),
  qualityRating: z.enum(["A+", "A", "B", "C", "D", "F"]).default("C"),
  trendDirection: z.enum(["bullish", "bearish", "neutral"]).default("neutral"),
  socialSentiment: z.enum(["positive", "negative", "neutral"]).default("neutral"),
});

export const insertUserScoreSchema = createInsertSchema(userScores).omit({
  id: true,
  joinedAt: true,
  lastActive: true,
}).extend({
  tier: z.enum(["bronze", "silver", "gold", "diamond", "legendary"]).default("bronze"),
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  createdAt: true,
}).extend({
  category: z.enum(["discovery", "performance", "streak", "social", "trading", "community"]).default("discovery"),
  rarity: z.enum(["common", "rare", "epic", "legendary"]).default("common"),
});

export const insertPostingStateSchema = createInsertSchema(postingState).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type BotConfiguration = typeof botConfigurations.$inferSelect;
export type InsertBotConfiguration = z.infer<typeof insertBotConfigurationSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type TokenPost = typeof tokenPosts.$inferSelect;
export type InsertTokenPost = z.infer<typeof insertTokenPostSchema>;
export type BotStats = typeof botStats.$inferSelect;
export type InsertBotStats = z.infer<typeof insertBotStatsSchema>;
export type LeaderboardEntry = typeof leaderboardEntries.$inferSelect;
export type InsertLeaderboardEntry = z.infer<typeof insertLeaderboardEntrySchema>;
export type UserScore = typeof userScores.$inferSelect;
export type InsertUserScore = z.infer<typeof insertUserScoreSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type PostingState = typeof postingState.$inferSelect;
export type InsertPostingState = z.infer<typeof insertPostingStateSchema>;
