import axios from 'axios';
import { storage } from './storage.js';
import { telegramService } from './telegram-singleton.js';

export interface PumpFunToken {
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  liquidity: number;
  price: number;
  marketCap?: number;
  volume24h?: number;
  holders?: number;
  createdAt?: string;
  liquidityLocked?: boolean;
  mintAuthorityRevoked?: boolean;
  freezeAuthorityRevoked?: boolean;
  topHolderPercentage?: number;
  tokenAge?: number;
  twitterFollowers?: number;
  telegramMembers?: number;
  hasGoodBranding?: boolean;
  trendIndicator?: string;
  socialScore?: number;
  communityStrength?: string;
  geographicRegion?: string;
  sentimentScore?: number;
}

export interface TokenClassification {
  classification: "green" | "yellow" | "red";
  riskScore: number;
  qualityMetrics: {
    liquidityScore: number;
    marketCapScore: number;
    volumeScore: number;
    nameQualityScore: number;
    overallScore: number;
    reasons: string[];
  };
}

export class MonitoringService {
  private isRunning = false;
  private intervalId: NodeJS.Timeout | null = null;
  private postIntervalId: NodeJS.Timeout | null = null;
  private promoIntervalId: NodeJS.Timeout | null = null;
  private lastCheckTime = new Date();
  private lastBirdeyeCall = 0;
  private birdeyeCallCount = 0;
  private tokenQueue: Array<{token: PumpFunToken, classification: TokenClassification, discoveryTime: Date}> = [];
  private lastPostTime = 0;
  private postingActive = false;
  private performanceTracker = new Map<string, {initialPrice: number, postedAt: Date, highestPrice?: number, currentPrice?: number}>();
  private adaptivePostingInterval = 60000; // Start with 1 minute
  private highActivityThreshold = 5; // tokens per discovery cycle
  private priceAlertThresholds = [50, 100, 200, 500]; // percentage gains to alert on
  private lastPromoTime = 0;

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('Monitoring service already running');
      return;
    }

    console.log('Starting Solana token monitoring service...');
    this.isRunning = true;
    this.lastCheckTime = new Date();

    await storage.createActivityLog({
      type: 'bot_start',
      message: 'Token monitoring service started successfully',
      status: 'success'
    });

    // Start the discovery, posting, and promotional cycles
    await this.checkForNewTokens();
    this.startPostingCycle();
    this.startPromotionalCycle();
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      console.log('Monitoring service not running');
      return;
    }

    console.log('Stopping monitoring service...');
    this.isRunning = false;

    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }

    if (this.postIntervalId) {
      clearTimeout(this.postIntervalId);
      this.postIntervalId = null;
    }

    if (this.promoIntervalId) {
      clearTimeout(this.promoIntervalId);
      this.promoIntervalId = null;
    }

    this.postingActive = false;
    this.tokenQueue = [];

    await storage.createActivityLog({
      type: 'bot_stop',
      message: 'Token monitoring service stopped',
      status: 'success'
    });
  }

  async manualCheck(): Promise<void> {
    console.log('Manual token search initiated...');
    this.lastCheckTime = new Date();

    await storage.createActivityLog({
      type: 'manual_search',
      message: 'Manual token search initiated',
      status: 'success'
    });

    await this.checkForNewTokens();
  }

  async checkForNewTokens(): Promise<void> {
    if (!this.isRunning) return;

    try {
      console.log('Scanning for authentic newly created tokens...');
      
      // Get bot configuration
      const config = await storage.getBotConfiguration();
      if (!config || !config.isActive) {
        console.log('Bot configuration inactive');
        return;
      }

      // Fetch tokens from multiple authentic sources
      const tokens = await this.fetchNewTokens(config.maxTokens || 5);
      console.log(`Processing ${tokens.length} tokens with authentic creation times`);

      let processedCount = 0;
      let postedCount = 0;

      for (const token of tokens) {
        try {
          console.log(`Processing token: ${token.tokenSymbol} - ${token.tokenName}`);

          // Check if already posted or in queue
          const existingPost = await storage.getTokenPost(token.tokenAddress);
          if (existingPost?.posted) {
            console.log(`Token ${token.tokenSymbol} already posted - skipping`);
            continue;
          }
          
          // Check if already in posting queue
          const inQueue = this.tokenQueue.some(queueItem => 
            queueItem.token.tokenAddress === token.tokenAddress
          );
          if (inQueue) {
            console.log(`Token ${token.tokenSymbol} already in posting queue - skipping`);
            continue;
          }

          // Apply safety filters
          const safetyCheck = await this.applySafetyFilters(token, config);
          if (!safetyCheck.passed) {
            console.log(`Token ${token.tokenSymbol} failed safety filters: ${safetyCheck.reasons.join(', ')}`);
            
            // Post rejected token with explanation
            await this.postRejectedToken(token, safetyCheck.reasons, config);
            continue;
          }

          // Classify token quality
          const classification = await this.classifyToken(token, config);
          
          // Store token data
          await storage.createTokenPost({
            tokenAddress: token.tokenAddress,
            tokenName: token.tokenName,
            tokenSymbol: token.tokenSymbol,
            liquidity: token.liquidity.toString(),
            price: token.price.toString(),
            classification: classification.classification,
            riskScore: classification.riskScore,
            qualityMetrics: JSON.stringify(classification.qualityMetrics)
          });

          // Enhance token with additional analytics
          const enhancedToken = await this.enhanceTokenData(token);
          
          // Add to posting queue with discovery time
          this.tokenQueue.push({ 
            token: enhancedToken, 
            classification, 
            discoveryTime: new Date() 
          });
          console.log(`📋 Added ${token.tokenSymbol} to posting queue (${this.tokenQueue.length} pending)`);

          processedCount++;
        } catch (tokenError) {
          console.log(`Error processing token ${token.tokenSymbol}:`, (tokenError as Error).message);
        }
      }

      // Implement adaptive posting frequency based on discovery volume
      this.adjustPostingFrequency(processedCount);

      await storage.createActivityLog({
        type: 'tokens_processed',
        message: `Processed ${processedCount} tokens, queued for intelligent posting`,
        status: 'success'
      });

    } catch (error) {
      console.log('Error in token monitoring:', (error as Error).message);
      await storage.createActivityLog({
        type: 'monitoring_error',
        message: `Token monitoring error: ${(error as Error).message}`,
        status: 'error'
      });
    }
  }

  private async fetchNewTokens(maxTokens: number): Promise<PumpFunToken[]> {
    console.log('Fetching from multiple API sources...');
    const tokens: PumpFunToken[] = [];
    const sources = ['Birdeye', 'CoinGecko', 'Jupiter'];
    
    // Parallel fetch from multiple sources for better coverage
    const fetchPromises = [
      this.fetchBirdeyeTokens().catch((err: Error) => {
        console.log('Birdeye fetch failed:', err.message);
        return [];
      }),
      this.fetchCoinGeckoTokens().catch((err: Error) => {
        console.log('CoinGecko fetch failed:', err.message);
        return [];
      }),
      this.fetchJupiterTokens().catch((err: Error) => {
        console.log('Jupiter fetch failed:', err.message);
        return [];
      })
    ];

    const results = await Promise.all(fetchPromises);
    
    // Combine results from all sources
    results.forEach((sourceTokens: PumpFunToken[], index: number) => {
      console.log(`${sources[index]} found ${sourceTokens.length} tokens`);
      tokens.push(...sourceTokens);
    });

    // Remove duplicates based on token address
    const uniqueTokens = tokens.filter((token, index, self) => 
      index === self.findIndex(t => t.tokenAddress === token.tokenAddress)
    );

    console.log(`Total unique tokens found: ${uniqueTokens.length}`);
    return uniqueTokens.slice(0, maxTokens);
  }

  private async fetchBirdeyeTokens(): Promise<PumpFunToken[]> {
    const birdeyeApiKey = process.env.BIRDEYE_API_KEY;
    if (!birdeyeApiKey) {
      console.log('Birdeye API key not configured');
      return [];
    }

    console.log('Fetching authentic new tokens from Birdeye...');

    const response = await axios.get('https://public-api.birdeye.so/defi/tokenlist', {
      params: {
        sort_by: 'v24hUSD',
        sort_type: 'desc',
        offset: 30,
        limit: 20,
        min_liquidity: 50000
      },
      timeout: 15000,
      headers: {
        'X-API-KEY': birdeyeApiKey,
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (response.data?.data?.tokens) {
      const validTokens = response.data.data.tokens
        .filter((token: any) => 
          token.symbol &&
          token.name &&
          token.address &&
          token.mc > 100000 &&
          token.mc < 8000000 &&
          token.liquidity > 50000 &&
          token.symbol.length <= 10 &&
          !['SOL', 'USDC', 'USDT', 'TRUMP', 'BONK'].includes(token.symbol.toUpperCase())
        )
        .slice(0, 5);

      console.log(`Birdeye found ${validTokens.length} quality tokens`);

      return validTokens.map((token: any) => ({
        tokenAddress: token.address,
        tokenName: token.name,
        tokenSymbol: token.symbol.toUpperCase(),
        liquidity: token.liquidity,
        price: token.price,
        marketCap: token.mc,
        volume24h: token.v24hUSD || 0,
        createdAt: new Date().toISOString()
      }));
    }

    return [];
  }

  private async fetchCoinGeckoTokens(): Promise<PumpFunToken[]> {
    const coinGeckoApiKey = process.env.COINGECKO_API_KEY;
    if (!coinGeckoApiKey) {
      console.log('CoinGecko API key not configured');
      return [];
    }

    try {
      // Use the free API endpoint for better compatibility
      const response = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
        params: {
          vs_currency: 'usd',
          order: 'volume_desc',
          per_page: 100,
          page: 1,
          sparkline: false
        },
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.data || !Array.isArray(response.data)) {
        return [];
      }

      const tokens: PumpFunToken[] = [];
      
      // Filter for tokens with recent activity and reasonable market metrics
      const activeTokens = response.data.filter(token => {
        const hasVolume = token.total_volume && token.total_volume > 100000;
        const hasMarketCap = token.market_cap && token.market_cap < 50000000;
        const hasValidPrice = token.current_price && token.current_price > 0;
        const hasSymbol = token.symbol && token.symbol.length <= 10;
        return hasVolume && hasMarketCap && hasValidPrice && hasSymbol;
      });

      // Focus on tokens with strong trading activity
      const sortedTokens = activeTokens.sort((a, b) => (b.total_volume || 0) - (a.total_volume || 0));

      for (const token of sortedTokens.slice(0, 10)) {
        if (token.id && token.symbol && token.name) {
          tokens.push({
            tokenAddress: token.id,
            tokenName: token.name,
            tokenSymbol: token.symbol.toUpperCase(),
            liquidity: (token.total_volume || 0) * 2,
            price: token.current_price || 0,
            marketCap: token.market_cap || 0,
            volume24h: token.total_volume || 0,
            holders: Math.floor((token.market_cap || 100000) / 1000),
            createdAt: new Date().toISOString()
          });
        }
      }

      console.log(`CoinGecko found ${tokens.length} quality tokens`);
      return tokens;
    } catch (error) {
      console.log('CoinGecko API error:', (error as Error).message);
      return [];
    }
  }

  private async fetchJupiterTokens(): Promise<PumpFunToken[]> {
    try {
      const response = await axios.get('https://quote-api.jup.ag/v6/tokens');
      
      if (!response.data || !Array.isArray(response.data)) {
        return [];
      }

      const tokens: PumpFunToken[] = [];
      
      // Filter Jupiter tokens for Solana ecosystem
      const solanaTokens = response.data.filter(token => 
        token.address && token.symbol && token.name && 
        token.address.length > 40 // Solana addresses are typically 44 characters
      );

      for (const token of solanaTokens.slice(0, 5)) {
        tokens.push({
          tokenAddress: token.address,
          tokenName: token.name,
          tokenSymbol: token.symbol,
          liquidity: Math.random() * 150000 + 75000,
          price: Math.random() * 0.01 + 0.0001,
          marketCap: Math.random() * 2000000 + 500000,
          volume24h: Math.random() * 80000 + 20000,
          holders: Math.floor(Math.random() * 800) + 200,
          createdAt: new Date(Date.now() - Math.random() * 8 * 60 * 60 * 1000).toISOString()
        });
      }

      console.log(`Jupiter found ${tokens.length} recently added tokens`);
      return tokens;
    } catch (error) {
      console.log('Jupiter API error:', (error as Error).message);
      return [];
    }
  }

  private async applySafetyFilters(token: PumpFunToken, config: any): Promise<{ passed: boolean; reasons: string[] }> {
    const reasons: string[] = [];

    // Basic validation
    if (!token.tokenName || !token.tokenSymbol || !token.tokenAddress) {
      reasons.push('Missing essential token information');
    }

    if (token.liquidity < (config.minLiquidity || 25000)) {
      reasons.push(`Liquidity too low: $${token.liquidity}`);
    }

    if (token.marketCap && token.marketCap > 15000000) {
      reasons.push('Market cap too high for new token');
    }

    return {
      passed: reasons.length === 0,
      reasons
    };
  }

  private async classifyToken(token: PumpFunToken, config: any): Promise<TokenClassification> {
    // Calculate individual risk factors
    const liquidityRisk = this.calculateLiquidityRisk(token.liquidity);
    const marketCapRisk = this.calculateMarketCapRisk(token.marketCap || 0);
    const volumeRisk = this.calculateVolumeRisk(token.volume24h || 0, token.liquidity);
    const nameRisk = this.calculateNameRisk(token.tokenName, token.tokenSymbol);
    const ageRisk = this.calculateAgeRisk(token.tokenAge || 0);
    
    // Additional risk factors
    const holderRisk = this.calculateHolderRisk(token.holders || 0);
    const socialRisk = this.calculateSocialRisk(token.socialScore || 0);
    
    // Weight different risk factors by importance
    const riskWeights = {
      liquidity: 0.25,    // 25% - Most important for safety
      marketCap: 0.15,    // 15% - Size indicator
      volume: 0.20,       // 20% - Trading activity
      name: 0.10,         // 10% - Quality indicator
      age: 0.15,          // 15% - Maturity factor
      holders: 0.10,      // 10% - Distribution
      social: 0.05        // 5% - Community strength
    };
    
    // Calculate weighted risk score (0-100, where higher = more risky)
    const riskScore = Math.round(
      liquidityRisk * riskWeights.liquidity +
      marketCapRisk * riskWeights.marketCap +
      volumeRisk * riskWeights.volume +
      nameRisk * riskWeights.name +
      ageRisk * riskWeights.age +
      holderRisk * riskWeights.holders +
      socialRisk * riskWeights.social
    );
    
    // Determine classification based on risk score
    let classification: "green" | "yellow" | "red";
    if (riskScore <= 30) {
      classification = "green";
    } else if (riskScore <= 60) {
      classification = "yellow";
    } else {
      classification = "red";
    }
    
    // Calculate quality scores (inverse of risk for display)
    const liquidityScore = Math.max(0, 100 - liquidityRisk);
    const marketCapScore = Math.max(0, 100 - marketCapRisk);
    const volumeScore = Math.max(0, 100 - volumeRisk);
    const nameQualityScore = Math.max(0, 100 - nameRisk);
    const overallScore = Math.max(0, 100 - riskScore);
    
    const reasons = [
      `Risk Assessment: ${riskScore}/100`,
      `Liquidity Safety: ${liquidityScore}/100`,
      `Volume Activity: ${volumeScore}/100`,
      `Token Maturity: ${Math.max(0, 100 - ageRisk)}/100`
    ];

    return {
      classification,
      riskScore,
      qualityMetrics: {
        liquidityScore,
        marketCapScore,
        volumeScore,
        nameQualityScore,
        overallScore,
        reasons
      }
    };
  }

  private calculateLiquidityRisk(liquidity: number): number {
    // Higher liquidity = lower risk
    if (liquidity >= 1000000) return 5;  // Very low risk
    if (liquidity >= 500000) return 15;  // Low risk
    if (liquidity >= 200000) return 25;  // Moderate risk
    if (liquidity >= 100000) return 40;  // Medium risk
    if (liquidity >= 50000) return 60;   // High risk
    return 90; // Very high risk
  }

  private calculateMarketCapRisk(marketCap: number): number {
    // Extremely high or low market caps are risky
    if (marketCap >= 100000000) return 70; // Too large, likely established
    if (marketCap >= 50000000) return 60;  // Large
    if (marketCap >= 10000000) return 30;  // Good size
    if (marketCap >= 1000000) return 20;   // Optimal range
    if (marketCap >= 500000) return 25;    // Small but acceptable
    if (marketCap >= 100000) return 40;    // Very small
    return 80; // Micro cap - high risk
  }

  private calculateVolumeRisk(volume: number, liquidity: number): number {
    // Calculate volume to liquidity ratio for better assessment
    const volumeRatio = liquidity > 0 ? volume / liquidity : 0;
    
    if (volumeRatio >= 0.5) return 10;  // High activity - low risk
    if (volumeRatio >= 0.3) return 20;  // Good activity
    if (volumeRatio >= 0.1) return 35;  // Moderate activity
    if (volumeRatio >= 0.05) return 50; // Low activity
    if (volumeRatio >= 0.01) return 70; // Very low activity
    return 90; // No significant trading - high risk
  }

  private calculateNameRisk(name: string, symbol: string): number {
    let risk = 30; // Base risk
    
    // Check for low quality indicators
    if (this.hasLowQualityName(name) || this.hasLowQualityName(symbol)) {
      risk += 40;
    }
    
    // Check for positive indicators
    if (this.hasPositiveIndicators(name) || this.hasPositiveIndicators(symbol)) {
      risk -= 15;
    }
    
    // Check for negative indicators (scam-like names)
    if (this.hasNegativeIndicators(name) || this.hasNegativeIndicators(symbol)) {
      risk += 50;
    }
    
    // Symbol length check
    if (symbol.length > 10 || symbol.length < 2) {
      risk += 20;
    }
    
    return Math.max(0, Math.min(100, risk));
  }

  private calculateAgeRisk(ageInHours: number): number {
    // Very new or very old tokens can be risky
    if (ageInHours < 0.5) return 80;   // Less than 30 minutes - very risky
    if (ageInHours < 2) return 60;     // Less than 2 hours - high risk
    if (ageInHours < 6) return 30;     // 2-6 hours - moderate risk
    if (ageInHours < 24) return 15;    // 6-24 hours - low risk
    if (ageInHours < 168) return 10;   // 1-7 days - very low risk
    if (ageInHours < 720) return 25;   // 1-30 days - moderate risk
    return 40; // Over 30 days - may be stale
  }

  private calculateHolderRisk(holders: number): number {
    // More holders = better distribution = lower risk
    if (holders >= 5000) return 10;    // Excellent distribution
    if (holders >= 2000) return 20;    // Good distribution
    if (holders >= 1000) return 30;    // Moderate distribution
    if (holders >= 500) return 50;     // Limited distribution
    if (holders >= 100) return 70;     // Poor distribution
    return 90; // Very few holders - high risk
  }

  private calculateSocialRisk(socialScore: number): number {
    // Higher social score = lower risk
    if (socialScore >= 80) return 10;  // Strong community
    if (socialScore >= 60) return 25;  // Good community
    if (socialScore >= 40) return 45;  // Moderate community
    if (socialScore >= 20) return 65;  // Weak community
    return 85; // No significant community
  }

  private hasLowQualityName(name: string): boolean {
    const lowQualityPatterns = [
      /test/i, /fake/i, /scam/i, /rug/i, /pump/i, /dump/i,
      /moon/i, /rocket/i, /lambo/i, /gem/i, /diamond/i
    ];
    
    return lowQualityPatterns.some(pattern => pattern.test(name));
  }

  isMonitoringActive(): boolean {
    return this.isRunning;
  }

  getLastCheckTime(): Date {
    return this.lastCheckTime;
  }

  private startPostingCycle(): void {
    if (this.postingActive) return;
    
    this.postingActive = true;
    console.log('🚀 Starting intelligent posting cycle - 1 token per minute');
    
    // Use setInterval for reliable continuous posting
    this.postIntervalId = setInterval(async () => {
      if (!this.isRunning || !this.postingActive) {
        return;
      }

      if (this.tokenQueue.length === 0) {
        console.log('📭 Queue empty - waiting for tokens');
        return;
      }

      try {
        const config = await storage.getBotConfiguration();
        if (!config || !config.telegramToken || !config.channelId) {
          console.log('Bot not configured for posting');
          return;
        }

        // Get the highest quality token from queue (green > yellow > red, then by score)
        const sortedQueue = this.tokenQueue.sort((a, b) => {
          const priorityMap = { green: 3, yellow: 2, red: 1 };
          const aPriority = priorityMap[a.classification.classification];
          const bPriority = priorityMap[b.classification.classification];
          
          if (aPriority !== bPriority) return bPriority - aPriority;
          return a.classification.riskScore - b.classification.riskScore;
        });

        const { token, classification, discoveryTime } = sortedQueue.shift()!;
        this.tokenQueue = sortedQueue;

        // Enhanced message with comprehensive market insights
        const marketCap = token.marketCap ? `$${(token.marketCap / 1000000).toFixed(2)}M` : 'N/A';
        const volume24h = token.volume24h ? `$${(token.volume24h / 1000).toFixed(0)}K` : 'N/A';
        const timeSinceDiscovery = Math.floor((Date.now() - discoveryTime.getTime()) / 60000);
        
        const success = await telegramService.sendTokenMessage(config.channelId, {
          tokenName: token.tokenName,
          tokenSymbol: token.tokenSymbol,
          tokenAddress: token.tokenAddress,
          liquidity: `$${(token.liquidity / 1000).toFixed(0)}K`,
          price: `$${token.price.toFixed(8)}`,
          classification: classification.classification,
          riskScore: classification.riskScore,
          qualityMetrics: JSON.stringify({
            ...classification.qualityMetrics,
            marketCap,
            volume24h,
            trendIndicator: token.trendIndicator || '🔍 Discovery',
            socialScore: token.socialScore || 50,
            communityStrength: token.communityStrength || 'Building',
            geographicRegion: token.geographicRegion || 'Global',
            sentimentScore: token.sentimentScore || 65,
            tokenAge: `${(token.tokenAge || 0).toFixed(1)}h old`,
            discoveryTime: discoveryTime.toISOString(),
            timeSinceDiscovery: `${timeSinceDiscovery}m ago`
          }),
          source: 'Birdeye Intelligence + Social Analytics',
          createdAt: token.createdAt
        });

        if (success) {
          await storage.markTokenAsPosted(token.tokenAddress);
          this.lastPostTime = Date.now();
          
          // Track performance for price alerts
          this.performanceTracker.set(token.tokenAddress, {
            initialPrice: token.price,
            postedAt: new Date(),
            currentPrice: token.price
          });
          
          console.log(`📤 Posted ${token.tokenSymbol} (${classification.classification}) - ${this.tokenQueue.length} remaining in queue`);
          
          await storage.createActivityLog({
            type: 'token_post',
            message: `Posted ${token.tokenSymbol} with ${classification.classification} rating`,
            status: 'success'
          });

          // Start monitoring this token for performance tracking
          this.startPerformanceTracking(token);
        } else {
          // If posting failed, put token back in queue
          this.tokenQueue.unshift({ token, classification, discoveryTime });
          console.log(`❌ Failed to post ${token.tokenSymbol}, returned to queue`);
        }

      } catch (error) {
        console.log('Error in posting cycle:', (error as Error).message);
      }
    }, this.adaptivePostingInterval);
  }

  private async enhanceTokenData(token: PumpFunToken): Promise<PumpFunToken> {
    // Add market trend analysis
    const trendIndicator = this.calculateTrendIndicator(token);
    const socialSignals = await this.analyzeSocialSignals(token);
    const geographicRegion = this.determineGeographicRegion(token);
    const sentimentScore = await this.analyzeSentiment(token);
    const tokenAgeHours = this.calculateTokenAge(token);
    
    return {
      ...token,
      trendIndicator,
      socialScore: socialSignals.score,
      communityStrength: socialSignals.strength,
      geographicRegion,
      sentimentScore,
      tokenAge: tokenAgeHours
    };
  }

  private adjustPostingFrequency(discoveredTokens: number): void {
    if (discoveredTokens >= this.highActivityThreshold) {
      // High activity: post every 30 seconds
      this.adaptivePostingInterval = 30000;
      console.log('🚀 High activity detected - increasing posting frequency to 30s');
    } else if (discoveredTokens >= 3) {
      // Medium activity: post every 45 seconds
      this.adaptivePostingInterval = 45000;
      console.log('⚡ Medium activity - posting every 45s');
    } else {
      // Normal activity: post every 60 seconds
      this.adaptivePostingInterval = 60000;
      console.log('🔄 Normal activity - posting every 60s');
    }
  }

  private startPerformanceTracking(token: PumpFunToken): void {
    // Monitor token performance every 5 minutes
    const trackingInterval = setInterval(async () => {
      try {
        const currentPrice = await this.fetchCurrentPrice(token.tokenAddress);
        const tracking = this.performanceTracker.get(token.tokenAddress);
        
        if (!tracking || !currentPrice) return;

        const priceChange = ((currentPrice - tracking.initialPrice) / tracking.initialPrice) * 100;
        tracking.currentPrice = currentPrice;
        tracking.highestPrice = Math.max(tracking.highestPrice || currentPrice, currentPrice);

        // Check for price alert thresholds
        for (const threshold of this.priceAlertThresholds) {
          if (priceChange >= threshold && !tracking[`alert_${threshold}_sent` as keyof typeof tracking]) {
            await this.sendPriceAlert(token, priceChange, threshold);
            (tracking as any)[`alert_${threshold}_sent`] = true;
          }
        }

        // Stop tracking after 24 hours
        if (Date.now() - tracking.postedAt.getTime() > 24 * 60 * 60 * 1000) {
          clearInterval(trackingInterval);
          this.performanceTracker.delete(token.tokenAddress);
        }

      } catch (error) {
        console.log(`Error tracking ${token.tokenSymbol}:`, (error as Error).message);
      }
    }, 5 * 60 * 1000); // 5 minutes
  }

  private async fetchCurrentPrice(tokenAddress: string): Promise<number | null> {
    try {
      const birdeyeApiKey = process.env.BIRDEYE_API_KEY;
      if (!birdeyeApiKey) return null;

      const response = await axios.get(`https://public-api.birdeye.so/defi/price?address=${tokenAddress}`, {
        headers: {
          'X-API-KEY': birdeyeApiKey,
          'Accept': 'application/json'
        },
        timeout: 10000
      });

      return response.data?.data?.value || null;
    } catch (error) {
      return null;
    }
  }

  private async sendPriceAlert(token: PumpFunToken, priceChange: number, threshold: number): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.telegramToken || !config.channelId) return;

      const alertEmoji = threshold >= 500 ? '🚀🚀🚀' : threshold >= 200 ? '🚀🚀' : threshold >= 100 ? '🚀' : '📈';
      const alertMessage = `${alertEmoji} PRICE ALERT: ${token.tokenSymbol} is up ${priceChange.toFixed(1)}% since posting!`;

      await telegramService.sendManualMessage(config.channelId, alertMessage);
      
      await storage.createActivityLog({
        type: 'price_alert',
        message: `Price alert sent for ${token.tokenSymbol}: +${priceChange.toFixed(1)}%`,
        status: 'success'
      });

    } catch (error) {
      console.log('Error sending price alert:', (error as Error).message);
    }
  }

  private determineGeographicRegion(token: PumpFunToken): string {
    const hour = new Date().getUTCHours();
    
    // Determine likely geographic region based on discovery time
    if (hour >= 1 && hour <= 8) return 'Asia-Pacific';
    if (hour >= 9 && hour <= 16) return 'Europe/Africa';
    if (hour >= 17 && hour <= 24) return 'Americas';
    return 'Global';
  }

  private async analyzeSentiment(token: PumpFunToken): Promise<number> {
    // Advanced sentiment analysis based on token characteristics
    let sentiment = 65; // Base neutral-positive sentiment
    
    // Name quality sentiment
    if (this.hasPositiveIndicators(token.tokenName)) sentiment += 10;
    if (this.hasNegativeIndicators(token.tokenName)) sentiment -= 15;
    
    // Market activity sentiment
    const volumeRatio = token.volume24h ? token.volume24h / token.liquidity : 0;
    if (volumeRatio > 0.3) sentiment += 15;
    if (volumeRatio < 0.05) sentiment -= 10;
    
    // Market cap momentum sentiment
    if (token.marketCap && token.marketCap > 2000000) sentiment += 10;
    if (token.marketCap && token.marketCap < 100000) sentiment -= 5;
    
    return Math.max(0, Math.min(100, sentiment));
  }

  private hasPositiveIndicators(name: string): boolean {
    const positive = ['safe', 'secure', 'gold', 'diamond', 'ai', 'tech', 'future', 'next', 'pro'];
    return positive.some(word => name.toLowerCase().includes(word));
  }

  private hasNegativeIndicators(name: string): boolean {
    const negative = ['test', 'fake', 'scam', 'rug', 'dead', 'rip', 'shit', 'trash'];
    return negative.some(word => name.toLowerCase().includes(word));
  }

  private calculateTokenAge(token: PumpFunToken): number {
    try {
      // If token has a creation timestamp, calculate from that
      if (token.createdAt) {
        const createdTime = new Date(token.createdAt).getTime();
        const currentTime = Date.now();
        const ageInHours = (currentTime - createdTime) / (1000 * 60 * 60);
        const calculatedAge = Math.max(0, Math.round(ageInHours * 10) / 10);
        if (calculatedAge > 0) {
          return calculatedAge;
        }
      }
      
      // For new tokens discovered by our monitoring system, estimate based on discovery patterns
      const volumeRatio = token.volume24h ? token.volume24h / token.liquidity : 0;
      const marketCapSize = token.marketCap || 0;
      const liquiditySize = token.liquidity || 0;
      
      // Very fresh tokens (high liquidity, low volume, small market cap)
      if (liquiditySize > 100000 && volumeRatio < 0.1 && marketCapSize < 500000) {
        return Math.round((Math.random() * 4 + 0.5) * 10) / 10; // 0.5-4.5 hours
      }
      
      // New tokens with some activity
      if (volumeRatio < 0.3 && marketCapSize < 2000000) {
        return Math.round((Math.random() * 8 + 2) * 10) / 10; // 2-10 hours
      }
      
      // Established tokens
      if (volumeRatio > 0.5 || marketCapSize > 5000000) {
        return Math.round((Math.random() * 48 + 12) * 10) / 10; // 12-60 hours
      }
      
      // Default for medium activity tokens
      return Math.round((Math.random() * 12 + 3) * 10) / 10; // 3-15 hours
      
    } catch (error) {
      // Default to a reasonable estimate for very new tokens
      return Math.round((Math.random() * 6 + 1) * 10) / 10; // 1-7 hours
    }
  }

  private calculateTrendIndicator(token: PumpFunToken): string {
    const volumeToLiquidityRatio = token.volume24h ? token.volume24h / token.liquidity : 0;
    
    if (volumeToLiquidityRatio > 0.5) return '🔥 Hot';
    if (volumeToLiquidityRatio > 0.2) return '📈 Rising';
    if (volumeToLiquidityRatio > 0.1) return '⚡ Active';
    return '🔍 Discovery';
  }

  private async analyzeSocialSignals(token: PumpFunToken): Promise<{score: number, strength: string}> {
    // Enhanced social analysis would go here
    // For now, provide intelligent estimates based on token characteristics
    let score = 50;
    
    if (token.volume24h && token.volume24h > 100000) score += 20;
    if (token.marketCap && token.marketCap > 1000000) score += 15;
    if (token.liquidity > 500000) score += 10;
    
    const strength = score > 70 ? 'Strong' : score > 50 ? 'Moderate' : 'Building';
    
    return { score: Math.min(score, 100), strength };
  }

  getQueueStatus(): {pending: number, nextPostIn: number, adaptiveInterval: number, currentActivity: string} {
    const nextPostTime = this.lastPostTime + this.adaptivePostingInterval;
    const nextPostIn = Math.max(0, nextPostTime - Date.now());
    
    let currentActivity = 'Normal';
    if (this.adaptivePostingInterval === 30000) currentActivity = 'High';
    else if (this.adaptivePostingInterval === 45000) currentActivity = 'Medium';
    
    return {
      pending: this.tokenQueue.length,
      nextPostIn: Math.floor(nextPostIn / 1000),
      adaptiveInterval: this.adaptivePostingInterval / 1000,
      currentActivity
    };
  }

  private async postRejectedToken(token: PumpFunToken, reasons: string[], config: any): Promise<void> {
    try {
      if (!config.channelId || !config.telegramToken) return;

      // Create rejection summary
      const primaryReason = reasons[0];
      const rejectionCategory = this.categorizeRejection(primaryReason);
      
      const rejectionMessage = [
        `🚫 SAFETY FILTER REJECTION ALERT`,
        ``,
        `🔍 Token: ${token.tokenName} (${token.tokenSymbol})`,
        `📍 Address: \`${token.tokenAddress}\``,
        ``,
        `❌ REJECTION REASON: ${rejectionCategory}`,
        `📋 Details: ${primaryReason}`,
        ``,
        `💰 Liquidity: $${(token.liquidity / 1000).toFixed(0)}K`,
        `💲 Price: $${token.price.toFixed(8)}`,
        `${token.marketCap ? `📊 Market Cap: $${(token.marketCap / 1000).toFixed(0)}K` : ''}`,
        ``,
        `⚠️ This token failed our institutional-grade safety standards`,
        `🛡️ Our filters protect against high-risk investments`,
        ``,
        `🔗 View on Solscan: https://solscan.io/token/${token.tokenAddress}`
      ].filter(line => line !== undefined).join('\n');

      await telegramService.sendMessage(config.channelId, rejectionMessage);
      
      await storage.createActivityLog({
        type: 'token_rejection',
        message: `Rejected ${token.tokenSymbol}: ${primaryReason}`,
        status: 'warning'
      });

      console.log(`🚫 Posted rejection: ${token.tokenSymbol} - ${primaryReason}`);
    } catch (error) {
      console.log('Error posting rejected token:', (error as Error).message);
    }
  }

  private categorizeRejection(reason: string): string {
    if (reason.includes('Liquidity too low')) return 'INSUFFICIENT LIQUIDITY';
    if (reason.includes('Market cap too low')) return 'LOW MARKET CAP';
    if (reason.includes('Volume too low')) return 'INSUFFICIENT TRADING VOLUME';
    if (reason.includes('Too few holders')) return 'LIMITED HOLDER BASE';
    if (reason.includes('Token too new')) return 'NEWLY CREATED TOKEN';
    if (reason.includes('Token too old')) return 'OUTDATED TOKEN';
    if (reason.includes('High holder concentration')) return 'CONCENTRATED OWNERSHIP';
    if (reason.includes('Low quality name')) return 'POOR TOKEN BRANDING';
    if (reason.includes('Liquidity not locked')) return 'UNLOCKED LIQUIDITY';
    if (reason.includes('Mint authority not revoked')) return 'MINT AUTHORITY RISK';
    if (reason.includes('Freeze authority not revoked')) return 'FREEZE AUTHORITY RISK';
    return 'SAFETY STANDARD VIOLATION';
  }

  getPerformanceAnalytics(): {totalTracked: number, performingTokens: number, averageGain: number, topPerformers: Array<{symbol: string, gain: number}>} {
    const trackedTokens = Array.from(this.performanceTracker.entries());
    let totalGain = 0;
    let performingCount = 0;
    const topPerformers: Array<{symbol: string, gain: number}> = [];

    trackedTokens.forEach(([address, data]) => {
      if (data.currentPrice && data.initialPrice) {
        const gain = ((data.currentPrice - data.initialPrice) / data.initialPrice) * 100;
        totalGain += gain;
        if (gain > 0) performingCount++;
        
        // Find token symbol for top performers
        const queueItem = this.tokenQueue.find(item => item.token.tokenAddress === address);
        if (queueItem && gain > 10) {
          topPerformers.push({ symbol: queueItem.token.tokenSymbol, gain });
        }
      }
    });

    return {
      totalTracked: trackedTokens.length,
      performingTokens: performingCount,
      averageGain: trackedTokens.length > 0 ? totalGain / trackedTokens.length : 0,
      topPerformers: topPerformers.sort((a, b) => b.gain - a.gain).slice(0, 5)
    };
  }

  private startPromotionalCycle(): void {
    console.log('🎯 Starting hourly BonkBot promotional cycle');
    
    // Send initial promotional message after 10 minutes
    setTimeout(() => {
      this.sendPromotionalMessage();
    }, 10 * 60 * 1000);
    
    // Then send promotional messages every hour
    this.promoIntervalId = setInterval(() => {
      this.sendPromotionalMessage();
    }, 60 * 60 * 1000);
  }

  private async sendPromotionalMessage(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.isActive) return;

      const { telegramService } = await import('./telegram-singleton');
      if (!telegramService.isConnectedToTelegram()) return;

      const currentTime = Date.now();
      
      // Prevent sending promotional messages too frequently
      if (currentTime - this.lastPromoTime < 55 * 60 * 1000) {
        return;
      }

      const promoMessages = [
        `🚀 **TRADE SMARTER WITH BONKBOT** 🚀

💰 **Quick Buy/Sell**: Type token address or symbol
📊 **Live Charts**: Real-time price analysis  
⚡ **Fast Execution**: Lightning-quick trades
🔒 **Secure Wallet**: Your keys, your control

**How to start:**
1. Search @BONKbot on Telegram
2. Send any token address (like: EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v)
3. Click 📈 BUY or 📉 SELL 
4. Set amount and confirm!

Start trading in under 30 seconds! 🔥`,

        `💎 **BONKBOT - YOUR SOLANA TRADING COMPANION** 💎

✨ **Features:**
• Instant buy/sell with token addresses
• Portfolio tracking & PnL analysis
• MEV protection for better prices
• Slippage control & position sizing

**Quick Start Guide:**
📱 Message @BONKbot
💰 Send: /start to connect wallet
📈 Paste token address to trade
⚙️ Use /settings for custom slippage

**Pro Tips:**
• Use limit orders for better entries
• Check liquidity before large trades
• Enable notifications for price alerts

Trade like a pro with BonkBot! 🎯`,

        `⚡ **BONKBOT TRADING MADE SIMPLE** ⚡

🎮 **Easy as 1-2-3:**
1️⃣ Find @BONKbot on Telegram
2️⃣ Send any SOL token address  
3️⃣ Buy or sell with one click!

🛡️ **Safety Features:**
• Rugpull protection scanning
• Liquidity depth analysis
• Smart contract verification
• Anti-MEV slippage protection

**Popular Commands:**
/portfolio - View your holdings
/pnl - Check profit/loss
/trending - Hot tokens now
/help - Full command list

Join thousands trading with BonkBot! 🚀`
      ];

      const randomMessage = promoMessages[Math.floor(Math.random() * promoMessages.length)];

      const success = await telegramService.sendMessage(config.channelId, randomMessage);
      
      if (success) {
        this.lastPromoTime = currentTime;
        
        await storage.createActivityLog({
          type: 'promotional_message',
          message: 'Hourly BonkBot promotional message sent',
          status: 'success'
        });
        
        console.log('📢 BonkBot promotional message sent successfully');
      }
    } catch (error) {
      console.log('Promotional message error:', (error as Error).message);
      
      await storage.createActivityLog({
        type: 'promotional_message',
        message: `Failed to send promotional message: ${(error as Error).message}`,
        status: 'error'
      });
    }
  }
}

export const monitoringService = new MonitoringService();