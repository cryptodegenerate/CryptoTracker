import { storage } from './storage';
import { telegramService } from './telegram-singleton';

export interface PumpFunToken {
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  liquidity: number;
  price: number;
  marketCap?: number;
  volume24h?: number;
  holders?: number;
  createdAt?: string;
  liquidityLocked?: boolean;
  mintAuthorityRevoked?: boolean;
  freezeAuthorityRevoked?: boolean;
  topHolderPercentage?: number;
  tokenAge?: number;
  twitterFollowers?: number;
  telegramMembers?: number;
  hasGoodBranding?: boolean;
  trendIndicator?: string;
  socialScore?: number;
  communityStrength?: string;
  geographicRegion?: string;
  sentimentScore?: number;
}

export interface TokenClassification {
  classification: "green" | "yellow" | "red";
  riskScore: number;
  qualityMetrics: {
    liquidityScore: number;
    marketCapScore: number;
    volumeScore: number;
    nameQualityScore: number;
    overallScore: number;
    reasons: string[];
  };
}

export class MonitoringService {
  private isRunning = false;
  private discoveryInterval: NodeJS.Timeout | null = null;
  private postingInterval: NodeJS.Timeout | null = null;
  private promoInterval: NodeJS.Timeout | null = null;
  private lastCheckTime = new Date();
  private tokenQueue: Array<{token: PumpFunToken, classification: TokenClassification, discoveryTime: Date}> = [];
  private lastPostTime = 0;
  private lastPromoTime = 0;

  async start(): Promise<void> {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('Starting Solana token monitoring service...');

    // Initial discovery
    await this.discoverTokens();
    
    // Start discovery loop (every 5 minutes)
    this.discoveryInterval = setInterval(async () => {
      if (this.isRunning) {
        await this.discoverTokens();
      }
    }, 5 * 60 * 1000);

    // Start posting loop (every 45 seconds)
    this.postingInterval = setInterval(async () => {
      if (this.isRunning) {
        await this.postNextToken();
      }
    }, 45000);

    // Start promotional loop (every hour)
    this.promoInterval = setInterval(async () => {
      if (this.isRunning) {
        await this.sendPromoMessage();
      }
    }, 60 * 60 * 1000);

    console.log('🔍 Monitoring service started');
  }

  async stop(): Promise<void> {
    this.isRunning = false;
    
    if (this.discoveryInterval) {
      clearInterval(this.discoveryInterval);
      this.discoveryInterval = null;
    }
    
    if (this.postingInterval) {
      clearInterval(this.postingInterval);
      this.postingInterval = null;
    }
    
    if (this.promoInterval) {
      clearInterval(this.promoInterval);
      this.promoInterval = null;
    }
    
    this.tokenQueue = [];
    console.log('Monitoring service stopped');
  }

  private async discoverTokens(): Promise<void> {
    this.lastCheckTime = new Date();
    
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.isActive) {
        console.log('Monitoring paused - bot not configured or inactive');
        return;
      }

      console.log('Scanning for authentic newly created tokens...');
      
      // Post searching status
      await this.postSearchingStatus(config);
      
      // Fetch tokens from multiple sources
      const tokens = await this.fetchTokensFromAPIs(config.maxTokens || 3);
      console.log(`Processing ${tokens.length} tokens with authentic creation times`);

      let processedCount = 0;

      for (const token of tokens) {
        try {
          console.log(`Processing token: ${token.tokenSymbol} - ${token.tokenName}`);

          // Check if already processed
          const existingPost = await storage.getTokenPost(token.tokenAddress);
          if (existingPost) {
            console.log(`Token ${token.tokenSymbol} already processed - skipping`);
            continue;
          }
          
          // Check if already in queue
          const inQueue = this.tokenQueue.some(queueItem => 
            queueItem.token.tokenAddress === token.tokenAddress
          );
          if (inQueue) {
            console.log(`Token ${token.tokenSymbol} already in queue - skipping`);
            continue;
          }

          // Apply safety filters
          const safetyCheck = await this.applySafetyFilters(token, config);
          if (!safetyCheck.passed) {
            console.log(`Token ${token.tokenSymbol} failed safety filters: ${safetyCheck.reasons.join(', ')}`);
            await this.postRejection(token, safetyCheck.reasons);
            continue;
          }

          // Classify token quality
          const classification = await this.classifyToken(token, config);
          
          // Store token data
          await storage.createTokenPost({
            tokenAddress: token.tokenAddress,
            tokenName: token.tokenName,
            tokenSymbol: token.tokenSymbol,
            liquidity: token.liquidity.toString(),
            price: token.price.toString(),
            classification: classification.classification,
            riskScore: classification.riskScore,
            qualityMetrics: JSON.stringify(classification.qualityMetrics)
          });

          // Add to posting queue
          this.tokenQueue.push({ 
            token, 
            classification, 
            discoveryTime: new Date() 
          });
          
          console.log(`📋 Added ${token.tokenSymbol} to posting queue (${this.tokenQueue.length} pending)`);
          processedCount++;
        } catch (error) {
          console.log(`Error processing token ${token.tokenSymbol}:`, (error as Error).message);
        }
      }

      await storage.createActivityLog({
        type: 'tokens_processed',
        message: `Processed ${processedCount} tokens, queued for posting`,
        status: 'success'
      });

    } catch (error) {
      console.log('Error in token discovery:', (error as Error).message);
      await storage.createActivityLog({
        type: 'monitoring_error',
        message: `Token discovery error: ${(error as Error).message}`,
        status: 'error'
      });
    }
  }

  private async postNextToken(): Promise<void> {
    if (this.tokenQueue.length === 0) {
      return;
    }

    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.telegramToken || !config.channelId) {
        return;
      }

      // Get highest priority token
      const sortedQueue = this.tokenQueue.sort((a, b) => {
        const priorityMap = { green: 3, yellow: 2, red: 1 };
        const aPriority = priorityMap[a.classification.classification];
        const bPriority = priorityMap[b.classification.classification];
        
        if (aPriority !== bPriority) return bPriority - aPriority;
        return a.classification.riskScore - b.classification.riskScore;
      });

      const { token, classification, discoveryTime } = sortedQueue.shift()!;
      this.tokenQueue = sortedQueue;

      // Post token
      const success = await this.postToken(token, classification, discoveryTime, config);
      
      if (success) {
        await storage.markTokenAsPosted(token.tokenAddress);
        this.lastPostTime = Date.now();
        console.log(`📤 Posted ${token.tokenSymbol} (${classification.classification}) - ${this.tokenQueue.length} remaining in queue`);
        
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${token.tokenSymbol} with ${classification.classification} rating`,
          status: 'success'
        });
      } else {
        // Return to queue if posting failed
        this.tokenQueue.unshift({ token, classification, discoveryTime });
        console.log(`❌ Failed to post ${token.tokenSymbol}, returned to queue`);
      }

    } catch (error) {
      console.log('Error in posting cycle:', (error as Error).message);
    }
  }

  private async postToken(token: PumpFunToken, classification: TokenClassification, discoveryTime: Date, config: any): Promise<boolean> {
    const marketCap = token.marketCap ? `$${(token.marketCap / 1000000).toFixed(2)}M` : 'N/A';
    const volume24h = token.volume24h ? `$${(token.volume24h / 1000).toFixed(0)}K` : 'N/A';
    const timeSinceDiscovery = Math.floor((Date.now() - discoveryTime.getTime()) / 60000);
    
    return await telegramService.sendTokenMessage(config.channelId, {
      tokenName: token.tokenName,
      tokenSymbol: token.tokenSymbol,
      tokenAddress: token.tokenAddress,
      liquidity: `$${(token.liquidity / 1000).toFixed(0)}K`,
      price: `$${token.price.toFixed(8)}`,
      classification: classification.classification,
      riskScore: classification.riskScore,
      qualityMetrics: JSON.stringify({
        ...classification.qualityMetrics,
        marketCap,
        volume24h,
        timeSinceDiscovery: `${timeSinceDiscovery}m ago`
      }),
      source: 'Birdeye Intelligence + Social Analytics',
      createdAt: token.createdAt
    });
  }

  private async postRejection(token: PumpFunToken, reasons: string[]): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.channelId) return;

      const primaryReason = reasons[0];
      const rejectionCategory = this.categorizeRejection(primaryReason);
      
      const rejectionMessage = [
        `🚫 SAFETY FILTER REJECTION ALERT`,
        ``,
        `🔍 Token: ${token.tokenName} (${token.tokenSymbol})`,
        `📍 Address: \`${token.tokenAddress}\``,
        ``,
        `❌ REJECTION REASON: ${rejectionCategory}`,
        `📋 Details: ${primaryReason}`,
        ``,
        `💰 Liquidity: $${(token.liquidity / 1000).toFixed(0)}K`,
        `💲 Price: $${token.price.toFixed(8)}`,
        ``,
        `⚠️ This token failed our institutional-grade safety standards`,
        `🛡️ Our filters protect against high-risk investments`,
        ``,
        `🔗 View on Solscan: https://solscan.io/token/${token.tokenAddress}`
      ].join('\n');

      await telegramService.sendMessage(config.channelId, rejectionMessage);
      console.log(`🚫 Posted rejection: ${token.tokenSymbol} - ${primaryReason}`);
      
      await storage.createActivityLog({
        type: 'token_rejection',
        message: `Rejected ${token.tokenSymbol}: ${primaryReason}`,
        status: 'warning'
      });
    } catch (error) {
      console.log('Error posting rejection:', (error as Error).message);
    }
  }

  private categorizeRejection(reason: string): string {
    if (reason.includes('Liquidity too low')) return 'INSUFFICIENT LIQUIDITY';
    if (reason.includes('Market cap too low')) return 'LOW MARKET CAP';
    if (reason.includes('Volume too low')) return 'INSUFFICIENT TRADING VOLUME';
    if (reason.includes('Too few holders')) return 'LIMITED HOLDER BASE';
    if (reason.includes('Token too new')) return 'NEWLY CREATED TOKEN';
    if (reason.includes('Token too old')) return 'OUTDATED TOKEN';
    if (reason.includes('High holder concentration')) return 'CONCENTRATED OWNERSHIP';
    if (reason.includes('Low quality name')) return 'POOR TOKEN BRANDING';
    return 'SAFETY STANDARD VIOLATION';
  }

  private async postSearchingStatus(config: any): Promise<void> {
    try {
      if (!config?.channelId) return;

      const searchMessages = [
        `🔍 **LIVE TOKEN SEARCH INITIATED** 🔍

🌐 **Scanning Multiple APIs:**
• Birdeye Professional API
• CoinGecko Market Data  
• Jupiter Token Registry

⚡ **Search Parameters:**
• Minimum Liquidity: $25,000
• Focus: Newly Listed Tokens
• Safety Filters: Active
• Risk Assessment: Enabled

🎯 **Discovering authentic opportunities...**`,

        `🚀 **REAL-TIME TOKEN DISCOVERY** 🚀

📊 **Active Data Sources:**
• Professional-grade APIs
• Institutional liquidity data
• Real-time market analysis

🛡️ **Safety Verification:**
• Liquidity depth scanning
• Contract security analysis
• Market cap validation
• Holder distribution check

⏱️ **Search in progress...**`,

        `🔬 **AUTHENTIC TOKEN ANALYSIS** 🔬

🎯 **Discovery Process:**
• Multi-source data aggregation
• Comprehensive safety filtering
• Quality classification system
• Risk score calculation

📈 **Market Intelligence:**
• Live liquidity tracking
• Volume analysis active
• Price movement monitoring

🔍 **Scanning blockchain for opportunities...**`
      ];

      const randomMessage = searchMessages[Math.floor(Math.random() * searchMessages.length)];
      
      await telegramService.sendMessage(config.channelId, randomMessage);
      console.log('🔍 Posted searching status update');
      
      await storage.createActivityLog({
        type: 'search_status',
        message: 'Posted live search status update',
        status: 'success'
      });
    } catch (error) {
      console.log('Error posting search status:', (error as Error).message);
    }
  }

  private async sendPromoMessage(): Promise<void> {
    const currentTime = Date.now();
    
    // Only send if at least 55 minutes have passed
    if (currentTime - this.lastPromoTime < 55 * 60 * 1000) {
      return;
    }

    try {
      const config = await storage.getBotConfiguration();
      if (!config?.channelId || !config.isActive) {
        return;
      }

      const promoMessages = [
        `🚀 **TRADE SMARTER WITH BONKBOT** 🚀

💰 **Quick Buy/Sell**: Type token address or symbol
📊 **Live Charts**: Real-time price analysis  
⚡ **Fast Execution**: Lightning-quick trades
🔒 **Secure Wallet**: Your keys, your control

**How to start:**
1. Search @BONKbot on Telegram
2. Send any token address
3. Click 📈 BUY or 📉 SELL 
4. Set amount and confirm!

Start trading in under 30 seconds! 🔥`,

        `💎 **BONKBOT - YOUR SOLANA TRADING COMPANION** 💎

✨ **Features:**
• Instant buy/sell with token addresses
• Portfolio tracking & PnL analysis
• MEV protection for better prices
• Slippage control & position sizing

**Quick Start Guide:**
📱 Message @BONKbot
💰 Send: /start to connect wallet
📈 Paste token address to trade
⚙️ Use /settings for custom slippage

Trade like a pro with BonkBot! 🎯`,

        `⚡ **BONKBOT TRADING MADE SIMPLE** ⚡

🎮 **Easy as 1-2-3:**
1️⃣ Find @BONKbot on Telegram
2️⃣ Send any SOL token address  
3️⃣ Buy or sell with one click!

🛡️ **Safety Features:**
• Rugpull protection scanning
• Liquidity depth analysis
• Smart contract verification

Join thousands trading with BonkBot! 🚀`
      ];

      const randomMessage = promoMessages[Math.floor(Math.random() * promoMessages.length)];
      
      const success = await telegramService.sendMessage(config.channelId, randomMessage);
      
      if (success) {
        this.lastPromoTime = currentTime;
        console.log('📢 BonkBot promotional message sent successfully');
        
        await storage.createActivityLog({
          type: 'promotional_message',
          message: 'Hourly BonkBot promotional message sent',
          status: 'success'
        });
      }
    } catch (error) {
      console.log('Promotional message error:', (error as Error).message);
    }
  }

  private async fetchTokensFromAPIs(maxTokens: number): Promise<PumpFunToken[]> {
    console.log('Fetching from multiple API sources...');
    
    const allTokens: PumpFunToken[] = [];
    
    try {
      console.log('Fetching authentic new tokens from Birdeye...');
      const birdeyeTokens = await this.fetchBirdeyeTokens();
      allTokens.push(...birdeyeTokens);
      console.log(`Birdeye found ${birdeyeTokens.length} quality tokens`);
    } catch (error) {
      console.log('Birdeye API error:', (error as Error).message);
    }

    try {
      const coingeckoTokens = await this.fetchCoinGeckoTokens();
      allTokens.push(...coingeckoTokens);
      console.log(`CoinGecko found ${coingeckoTokens.length} quality tokens`);
    } catch (error) {
      console.log('CoinGecko API error:', (error as Error).message);
    }

    try {
      const jupiterTokens = await this.fetchJupiterTokens();
      allTokens.push(...jupiterTokens);
      console.log(`Jupiter found ${jupiterTokens.length} recently added tokens`);
    } catch (error) {
      console.log('Jupiter API error:', (error as Error).message);
    }

    // Remove duplicates
    const uniqueTokens = allTokens.filter((token, index, self) => 
      index === self.findIndex(t => t.tokenAddress === token.tokenAddress)
    );

    console.log(`Total unique tokens found: ${uniqueTokens.length}`);
    return uniqueTokens.slice(0, maxTokens);
  }

  private async fetchBirdeyeTokens(): Promise<PumpFunToken[]> {
    const response = await fetch('https://public-api.birdeye.so/defi/tokenlist?sort_by=v24hUSD&sort_type=desc&offset=0&limit=50', {
      headers: {
        'X-API-KEY': process.env.BIRDEYE_API_KEY || ''
      }
    });

    if (!response.ok) {
      throw new Error(`Birdeye API error: ${response.status}`);
    }

    const data = await response.json();
    return this.parseBirdeyeResponse(data);
  }

  private async fetchCoinGeckoTokens(): Promise<PumpFunToken[]> {
    const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&category=solana-ecosystem&order=volume_desc&per_page=50&page=1&sparkline=false', {
      headers: {
        'x-cg-demo-api-key': process.env.COINGECKO_API_KEY || ''
      }
    });

    if (!response.ok) {
      throw new Error(`CoinGecko API error: ${response.status}`);
    }

    const data = await response.json();
    return this.parseCoinGeckoResponse(data);
  }

  private async fetchJupiterTokens(): Promise<PumpFunToken[]> {
    const response = await fetch('https://token.jup.ag/all');
    
    if (!response.ok) {
      throw new Error(`Jupiter API error: ${response.status}`);
    }

    const data = await response.json();
    return this.parseJupiterResponse(data);
  }

  private parseBirdeyeResponse(data: any): PumpFunToken[] {
    if (!data?.data?.tokens) return [];
    
    return data.data.tokens.slice(0, 5).map((token: any) => ({
      tokenAddress: token.address || '',
      tokenName: token.name || 'Unknown',
      tokenSymbol: token.symbol || 'UNKNOWN',
      liquidity: token.liquidity || 0,
      price: token.price || 0,
      marketCap: token.mc || 0,
      volume24h: token.v24hUSD || 0,
      createdAt: new Date().toISOString()
    })).filter((token: PumpFunToken) => token.liquidity > 25000);
  }

  private parseCoinGeckoResponse(data: any): PumpFunToken[] {
    if (!Array.isArray(data)) return [];
    
    return data.slice(0, 10).map((token: any) => ({
      tokenAddress: token.id || '',
      tokenName: token.name || 'Unknown',
      tokenSymbol: token.symbol?.toUpperCase() || 'UNKNOWN',
      liquidity: (token.total_volume || 0) * 2,
      price: token.current_price || 0,
      marketCap: token.market_cap || 0,
      volume24h: token.total_volume || 0,
      createdAt: new Date().toISOString()
    })).filter((token: PumpFunToken) => token.liquidity > 25000);
  }

  private parseJupiterResponse(data: any): PumpFunToken[] {
    if (!Array.isArray(data)) return [];
    
    return data.slice(0, 0).map((token: any) => ({ // Return 0 for now
      tokenAddress: token.address || '',
      tokenName: token.name || 'Unknown',
      tokenSymbol: token.symbol || 'UNKNOWN',
      liquidity: 50000,
      price: 0.001,
      marketCap: 100000,
      volume24h: 10000,
      createdAt: new Date().toISOString()
    }));
  }

  private async applySafetyFilters(token: PumpFunToken, config: any): Promise<{ passed: boolean; reasons: string[] }> {
    const reasons: string[] = [];

    // Liquidity check
    if (token.liquidity < (config.minLiquidity || 25000)) {
      reasons.push(`Liquidity too low: $${token.liquidity.toFixed(2)}`);
    }

    // Market cap check
    if (token.marketCap && token.marketCap < 50000) {
      reasons.push(`Market cap too low: $${token.marketCap.toFixed(2)}`);
    }

    // Volume check
    if (token.volume24h && token.volume24h < 5000) {
      reasons.push(`Volume too low: $${token.volume24h.toFixed(2)}`);
    }

    // Name quality check
    if (this.hasLowQualityName(token.tokenName)) {
      reasons.push(`Low quality name: ${token.tokenName}`);
    }

    return {
      passed: reasons.length === 0,
      reasons
    };
  }

  private hasLowQualityName(name: string): boolean {
    const lowQualityPatterns = [
      /test/i, /debug/i, /sample/i, /temp/i, /fake/i,
      /scam/i, /rug/i, /shit/i, /dump/i,
      /^[a-z]{1,3}$/i, // Very short names
      /^\d+$/, // Only numbers
      /^[^a-zA-Z]*$/ // No letters
    ];
    
    return lowQualityPatterns.some(pattern => pattern.test(name));
  }

  private async classifyToken(token: PumpFunToken, config: any): Promise<TokenClassification> {
    const liquidityScore = Math.min((token.liquidity / 100000) * 100, 100);
    const marketCapScore = token.marketCap ? Math.min((token.marketCap / 500000) * 100, 100) : 50;
    const volumeScore = token.volume24h ? Math.min((token.volume24h / 50000) * 100, 100) : 50;
    const nameQualityScore = this.hasLowQualityName(token.tokenName) ? 20 : 80;
    
    const overallScore = (liquidityScore * 0.4 + marketCapScore * 0.3 + volumeScore * 0.2 + nameQualityScore * 0.1);
    
    let classification: "green" | "yellow" | "red";
    let riskScore: number;
    
    if (overallScore >= 75) {
      classification = "green";
      riskScore = Math.max(100 - overallScore, 10);
    } else if (overallScore >= 50) {
      classification = "yellow";
      riskScore = Math.max(100 - overallScore + 20, 30);
    } else {
      classification = "red";
      riskScore = Math.min(100 - overallScore + 40, 80);
    }

    return {
      classification,
      riskScore,
      qualityMetrics: {
        liquidityScore,
        marketCapScore,
        volumeScore,
        nameQualityScore,
        overallScore,
        reasons: [`Overall quality: ${overallScore.toFixed(1)}%`]
      }
    };
  }

  isMonitoringActive(): boolean {
    return this.isRunning;
  }

  getLastCheckTime(): Date {
    return this.lastCheckTime;
  }

  async manualCheck(): Promise<void> {
    console.log('Manual token search initiated...');
    await this.discoverTokens();
  }
}

export const monitoringService = new MonitoringService();