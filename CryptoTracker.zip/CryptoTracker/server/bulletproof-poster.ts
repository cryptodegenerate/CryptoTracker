import { storage } from './storage';
import { telegramService } from './telegram-singleton';

class BulletproofPoster {
  private intervalId: NodeJS.Timeout | null = null;
  private isActive = false;
  private postInterval = 45000; // 45 seconds
  private lastPostAttempt = 0;
  private consecutiveFailures = 0;

  start(): void {
    if (this.isActive) return;
    
    this.isActive = true;
    console.log('🛡️ Starting bulletproof posting service');
    
    // Use setInterval for maximum reliability
    this.intervalId = setInterval(() => {
      this.attemptPost().catch(error => {
        console.log('Posting error caught:', error.message);
      });
    }, this.postInterval);
    
    // Also attempt first post immediately
    setTimeout(() => this.attemptPost(), 3000);
  }

  stop(): void {
    this.isActive = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    console.log('🛑 Bulletproof posting service stopped');
  }

  private async attemptPost(): Promise<void> {
    if (!this.isActive) return;
    
    this.lastPostAttempt = Date.now();
    console.log('⏰ Bulletproof posting attempt');
    
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.telegramToken || !config.channelId) {
        console.log('⚠️ Bot configuration missing');
        return;
      }

      // Get all unposted tokens
      const unpostedTokens = await storage.getUnpostedTokens();
      if (unpostedTokens.length === 0) {
        console.log('📭 No tokens available for posting');
        return;
      }

      // Always post the first available token
      const tokenToPost = unpostedTokens[0];
      
      console.log(`🎯 Attempting to post: ${tokenToPost.tokenSymbol}`);
      
      const success = await this.postTokenMessage(tokenToPost, config);
      
      if (success) {
        await storage.markTokenAsPosted(tokenToPost.tokenAddress);
        this.consecutiveFailures = 0;
        
        console.log(`✅ Successfully posted ${tokenToPost.tokenSymbol} - ${unpostedTokens.length - 1} remaining`);
        
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${tokenToPost.tokenSymbol}`,
          status: 'success'
        });
      } else {
        this.consecutiveFailures++;
        console.log(`❌ Failed to post ${tokenToPost.tokenSymbol} (failures: ${this.consecutiveFailures})`);
      }

    } catch (error) {
      this.consecutiveFailures++;
      console.log(`💥 Posting exception: ${(error as Error).message} (failures: ${this.consecutiveFailures})`);
    }
  }

  private async postTokenMessage(tokenData: any, config: any): Promise<boolean> {
    try {
      const ageDisplay = tokenData.ageInHours !== undefined && tokenData.ageInHours !== null 
        ? `${Math.round(tokenData.ageInHours)}h` 
        : 'New';
      
      const liquidity = parseFloat(tokenData.liquidity) || 0;
      const marketCap = tokenData.marketCap ? parseFloat(tokenData.marketCap) : liquidity * 1.2;
      const volume = tokenData.volume24h ? parseFloat(tokenData.volume24h) : 0;
      
      const riskEmoji = tokenData.classification === 'green' ? '🟢' : 
                       tokenData.classification === 'yellow' ? '🟡' : '🔴';
      
      const qualityScore = tokenData.qualityMetrics ? 
        JSON.parse(tokenData.qualityMetrics).overallScore : 50;

      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${tokenData.tokenName}** (${tokenData.tokenSymbol})

📊 **Market Data:**
💰 Liquidity: $${liquidity.toLocaleString()}
💵 Market Cap: $${marketCap.toLocaleString()}
📈 24h Volume: $${volume.toLocaleString()}
⏰ Age: ${ageDisplay}

🔗 **Contract:** \`${tokenData.tokenAddress}\`

⚡ **Discovery Metrics:**
${riskEmoji} Risk Level: ${(tokenData.classification || 'UNKNOWN').toUpperCase()}
📊 Quality Score: ${qualityScore.toFixed(1)}%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      return true;
      
    } catch (error) {
      console.log(`📱 Telegram send error: ${(error as Error).message}`);
      return false;
    }
  }

  getStatus(): { 
    active: boolean; 
    lastAttempt: number; 
    failures: number; 
    nextPostIn: number;
  } {
    const now = Date.now();
    const timeSinceLastAttempt = now - this.lastPostAttempt;
    const nextPostIn = Math.max(0, this.postInterval - timeSinceLastAttempt);
    
    return {
      active: this.isActive,
      lastAttempt: this.lastPostAttempt,
      failures: this.consecutiveFailures,
      nextPostIn: nextPostIn
    };
  }
}

export const bulletproofPoster = new BulletproofPoster();