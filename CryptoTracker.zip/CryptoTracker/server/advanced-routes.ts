import { Express } from 'express';
import { autoStrategyBacktester } from './auto-strategy-backtester';
import { telegramTradingBot } from './telegram-trading-bot';
import { autoTrader } from './auto-trader';

export function setupAdvancedRoutes(app: Express): void {
  
  // Auto-Strategy Backtester Routes
  app.post('/api/backtest/run', async (req, res) => {
    try {
      console.log('🧪 Starting backtest optimization...');
      const results = await autoStrategyBacktester.runOptimization();
      res.json({ 
        success: true, 
        message: 'Backtest completed',
        topResults: results.slice(0, 10) 
      });
    } catch (error) {
      console.log('Error running backtest:', (error as Error).message);
      res.status(500).json({ error: 'Failed to run backtest' });
    }
  });

  app.get('/api/backtest/results', async (req, res) => {
    try {
      const results = autoStrategyBacktester.getResults();
      if (!results) {
        res.json({ message: 'No backtest results found. Run optimization first.' });
        return;
      }
      res.json({ 
        results: results.slice(0, 20), // Top 20 results
        summary: {
          totalConfigurations: results.length,
          bestScore: results[0]?.score || 0,
          optimalConfig: results[0]?.config || null
        }
      });
    } catch (error) {
      console.log('Error getting backtest results:', (error as Error).message);
      res.status(500).json({ error: 'Failed to get backtest results' });
    }
  });

  app.post('/api/backtest/apply-optimal', async (req, res) => {
    try {
      const success = await autoStrategyBacktester.applyBestConfiguration();
      if (success) {
        res.json({ 
          success: true, 
          message: 'Optimal configuration applied to auto-trader' 
        });
      } else {
        res.status(400).json({ error: 'No optimal configuration found' });
      }
    } catch (error) {
      console.log('Error applying optimal config:', (error as Error).message);
      res.status(500).json({ error: 'Failed to apply optimal configuration' });
    }
  });

  // Advanced Trading Configuration Routes
  app.post('/api/trading/alpha-signals', async (req, res) => {
    try {
      const { momentumEnabled, momentumThreshold, sentimentEnabled } = req.body;
      
      autoTrader.updateConfig({
        momentumFilterEnabled: momentumEnabled,
        minMomentumPercentage: momentumThreshold || 5,
        sentimentFilterEnabled: sentimentEnabled || false
      });

      res.json({ 
        success: true, 
        message: 'Alpha signal settings updated' 
      });
    } catch (error) {
      console.log('Error updating alpha signals:', (error as Error).message);
      res.status(500).json({ error: 'Failed to update alpha signal settings' });
    }
  });

  app.post('/api/trading/adaptive-risk', async (req, res) => {
    try {
      const { adaptiveEnabled, volatilityAdjustment, streakAdjustment } = req.body;
      
      autoTrader.updateConfig({
        adaptiveRiskEnabled: adaptiveEnabled,
        volatilityAdjustment: volatilityAdjustment,
        streakAdjustment: streakAdjustment
      });

      res.json({ 
        success: true, 
        message: 'Adaptive risk settings updated' 
      });
    } catch (error) {
      console.log('Error updating adaptive risk:', (error as Error).message);
      res.status(500).json({ error: 'Failed to update adaptive risk settings' });
    }
  });

  // Performance Analytics Routes
  app.get('/api/analytics/performance', async (req, res) => {
    try {
      const status = autoTrader.getTradingStatus();
      
      // Enhanced performance analytics
      const analytics = {
        overview: {
          totalInvested: status.totalInvested,
          totalRealized: status.totalRealized,
          winRate: parseFloat(status.winRate),
          activePositions: status.activePositions
        },
        risk: {
          portfolioRisk: status.config.portfolioRiskPercentage,
          stopLoss: status.config.stopLossPercentage,
          takeProfit: status.config.takeProfitPercentage,
          trailingStopEnabled: status.config.trailingStopEnabled
        },
        alphaFeatures: {
          momentumFilter: status.config.momentumFilterEnabled,
          momentumThreshold: status.config.minMomentumPercentage,
          adaptiveRisk: status.config.adaptiveRiskEnabled,
          sentimentFilter: status.config.sentimentFilterEnabled
        },
        filters: {
          minLiquidity: status.config.minLiquidity,
          maxMarketCap: status.config.maxMarketCap,
          minTokenAge: status.config.minTokenAgeMinutes,
          maxDevWallet: status.config.maxDevWalletPercentage
        }
      };

      res.json(analytics);
    } catch (error) {
      console.log('Error getting performance analytics:', (error as Error).message);
      res.status(500).json({ error: 'Failed to get performance analytics' });
    }
  });

  // Telegram Bot Control Routes
  app.post('/api/telegram/send-test', async (req, res) => {
    try {
      await telegramTradingBot.sendTradeAlert('buy', 'TEST', 0.001234);
      res.json({ 
        success: true, 
        message: 'Test alert sent to Telegram' 
      });
    } catch (error) {
      console.log('Error sending test telegram:', (error as Error).message);
      res.status(500).json({ error: 'Failed to send test telegram' });
    }
  });

  app.get('/api/telegram/status', async (req, res) => {
    try {
      res.json({
        initialized: true, // telegramTradingBot.isInitialized would be better
        commandsAvailable: [
          '/status', '/open', '/pnl', '/pause', '/resume', 
          '/risk', '/momentum', '/adaptive', '/trailing', '/help'
        ],
        features: [
          'Real-time trade alerts',
          'Performance summaries', 
          'Remote bot control',
          'Advanced configuration'
        ]
      });
    } catch (error) {
      console.log('Error getting telegram status:', (error as Error).message);
      res.status(500).json({ error: 'Failed to get telegram status' });
    }
  });

  // Quick Action Routes
  app.post('/api/quick/emergency-stop', async (req, res) => {
    try {
      autoTrader.updateConfig({ 
        enabled: false,
        tradingPaused: true 
      });
      
      res.json({ 
        success: true, 
        message: 'Emergency stop activated - all trading halted' 
      });
    } catch (error) {
      console.log('Error activating emergency stop:', (error as Error).message);
      res.status(500).json({ error: 'Failed to activate emergency stop' });
    }
  });

  app.post('/api/quick/optimize-now', async (req, res) => {
    try {
      // Run quick optimization in background
      setImmediate(async () => {
        try {
          await autoStrategyBacktester.runOptimization();
          await autoStrategyBacktester.applyBestConfiguration();
          console.log('✅ Quick optimization completed and applied');
        } catch (error) {
          console.log('❌ Quick optimization failed:', (error as Error).message);
        }
      });

      res.json({ 
        success: true, 
        message: 'Optimization started in background' 
      });
    } catch (error) {
      console.log('Error starting optimization:', (error as Error).message);
      res.status(500).json({ error: 'Failed to start optimization' });
    }
  });

  app.post('/api/quick/reset-blacklist', async (req, res) => {
    try {
      autoTrader.updateConfig({});
      // Note: Would need to add clearBlacklist method to autoTrader
      
      res.json({ 
        success: true, 
        message: 'Blacklist cleared - previously failed tokens can be traded again' 
      });
    } catch (error) {
      console.log('Error clearing blacklist:', (error as Error).message);
      res.status(500).json({ error: 'Failed to clear blacklist' });
    }
  });

  console.log('🚀 Advanced routes initialized');
}