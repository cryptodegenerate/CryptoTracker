import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

interface PostingState {
  lastPostTime: number;
  postDelay: number;
  isActive: boolean;
}

interface TokenQueue {
  tokens: Array<{
    tokenAddress: string;
    tokenName: string;
    tokenSymbol: string;
    liquidity: string;
    price: string;
    classification: string;
    riskScore: number;
    qualityMetrics?: string;
    ageInHours?: number;
    marketCap?: string;
    volume24h?: string;
    posted: boolean;
    queuedAt: number;
  }>;
}

class FileStorage {
  private dataDir = './data';
  private postingStateFile = join(this.dataDir, 'posting-state.json');
  private tokenQueueFile = join(this.dataDir, 'token-queue.json');

  constructor() {
    this.ensureDataDir();
  }

  private ensureDataDir(): void {
    if (!existsSync(this.dataDir)) {
      mkdirSync(this.dataDir, { recursive: true });
    }
  }

  getPostingState(): PostingState {
    try {
      if (existsSync(this.postingStateFile)) {
        const data = readFileSync(this.postingStateFile, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.log('Error reading posting state:', (error as Error).message);
    }
    
    // Default state
    return {
      lastPostTime: Date.now() - 50000, // Allow immediate first post
      postDelay: 45000, // 45 seconds
      isActive: true
    };
  }

  savePostingState(state: PostingState): void {
    try {
      writeFileSync(this.postingStateFile, JSON.stringify(state, null, 2));
    } catch (error) {
      console.log('Error saving posting state:', (error as Error).message);
    }
  }

  getTokenQueue(): TokenQueue {
    try {
      if (existsSync(this.tokenQueueFile)) {
        const data = readFileSync(this.tokenQueueFile, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.log('Error reading token queue:', (error as Error).message);
    }
    
    return { tokens: [] };
  }

  saveTokenQueue(queue: TokenQueue): void {
    try {
      writeFileSync(this.tokenQueueFile, JSON.stringify(queue, null, 2));
    } catch (error) {
      console.log('Error saving token queue:', (error as Error).message);
    }
  }

  addTokenToQueue(tokenData: any): void {
    const queue = this.getTokenQueue();
    
    // Check if token already exists
    const exists = queue.tokens.some(t => t.tokenAddress === tokenData.tokenAddress);
    if (exists) return;
    
    const token = {
      tokenAddress: tokenData.tokenAddress,
      tokenName: tokenData.tokenName,
      tokenSymbol: tokenData.tokenSymbol,
      liquidity: tokenData.liquidity,
      price: tokenData.price,
      classification: tokenData.classification || 'yellow',
      riskScore: tokenData.riskScore || 50,
      qualityMetrics: tokenData.qualityMetrics,
      ageInHours: tokenData.ageInHours,
      marketCap: tokenData.marketCap,
      volume24h: tokenData.volume24h,
      posted: false,
      queuedAt: Date.now()
    };
    
    queue.tokens.push(token);
    this.saveTokenQueue(queue);
  }

  getNextUnpostedToken(): any | null {
    const queue = this.getTokenQueue();
    const unposted = queue.tokens.filter(t => !t.posted);
    return unposted.length > 0 ? unposted[0] : null;
  }

  markTokenAsPosted(tokenAddress: string): void {
    const queue = this.getTokenQueue();
    const token = queue.tokens.find(t => t.tokenAddress === tokenAddress);
    if (token) {
      token.posted = true;
      this.saveTokenQueue(queue);
    }
  }

  getUnpostedCount(): number {
    const queue = this.getTokenQueue();
    return queue.tokens.filter(t => !t.posted).length;
  }

  cleanOldTokens(): void {
    const queue = this.getTokenQueue();
    const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
    
    // Keep only tokens from last 24 hours
    queue.tokens = queue.tokens.filter(t => t.queuedAt > oneDayAgo);
    this.saveTokenQueue(queue);
  }
}

export const fileStorage = new FileStorage();