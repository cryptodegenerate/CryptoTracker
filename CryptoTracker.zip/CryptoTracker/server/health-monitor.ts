import { storage } from './storage';
import { telegramService } from './telegram-singleton';
import { monitoringService } from './monitoring';

interface HealthStatus {
  isHealthy: boolean;
  lastCheck: Date;
  errors: string[];
  uptime: number;
  memoryUsage: number;
  queueStatus: {
    tokensQueued: number;
    lastPost: Date | null;
  };
}

class HealthMonitor {
  private startTime = Date.now();
  private lastHealthCheck = new Date();
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private errorCount = 0;
  private maxErrors = 10;
  private isRunning = false;

  start(): void {
    if (this.isRunning) return;
    this.isRunning = true;

    // Health check every 2 minutes
    this.healthCheckInterval = setInterval(() => {
      this.performHealthCheck();
    }, 120000);

    console.log('🏥 Health monitor started');
  }

  stop(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    this.isRunning = false;
  }

  private async performHealthCheck(): Promise<void> {
    try {
      const status = await this.getHealthStatus();
      this.lastHealthCheck = new Date();

      if (!status.isHealthy) {
        console.log('⚠️ Health check failed:', status.errors);
        await this.attemptRecovery();
      } else {
        this.errorCount = 0; // Reset error count on successful check
      }

      // Log health status every 10 minutes
      if (Date.now() % (10 * 60 * 1000) < 120000) {
        await storage.createActivityLog({
          type: 'health_check',
          message: `System health: ${status.isHealthy ? 'OK' : 'ISSUES'} - Uptime: ${Math.round(status.uptime)}h`,
          status: status.isHealthy ? 'success' : 'warning'
        });
      }
    } catch (error) {
      console.log('Health check error:', (error as Error).message);
      this.errorCount++;
      
      if (this.errorCount > this.maxErrors) {
        await this.emergencyRestart();
      }
    }
  }

  private async getHealthStatus(): Promise<HealthStatus> {
    const errors: string[] = [];
    const memoryUsage = process.memoryUsage().heapUsed / 1024 / 1024; // MB
    const uptime = (Date.now() - this.startTime) / (1000 * 60 * 60); // hours

    // Check Telegram connection
    if (!telegramService.isConnectedToTelegram()) {
      errors.push('Telegram not connected');
    }

    // Check monitoring service
    if (!monitoringService.isMonitoringActive()) {
      errors.push('Monitoring service inactive');
    }

    // Check memory usage (alert if over 500MB)
    if (memoryUsage > 500) {
      errors.push(`High memory usage: ${memoryUsage.toFixed(0)}MB`);
    }

    // Check bot configuration
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.isActive) {
        errors.push('Bot configuration missing or inactive');
      }
    } catch (error) {
      errors.push('Database connection issues');
    }

    // Get queue status
    const queueStatus = this.getQueueStatus();

    return {
      isHealthy: errors.length === 0,
      lastCheck: this.lastHealthCheck,
      errors,
      uptime,
      memoryUsage,
      queueStatus
    };
  }

  private getQueueStatus() {
    try {
      const analytics = monitoringService.getQueueStatus();
      return {
        tokensQueued: analytics.pending,
        lastPost: analytics.nextPostIn > 0 ? new Date(Date.now() - analytics.nextPostIn) : null
      };
    } catch (error) {
      return {
        tokensQueued: 0,
        lastPost: null
      };
    }
  }

  private async attemptRecovery(): Promise<void> {
    console.log('🔧 Attempting system recovery...');

    try {
      // Restart monitoring if stopped
      if (!monitoringService.isMonitoringActive()) {
        console.log('Restarting monitoring service...');
        await monitoringService.start();
      }

      // Reconnect Telegram if disconnected
      if (!telegramService.isConnectedToTelegram()) {
        console.log('Reconnecting Telegram service...');
        const config = await storage.getBotConfiguration();
        if (config?.telegramToken) {
          await telegramService.initialize(config.telegramToken);
        }
      }

      await storage.createActivityLog({
        type: 'system_recovery',
        message: 'Automated recovery attempt completed',
        status: 'success'
      });
    } catch (error) {
      console.log('Recovery failed:', (error as Error).message);
      await storage.createActivityLog({
        type: 'system_recovery',
        message: `Recovery failed: ${(error as Error).message}`,
        status: 'error'
      });
    }
  }

  private async emergencyRestart(): Promise<void> {
    console.log('🚨 Emergency restart required');
    
    await storage.createActivityLog({
      type: 'emergency_restart',
      message: 'System instability detected - emergency restart initiated',
      status: 'error'
    });

    // Graceful shutdown and restart
    try {
      await monitoringService.stop();
      await telegramService.disconnect();
      
      setTimeout(async () => {
        const config = await storage.getBotConfiguration();
        if (config?.telegramToken) {
          await telegramService.initialize(config.telegramToken);
          await monitoringService.start();
          this.errorCount = 0;
        }
      }, 5000);
    } catch (error) {
      console.log('Emergency restart error:', (error as Error).message);
    }
  }

  async getStatus(): Promise<HealthStatus> {
    return this.getHealthStatus();
  }
}

export const healthMonitor = new HealthMonitor();