import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

interface BacktestConfig {
  liquidityRatioMin: number;
  liquidityRatioMax: number;
  minTokenAge: number;
  maxDevWallet: number;
  minMomentum: number;
  stopLoss: number;
  takeProfit: number;
  trailingStop: number;
}

interface BacktestResult {
  config: BacktestConfig;
  totalTrades: number;
  winRate: number;
  avgPnL: number;
  maxDrawdown: number;
  sharpeRatio: number;
  score: number; // composite performance score
}

interface TradeLog {
  timestamp: number;
  symbol: string;
  entryPrice: number;
  exitPrice: number;
  pnlPercent: number;
  exitReason: string;
  tokenAge: number;
  liquidityRatio: number;
  momentum: number;
  devWallet: number;
}

class AutoStrategyBacktester {
  private dataFile = './data/trade-logs.json';
  private resultsFile = './data/backtest-results.json';

  // Simulate historical trades for backtesting
  private generateSampleTrades(): TradeLog[] {
    const trades: TradeLog[] = [];
    const now = Date.now();
    
    for (let i = 0; i < 100; i++) {
      const dayOffset = Math.random() * 30 * 24 * 60 * 60 * 1000; // Last 30 days
      const timestamp = now - dayOffset;
      
      // Generate realistic trade parameters
      const tokenAge = Math.random() * 120 + 5; // 5-125 minutes
      const liquidityRatio = Math.random() * 1.5 + 0.1; // 0.1-1.6
      const momentum = (Math.random() - 0.2) * 20; // -4% to +16%
      const devWallet = Math.random() * 40; // 0-40%
      
      // Simulate P&L based on parameters (better params = better results)
      let basePnL = (Math.random() - 0.45) * 60; // -27% to +33%, slight negative bias
      
      // Adjust P&L based on token quality
      if (tokenAge > 30) basePnL += 5; // Older tokens perform better
      if (liquidityRatio > 0.2 && liquidityRatio < 1.0) basePnL += 8; // Good liquidity ratio
      if (momentum > 5) basePnL += 10; // Positive momentum helps
      if (devWallet < 20) basePnL += 7; // Lower dev ownership is better
      
      const pnlPercent = Math.max(-90, Math.min(500, basePnL)); // Cap between -90% and +500%
      
      trades.push({
        timestamp,
        symbol: `TOKEN${i}`,
        entryPrice: Math.random() * 0.001 + 0.0001,
        exitPrice: 0, // Will be calculated
        pnlPercent,
        exitReason: pnlPercent > 0 ? 'take_profit' : 'stop_loss',
        tokenAge,
        liquidityRatio,
        momentum,
        devWallet
      });
    }
    
    return trades;
  }

  // Run backtest with specific configuration
  private runBacktest(config: BacktestConfig, trades: TradeLog[]): BacktestResult {
    const validTrades = trades.filter(trade => {
      // Apply filters based on config
      if (trade.liquidityRatio < config.liquidityRatioMin) return false;
      if (trade.liquidityRatio > config.liquidityRatioMax) return false;
      if (trade.tokenAge < config.minTokenAge) return false;
      if (trade.devWallet > config.maxDevWallet) return false;
      if (trade.momentum < config.minMomentum) return false;
      
      return true;
    });

    if (validTrades.length === 0) {
      return {
        config,
        totalTrades: 0,
        winRate: 0,
        avgPnL: 0,
        maxDrawdown: 0,
        sharpeRatio: 0,
        score: 0
      };
    }

    const wins = validTrades.filter(t => t.pnlPercent > 0).length;
    const winRate = (wins / validTrades.length) * 100;
    const avgPnL = validTrades.reduce((sum, t) => sum + t.pnlPercent, 0) / validTrades.length;
    
    // Calculate max drawdown
    let peak = 0;
    let maxDrawdown = 0;
    let runningPnL = 0;
    
    validTrades.forEach(trade => {
      runningPnL += trade.pnlPercent;
      if (runningPnL > peak) peak = runningPnL;
      const drawdown = (peak - runningPnL) / Math.max(1, peak) * 100;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    });

    // Calculate Sharpe ratio (simplified)
    const returns = validTrades.map(t => t.pnlPercent);
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
    const sharpeRatio = variance > 0 ? avgReturn / Math.sqrt(variance) : 0;

    // Composite score (higher is better)
    const score = (winRate * 0.3) + (avgPnL * 0.4) + (sharpeRatio * 0.2) - (maxDrawdown * 0.1);

    return {
      config,
      totalTrades: validTrades.length,
      winRate,
      avgPnL,
      maxDrawdown,
      sharpeRatio,
      score
    };
  }

  // Generate optimization configurations to test
  private generateConfigurations(): BacktestConfig[] {
    const configs: BacktestConfig[] = [];
    
    // Test various parameter combinations
    const liquidityMins = [0.15, 0.20, 0.25];
    const liquidityMaxs = [0.8, 1.0, 1.2];
    const tokenAges = [10, 15, 20, 30];
    const devWallets = [15, 20, 25, 30];
    const momentums = [0, 3, 5, 8];
    
    liquidityMins.forEach(lMin => {
      liquidityMaxs.forEach(lMax => {
        if (lMax <= lMin) return;
        
        tokenAges.forEach(age => {
          devWallets.forEach(dev => {
            momentums.forEach(mom => {
              configs.push({
                liquidityRatioMin: lMin,
                liquidityRatioMax: lMax,
                minTokenAge: age,
                maxDevWallet: dev,
                minMomentum: mom,
                stopLoss: 20, // Fixed for now
                takeProfit: 100, // Fixed for now
                trailingStop: 15 // Fixed for now
              });
            });
          });
        });
      });
    });
    
    return configs;
  }

  // Run comprehensive backtest and optimization
  async runOptimization(): Promise<BacktestResult[]> {
    console.log('🧪 Starting auto-strategy backtesting...');
    
    // Generate or load historical trades
    const trades = this.generateSampleTrades();
    console.log(`📊 Generated ${trades.length} sample trades for backtesting`);
    
    // Generate configurations to test
    const configs = this.generateConfigurations();
    console.log(`🔧 Testing ${configs.length} parameter combinations...`);
    
    // Run backtests
    const results: BacktestResult[] = [];
    
    configs.forEach((config, index) => {
      const result = this.runBacktest(config, trades);
      results.push(result);
      
      if (index % 50 === 0) {
        console.log(`⏳ Progress: ${index}/${configs.length} configurations tested`);
      }
    });
    
    // Sort by score (best first)
    results.sort((a, b) => b.score - a.score);
    
    // Save results
    this.saveResults(results);
    
    console.log('✅ Backtesting complete!');
    this.printTopResults(results.slice(0, 5));
    
    return results;
  }

  private saveResults(results: BacktestResult[]): void {
    try {
      writeFileSync(this.resultsFile, JSON.stringify(results, null, 2));
      console.log(`💾 Results saved to ${this.resultsFile}`);
    } catch (error) {
      console.log('❌ Error saving backtest results:', (error as Error).message);
    }
  }

  private printTopResults(results: BacktestResult[]): void {
    console.log('\n🏆 TOP 5 PERFORMING CONFIGURATIONS:');
    console.log('====================================');
    
    results.forEach((result, index) => {
      console.log(`\n#${index + 1} - Score: ${result.score.toFixed(2)}`);
      console.log(`├─ Liquidity Ratio: ${result.config.liquidityRatioMin.toFixed(2)}-${result.config.liquidityRatioMax.toFixed(2)}`);
      console.log(`├─ Min Token Age: ${result.config.minTokenAge} minutes`);
      console.log(`├─ Max Dev Wallet: ${result.config.maxDevWallet}%`);
      console.log(`├─ Min Momentum: ${result.config.minMomentum}%`);
      console.log(`├─ Total Trades: ${result.totalTrades}`);
      console.log(`├─ Win Rate: ${result.winRate.toFixed(1)}%`);
      console.log(`├─ Avg P&L: ${result.avgPnL.toFixed(2)}%`);
      console.log(`├─ Max Drawdown: ${result.maxDrawdown.toFixed(2)}%`);
      console.log(`└─ Sharpe Ratio: ${result.sharpeRatio.toFixed(3)}`);
    });
    
    if (results.length > 0) {
      console.log('\n💡 OPTIMIZATION INSIGHTS:');
      console.log('========================');
      
      const best = results[0];
      console.log(`🎯 Optimal liquidity ratio: ${best.config.liquidityRatioMin.toFixed(2)}-${best.config.liquidityRatioMax.toFixed(2)}`);
      console.log(`⏰ Optimal token age: ${best.config.minTokenAge} minutes`);
      console.log(`🏦 Optimal dev wallet limit: ${best.config.maxDevWallet}%`);
      console.log(`🚀 Optimal momentum threshold: ${best.config.minMomentum}%`);
      
      console.log('\n🔧 RECOMMENDED UPDATES:');
      console.log('======================');
      console.log('Consider updating your trading config with these optimal parameters for better performance.');
    }
  }

  // Get current results
  getResults(): BacktestResult[] | null {
    try {
      if (existsSync(this.resultsFile)) {
        const data = readFileSync(this.resultsFile, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.log('Error loading backtest results:', (error as Error).message);
    }
    return null;
  }

  // Apply best configuration to auto-trader
  async applyBestConfiguration(): Promise<boolean> {
    try {
      const results = this.getResults();
      if (!results || results.length === 0) {
        console.log('❌ No backtest results found. Run optimization first.');
        return false;
      }

      const best = results[0];
      const { autoTrader } = await import('./auto-trader');
      
      autoTrader.updateConfig({
        minTokenAgeMinutes: best.config.minTokenAge,
        maxDevWalletPercentage: best.config.maxDevWallet,
        minMomentumPercentage: best.config.minMomentum,
        stopLossPercentage: best.config.stopLoss,
        takeProfitPercentage: best.config.takeProfit,
        trailingStopDistance: best.config.trailingStop
      });

      console.log('✅ Applied optimal configuration to auto-trader');
      console.log(`🎯 Expected improvement: ${best.score.toFixed(2)} performance score`);
      
      return true;
    } catch (error) {
      console.log('❌ Error applying configuration:', (error as Error).message);
      return false;
    }
  }
}

export const autoStrategyBacktester = new AutoStrategyBacktester();