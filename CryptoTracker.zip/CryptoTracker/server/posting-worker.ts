import { storage } from './storage';
import { telegramService } from './telegram-singleton';

class PostingWorker {
  private running = false;
  private checkInterval = 5000; // Check every 5 seconds
  private postDelay = 45000; // 45 seconds between posts

  async start(): Promise<void> {
    if (this.running) return;
    this.running = true;
    console.log('🚀 Starting posting worker');
    
    // Initialize posting state in database
    await this.initializePostingState();
    this.workerLoop();
  }

  private async initializePostingState(): Promise<void> {
    const existingState = await storage.getPostingState();
    if (!existingState) {
      await storage.updatePostingState({
        lastPostTime: new Date(),
        isActive: true,
        postDelay: this.postDelay
      });
    }
  }

  stop(): void {
    this.running = false;
    console.log('🛑 Posting worker stopped');
  }

  private async workerLoop(): Promise<void> {
    while (this.running) {
      try {
        await this.checkAndPost();
        await this.sleep(this.checkInterval);
      } catch (error) {
        console.log('Worker error:', (error as Error).message);
        await this.sleep(this.checkInterval);
      }
    }
  }

  private async checkAndPost(): Promise<void> {
    const now = new Date();
    
    // Get posting state from database
    const postingState = await storage.getPostingState();
    if (!postingState) {
      await this.initializePostingState();
      return;
    }

    // Only attempt to post if enough time has passed
    const timeSinceLastPost = now.getTime() - postingState.lastPostTime.getTime();
    if (timeSinceLastPost < postingState.postDelay) {
      return;
    }

    const config = await storage.getBotConfiguration();
    if (!config?.isActive || !config.telegramToken || !config.channelId) {
      return;
    }

    const unpostedTokens = await storage.getUnpostedTokens();
    if (unpostedTokens.length === 0) {
      return;
    }

    const tokenToPost = unpostedTokens[0];
    console.log(`🎯 Posting worker attempting: ${tokenToPost.tokenSymbol}`);

    const success = await this.postToken(tokenToPost, config);
    if (success) {
      await storage.markTokenAsPosted(tokenToPost.tokenAddress);
      
      // Update posting state in database
      await storage.updatePostingState({
        lastPostTime: now,
        isActive: true
      });
      
      console.log(`✅ Posted ${tokenToPost.tokenSymbol} - ${unpostedTokens.length - 1} remaining`);
      
      await storage.createActivityLog({
        type: 'token_post',
        message: `Posted ${tokenToPost.tokenSymbol}`,
        status: 'success'
      });
    }
  }

  private async postToken(tokenData: any, config: any): Promise<boolean> {
    try {
      const ageInHours = tokenData.ageInHours || 'Unknown';
      const formattedAge = ageInHours === 'Unknown' ? 'Unknown' : `${Math.round(ageInHours)}h`;
      
      const liquidity = parseFloat(tokenData.liquidity) || 0;
      const marketCap = tokenData.marketCap ? parseFloat(tokenData.marketCap) : null;
      const volume = tokenData.volume24h ? parseFloat(tokenData.volume24h) : null;
      
      const riskEmoji = tokenData.classification === 'green' ? '🟢' : 
                       tokenData.classification === 'yellow' ? '🟡' : '🔴';
      
      let qualityScore = 'N/A';
      try {
        if (tokenData.qualityMetrics) {
          const metrics = JSON.parse(tokenData.qualityMetrics);
          qualityScore = metrics.overallScore?.toFixed(1) || 'N/A';
        }
      } catch (e) {
        // Ignore parsing errors
      }

      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${tokenData.tokenName}** (${tokenData.tokenSymbol})

📊 **Market Data:**
💰 Liquidity: $${liquidity.toLocaleString()}
💵 Market Cap: ${marketCap ? `$${marketCap.toLocaleString()}` : 'N/A'}
📈 24h Volume: ${volume ? `$${volume.toLocaleString()}` : 'N/A'}
⏰ Age: ${formattedAge}

🔗 **Contract:** \`${tokenData.tokenAddress}\`

⚡ **Discovery Metrics:**
${riskEmoji} Risk Level: ${(tokenData.classification || 'UNCLASSIFIED').toUpperCase()}
📊 Quality Score: ${qualityScore}%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      return true;
    } catch (error) {
      console.log('Token posting error:', (error as Error).message);
      return false;
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  isRunning(): boolean {
    return this.running;
  }

  async getStatus(): Promise<{ running: boolean; lastPost: number; nextPostIn: number }> {
    const now = Date.now();
    const postingState = await storage.getPostingState();
    
    if (!postingState) {
      return {
        running: this.running,
        lastPost: 0,
        nextPostIn: 0
      };
    }
    
    const timeSinceLastPost = now - postingState.lastPostTime.getTime();
    const nextPostIn = Math.max(0, postingState.postDelay - timeSinceLastPost);
    
    return {
      running: this.running,
      lastPost: postingState.lastPostTime.getTime(),
      nextPostIn: nextPostIn
    };
  }
}

export const postingWorker = new PostingWorker();