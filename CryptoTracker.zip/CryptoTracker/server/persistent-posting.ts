import { storage } from './storage';
import { telegramService } from './telegram-singleton';

class PersistentPostingService {
  private intervalId: NodeJS.Timeout | null = null;
  private isActive = false;

  async start(): Promise<void> {
    if (this.isActive) return;
    this.isActive = true;
    
    console.log('🔄 Starting persistent posting service');
    
    // Initialize posting state
    await this.initializeState();
    
    // Start checking every 10 seconds
    this.intervalId = setInterval(() => {
      this.processQueue().catch(err => 
        console.log('Posting queue error:', err.message)
      );
    }, 10000);
  }

  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isActive = false;
    console.log('🛑 Persistent posting service stopped');
  }

  private async initializeState(): Promise<void> {
    const state = await storage.getPostingState();
    if (!state) {
      await storage.updatePostingState({
        lastPostTime: new Date(Date.now() - 50000), // Allow immediate first post
        isActive: true,
        postDelay: 45000
      });
    }
  }

  private async processQueue(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.telegramToken || !config.channelId) {
        return;
      }

      const postingState = await storage.getPostingState();
      if (!postingState || !postingState.isActive) {
        return;
      }

      // Check if enough time has passed
      const now = new Date();
      const timeSinceLastPost = now.getTime() - postingState.lastPostTime.getTime();
      
      if (timeSinceLastPost < postingState.postDelay) {
        return;
      }

      // Get next token to post
      const unpostedTokens = await storage.getUnpostedTokens();
      if (unpostedTokens.length === 0) {
        return;
      }

      const tokenToPost = unpostedTokens[0];
      console.log(`📤 Posting: ${tokenToPost.tokenSymbol}`);

      const success = await this.postTokenMessage(tokenToPost, config);
      
      if (success) {
        await storage.markTokenAsPosted(tokenToPost.tokenAddress);
        await storage.updatePostingState({
          lastPostTime: now,
          isActive: true
        });
        
        console.log(`✅ Posted ${tokenToPost.tokenSymbol} - ${unpostedTokens.length - 1} remaining`);
        
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${tokenToPost.tokenSymbol}`,
          status: 'success'
        });
      }
    } catch (error) {
      console.log('Queue processing error:', (error as Error).message);
    }
  }

  private async postTokenMessage(tokenData: any, config: any): Promise<boolean> {
    try {
      const ageInHours = tokenData.ageInHours || 'Unknown';
      const formattedAge = ageInHours === 'Unknown' ? 'Unknown' : `${Math.round(ageInHours)}h`;
      
      const liquidity = parseFloat(tokenData.liquidity) || 0;
      const marketCap = tokenData.marketCap ? parseFloat(tokenData.marketCap) : null;
      const volume = tokenData.volume24h ? parseFloat(tokenData.volume24h) : null;
      
      const riskEmoji = tokenData.classification === 'green' ? '🟢' : 
                       tokenData.classification === 'yellow' ? '🟡' : '🔴';
      
      let qualityScore = 'N/A';
      try {
        if (tokenData.qualityMetrics) {
          const metrics = JSON.parse(tokenData.qualityMetrics);
          qualityScore = metrics.overallScore?.toFixed(1) || 'N/A';
        }
      } catch (e) {
        // Ignore parsing errors
      }

      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${tokenData.tokenName}** (${tokenData.tokenSymbol})

📊 **Market Data:**
💰 Liquidity: $${liquidity.toLocaleString()}
💵 Market Cap: ${marketCap ? `$${marketCap.toLocaleString()}` : 'N/A'}
📈 24h Volume: ${volume ? `$${volume.toLocaleString()}` : 'N/A'}
⏰ Age: ${formattedAge}

🔗 **Contract:** \`${tokenData.tokenAddress}\`

⚡ **Discovery Metrics:**
${riskEmoji} Risk Level: ${(tokenData.classification || 'UNCLASSIFIED').toUpperCase()}
📊 Quality Score: ${qualityScore}%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      return true;
    } catch (error) {
      console.log('Telegram posting failed:', (error as Error).message);
      return false;
    }
  }

  isRunning(): boolean {
    return this.isActive;
  }

  async getStatus(): Promise<{
    active: boolean;
    nextPostIn: number;
    queueSize: number;
  }> {
    const postingState = await storage.getPostingState();
    const unpostedTokens = await storage.getUnpostedTokens();
    
    if (!postingState) {
      return {
        active: this.isActive,
        nextPostIn: 0,
        queueSize: unpostedTokens.length
      };
    }

    const now = Date.now();
    const timeSinceLastPost = now - postingState.lastPostTime.getTime();
    const nextPostIn = Math.max(0, postingState.postDelay - timeSinceLastPost);

    return {
      active: this.isActive,
      nextPostIn,
      queueSize: unpostedTokens.length
    };
  }
}

export const persistentPostingService = new PersistentPostingService();