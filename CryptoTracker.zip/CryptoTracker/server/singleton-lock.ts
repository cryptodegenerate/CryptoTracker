import { writeFileSync, readFileSync, existsSync, unlinkSync, mkdirSync } from 'fs';
import { dirname } from 'path';

export class SingletonLock {
  private lockFile: string;
  private processId: number;
  private isLocked = false;

  constructor(name: string) {
    this.lockFile = `./tmp/${name}.lock`;
    this.processId = process.pid;
    
    // Ensure tmp directory exists
    const dir = dirname(this.lockFile);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
  }

  acquire(): boolean {
    try {
      if (this.isAlreadyRunning()) {
        return false;
      }

      writeFileSync(this.lockFile, this.processId.toString());
      this.isLocked = true;
      
      // Clean up on exit
      process.on('exit', () => this.release());
      process.on('SIGINT', () => {
        this.release();
        process.exit(0);
      });
      process.on('SIGTERM', () => {
        this.release();
        process.exit(0);
      });

      return true;
    } catch (error) {
      return false;
    }
  }

  private isAlreadyRunning(): boolean {
    if (!existsSync(this.lockFile)) {
      return false;
    }

    try {
      const pidStr = readFileSync(this.lockFile, 'utf8').trim();
      const pid = parseInt(pidStr);
      
      if (isNaN(pid)) {
        // Invalid PID, remove stale lock
        this.release();
        return false;
      }

      // Check if process is still running
      try {
        process.kill(pid, 0); // Signal 0 just checks if process exists
        return true; // Process is running
      } catch (error) {
        // Process doesn't exist, remove stale lock
        this.release();
        return false;
      }
    } catch (error) {
      // Error reading lock file, assume not running
      this.release();
      return false;
    }
  }

  release(): void {
    if (this.isLocked && existsSync(this.lockFile)) {
      try {
        unlinkSync(this.lockFile);
        this.isLocked = false;
      } catch (error) {
        // Ignore cleanup errors
      }
    }
  }
}