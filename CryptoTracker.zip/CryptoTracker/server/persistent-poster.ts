import { storage } from './storage';
import { telegramService } from './telegram-singleton';

class PersistentPoster {
  private isActive = false;
  private postingLoop: NodeJS.Timeout | null = null;
  private lastPostTime = 0;
  private postInterval = 45000; // 45 seconds
  private consecutiveFailures = 0;
  private maxFailures = 5;

  start(): void {
    if (this.isActive) return;
    
    this.isActive = true;
    console.log('🚀 Starting persistent posting service');
    
    // Start posting immediately, then maintain the loop
    this.scheduleNextPost(2000); // 2 second delay for startup
  }

  stop(): void {
    this.isActive = false;
    if (this.postingLoop) {
      clearTimeout(this.postingLoop);
      this.postingLoop = null;
    }
    console.log('🛑 Persistent posting service stopped');
  }

  private scheduleNextPost(delay: number = this.postInterval): void {
    if (!this.isActive) return;

    this.postingLoop = setTimeout(async () => {
      await this.attemptPost();
      this.scheduleNextPost(); // Schedule the next post
    }, delay);
  }

  private async attemptPost(): Promise<void> {
    try {
      console.log('⏰ Posting attempt triggered');
      
      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.telegramToken || !config.channelId) {
        console.log('Bot not configured for posting');
        return;
      }

      // Get unposted tokens
      const unpostedTokens = await storage.getUnpostedTokens();
      if (unpostedTokens.length === 0) {
        console.log('No tokens to post');
        return;
      }

      // Post the first token
      const tokenToPost = unpostedTokens[0];
      const success = await this.postToken(tokenToPost, config);
      
      if (success) {
        await storage.markTokenAsPosted(tokenToPost.tokenAddress);
        this.lastPostTime = Date.now();
        this.consecutiveFailures = 0;
        
        console.log(`📤 Posted ${tokenToPost.tokenSymbol} - ${unpostedTokens.length - 1} remaining`);
        
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${tokenToPost.tokenSymbol}`,
          status: 'success'
        });
      } else {
        this.consecutiveFailures++;
        console.log(`Failed to post ${tokenToPost.tokenSymbol} (${this.consecutiveFailures}/${this.maxFailures})`);
      }

    } catch (error) {
      this.consecutiveFailures++;
      console.log('Posting error:', (error as Error).message);
      
      if (this.consecutiveFailures >= this.maxFailures) {
        console.log('Too many consecutive failures, restarting posting service...');
        this.restart();
      }
    }
  }

  private async postToken(tokenData: any, config: any): Promise<boolean> {
    try {
      const ageInHours = tokenData.ageInHours || 'Unknown';
      const formattedAge = ageInHours === 'Unknown' ? 'Unknown' : `${Math.round(ageInHours)}h`;
      
      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${tokenData.tokenName}** (${tokenData.tokenSymbol})

📊 **Market Data:**
💰 Liquidity: $${tokenData.liquidity?.toLocaleString() || 'N/A'}
💵 Market Cap: $${tokenData.marketCap?.toLocaleString() || 'N/A'}
📈 24h Volume: $${tokenData.volume24h?.toLocaleString() || 'N/A'}
⏰ Age: ${formattedAge}

🔗 **Contract:** \`${tokenData.tokenAddress}\`

⚡ **Discovery Metrics:**
${tokenData.classification === 'green' ? '🟢' : tokenData.classification === 'yellow' ? '🟡' : '🔴'} Risk Level: ${tokenData.classification?.toUpperCase() || 'UNCLASSIFIED'}
📊 Quality Score: ${tokenData.qualityMetrics?.overallScore?.toFixed(1) || 'N/A'}%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      return true;
    } catch (error) {
      console.log('Token posting error:', (error as Error).message);
      return false;
    }
  }

  private restart(): void {
    console.log('🔄 Restarting persistent posting service...');
    this.stop();
    setTimeout(() => {
      this.consecutiveFailures = 0;
      this.start();
    }, 5000);
  }

  getStatus(): { active: boolean, lastPost: number, failures: number, nextPostIn: number } {
    const now = Date.now();
    const timeSinceLastSchedule = this.postingLoop ? this.postInterval : 0;
    
    return {
      active: this.isActive,
      lastPost: this.lastPostTime,
      failures: this.consecutiveFailures,
      nextPostIn: Math.max(0, timeSinceLastSchedule)
    };
  }
}

export const persistentPoster = new PersistentPoster();