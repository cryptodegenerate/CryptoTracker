import { storage } from './storage';
import { telegramService } from './telegram-singleton';
import { quietResetManager } from './quiet-reset';
import { filePostingService } from './file-posting-service';

export interface PumpFunToken {
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  liquidity: number;
  price: number;
  marketCap?: number;
  volume24h?: number;
  holders?: number;
  createdAt?: string;
  ageInHours?: number;
}

export interface TokenClassification {
  classification: "green" | "yellow" | "red";
  riskScore: number;
  qualityMetrics: {
    liquidityScore: number;
    marketCapScore: number;
    volumeScore: number;
    nameQualityScore: number;
    overallScore: number;
    reasons: string[];
  };
}

export class RobustMonitoringService {
  private isRunning = false;
  private discoveryTimer: NodeJS.Timeout | null = null;
  private postingTimer: NodeJS.Timeout | null = null;
  private promoTimer: NodeJS.Timeout | null = null;
  private lastCheckTime = new Date();

  async start(): Promise<void> {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('🚀 Starting robust monitoring service');

    // Start quiet reset manager
    quietResetManager.start();

    // Immediate initial discovery
    setTimeout(() => this.performDiscovery(), 1000);
    
    // Set up persistent timers - only discovery and promo, posting handled by persistent service
    this.startDiscoveryTimer();
    this.startPromoTimer();
  }

  async stop(): Promise<void> {
    this.isRunning = false;
    
    // Stop quiet reset manager
    quietResetManager.stop();
    
    [this.discoveryTimer, this.postingTimer, this.promoTimer].forEach(timer => {
      if (timer) clearInterval(timer);
    });
    
    this.discoveryTimer = null;
    this.postingTimer = null;
    this.promoTimer = null;
    
    console.log('Monitoring service stopped');
  }

  private startDiscoveryTimer(): void {
    this.discoveryTimer = setInterval(() => {
      if (this.isRunning) {
        this.performDiscovery();
      }
    }, 5 * 60 * 1000); // 5 minutes
  }

  private startPostingTimer(): void {
    // Start posting immediately, then continue every 45 seconds
    setTimeout(async () => {
      if (this.isRunning) {
        console.log('⏰ Initial posting timer triggered');
        await this.performPosting();
      }
    }, 5000); // 5 second delay for startup

    this.postingTimer = setInterval(async () => {
      if (this.isRunning) {
        console.log('⏰ Posting timer triggered');
        await this.performPosting();
      }
    }, 45000); // 45 seconds
  }

  private startPromoTimer(): void {
    this.promoTimer = setInterval(() => {
      if (this.isRunning) {
        this.sendPromoMessage();
      }
    }, 60 * 60 * 1000); // 1 hour
  }

  private async performDiscovery(): Promise<void> {
    this.lastCheckTime = new Date();
    
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.channelId) return;

      console.log('🔍 Performing token discovery...');
      
      // Post searching status
      await this.postSearchingStatus(config);
      
      // Get recently processed tokens (last 2 hours) to avoid duplicates  
      const processedTokens = await storage.getAllStoredTokens();
      const recentCutoff = new Date(Date.now() - 2 * 60 * 60 * 1000); // 2 hours ago
      const recentlyProcessed = new Set(
        processedTokens
          .filter(t => new Date(t.createdAt) > recentCutoff)
          .map(t => t.tokenAddress)
      );
      
      // Fetch and filter new tokens
      const allTokens = await this.fetchTokens();
      const newTokens = allTokens.filter(token => !recentlyProcessed.has(token.tokenAddress));
      
      console.log(`Found ${allTokens.length} total tokens, ${newTokens.length} new ones to process`);

      // Process new tokens
      let processedCount = 0;
      for (const token of newTokens.slice(0, 5)) {
        await this.processToken(token, config);
        processedCount++;
      }

      await storage.createActivityLog({
        type: 'tokens_processed',
        message: `Discovery cycle completed - processed ${processedCount} new tokens`,
        status: 'success'
      });

    } catch (error) {
      console.log('Discovery error:', (error as Error).message);
    }
  }

  private async performPosting(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.channelId) return;

      // Get unposted tokens from storage
      const unpostedTokens = await storage.getUnpostedTokens();
      if (unpostedTokens.length === 0) return;

      // Post the first unposted token
      const tokenToPost = unpostedTokens[0];
      
      const success = await this.postStoredToken(tokenToPost, config);
      
      if (success) {
        await storage.markTokenAsPosted(tokenToPost.tokenAddress);
        console.log(`📤 Posted ${tokenToPost.tokenSymbol} - ${unpostedTokens.length - 1} remaining`);
        
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${tokenToPost.tokenSymbol}`,
          status: 'success'
        });
      }

    } catch (error) {
      console.log('Posting error:', (error as Error).message);
    }
  }

  private async processToken(token: PumpFunToken, config: any): Promise<void> {
    try {
      // Check if already processed
      const existing = await storage.getTokenPost(token.tokenAddress);
      if (existing) return;

      console.log(`Processing: ${token.tokenSymbol}`);

      // Apply safety filters
      const safetyCheck = await this.applySafetyFilters(token);
      
      if (!safetyCheck.passed) {
        console.log(`Rejected ${token.tokenSymbol}: ${safetyCheck.reasons.join(', ')}`);
        await this.postRejection(token, safetyCheck.reasons, config);
        return;
      }

      // Classify and store
      const classification = await this.classifyToken(token);
      
      // Store in database for tracking
      await storage.createTokenPost({
        tokenAddress: token.tokenAddress,
        tokenName: token.tokenName,
        tokenSymbol: token.tokenSymbol,
        liquidity: token.liquidity.toString(),
        price: token.price.toString(),
        classification: classification.classification,
        riskScore: classification.riskScore,
        qualityMetrics: JSON.stringify(classification.qualityMetrics),
        ageInHours: token.ageInHours
      });

      // Queue in file-based storage for persistent posting
      filePostingService.queueToken({
        tokenAddress: token.tokenAddress,
        tokenName: token.tokenName,
        tokenSymbol: token.tokenSymbol,
        liquidity: token.liquidity.toString(),
        price: token.price.toString(),
        classification: classification.classification,
        riskScore: classification.riskScore,
        qualityMetrics: JSON.stringify(classification.qualityMetrics),
        ageInHours: token.ageInHours,
        marketCap: token.marketCap?.toString(),
        volume24h: token.volume24h?.toString()
      });

      console.log(`✅ Queued ${token.tokenSymbol} for posting`);

    } catch (error) {
      console.log(`Error processing ${token.tokenSymbol}:`, (error as Error).message);
    }
  }

  private async postStoredToken(tokenData: any, config: any): Promise<boolean> {
    try {
      const qualityMetrics = JSON.parse(tokenData.qualityMetrics || '{}');
      const ageHours = tokenData.ageInHours || 'Unknown';
      
      const message = {
        tokenName: tokenData.tokenName,
        tokenSymbol: tokenData.tokenSymbol,
        tokenAddress: tokenData.tokenAddress,
        liquidity: `$${(parseFloat(tokenData.liquidity) / 1000).toFixed(0)}K`,
        price: `$${parseFloat(tokenData.price).toFixed(8)}`,
        classification: tokenData.classification,
        riskScore: tokenData.riskScore,
        qualityMetrics: JSON.stringify(qualityMetrics),
        source: 'Multi-API Discovery Engine',
        createdAt: tokenData.createdAt?.toISOString(),
        ageInHours: typeof ageHours === 'number' ? `${ageHours}h` : ageHours
      };

      return await telegramService.sendTokenMessage(config.channelId, message);
    } catch (error) {
      console.log('Error posting token:', (error as Error).message);
      return false;
    }
  }

  private async postRejection(token: PumpFunToken, reasons: string[], config: any): Promise<void> {
    try {
      const primaryReason = reasons[0];
      const category = this.categorizeRejection(primaryReason);
      
      const message = [
        `🚫 SAFETY FILTER REJECTION ALERT`,
        ``,
        `🔍 Token: ${token.tokenName} (${token.tokenSymbol})`,
        `📍 Address: \`${token.tokenAddress}\``,
        ``,
        `❌ REJECTION REASON: ${category}`,
        `📋 Details: ${primaryReason}`,
        ``,
        `💰 Liquidity: $${(token.liquidity / 1000).toFixed(0)}K`,
        `💲 Price: $${token.price.toFixed(8)}`,
        ``,
        `⚠️ This token failed our institutional-grade safety standards`,
        `🛡️ Our filters protect against high-risk investments`,
        ``,
        `🔗 View on Solscan: https://solscan.io/token/${token.tokenAddress}`
      ].join('\n');

      await telegramService.sendMessage(config.channelId, message);
      console.log(`🚫 Posted rejection: ${token.tokenSymbol}`);

    } catch (error) {
      console.log('Error posting rejection:', (error as Error).message);
    }
  }

  private async postSearchingStatus(config: any): Promise<void> {
    try {
      const searchMessages = [
        `🔍 **LIVE TOKEN SEARCH INITIATED** 🔍

🌐 **Scanning Multiple APIs:**
• Birdeye Professional API
• CoinGecko Market Data  
• Jupiter Token Registry

⚡ **Search Parameters:**
• Minimum Liquidity: $25,000
• Focus: Newly Listed Tokens
• Safety Filters: Active
• Risk Assessment: Enabled

🎯 **Discovering authentic opportunities...**`,

        `🚀 **REAL-TIME TOKEN DISCOVERY** 🚀

📊 **Active Data Sources:**
• Professional-grade APIs
• Institutional liquidity data
• Real-time market analysis

🛡️ **Safety Verification:**
• Liquidity depth scanning
• Contract security analysis
• Market cap validation
• Holder distribution check

⏱️ **Search in progress...**`,

        `🔬 **AUTHENTIC TOKEN ANALYSIS** 🔬

🎯 **Discovery Process:**
• Multi-source data aggregation
• Comprehensive safety filtering
• Quality classification system
• Risk score calculation

📈 **Market Intelligence:**
• Live liquidity tracking
• Volume analysis active
• Price movement monitoring

🔍 **Scanning blockchain for opportunities...**`
      ];

      const randomMessage = searchMessages[Math.floor(Math.random() * searchMessages.length)];
      
      await telegramService.sendMessage(config.channelId, randomMessage);
      console.log('🔍 Posted searching status');

    } catch (error) {
      console.log('Error posting search status:', (error as Error).message);
    }
  }

  private async sendPromoMessage(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.channelId || !config.isActive) return;

      const promoMessages = [
        `🚀 **TRADE SMARTER WITH BONKBOT** 🚀

💰 **Quick Buy/Sell**: Type token address or symbol
📊 **Live Charts**: Real-time price analysis  
⚡ **Fast Execution**: Lightning-quick trades
🔒 **Secure Wallet**: Your keys, your control

**How to start:**
1. Search @BONKbot on Telegram
2. Send any token address
3. Click 📈 BUY or 📉 SELL 
4. Set amount and confirm!

Start trading in under 30 seconds! 🔥`,

        `💎 **BONKBOT - YOUR SOLANA TRADING COMPANION** 💎

✨ **Features:**
• Instant buy/sell with token addresses
• Portfolio tracking & PnL analysis
• MEV protection for better prices
• Slippage control & position sizing

**Quick Start Guide:**
📱 Message @BONKbot
💰 Send: /start to connect wallet
📈 Paste token address to trade
⚙️ Use /settings for custom slippage

Trade like a pro with BonkBot! 🎯`,

        `⚡ **BONKBOT TRADING MADE SIMPLE** ⚡

🎮 **Easy as 1-2-3:**
1️⃣ Find @BONKbot on Telegram
2️⃣ Send any SOL token address  
3️⃣ Buy or sell with one click!

🛡️ **Safety Features:**
• Rugpull protection scanning
• Liquidity depth scanning
• Smart contract verification

Join thousands trading with BonkBot! 🚀`
      ];

      const randomMessage = promoMessages[Math.floor(Math.random() * promoMessages.length)];
      
      await telegramService.sendMessage(config.channelId, randomMessage);
      console.log('📢 Posted BonkBot promotion');

    } catch (error) {
      console.log('Promo error:', (error as Error).message);
    }
  }

  private async fetchTokens(): Promise<PumpFunToken[]> {
    const allTokens: PumpFunToken[] = [];
    
    // Rotate API parameters to get different token sets
    const currentOffset = Math.floor((Date.now() / 120000) % 15) * 5; // Change offset every 2 minutes, 0-70 range
    const sortOptions = ['v24hChangePercent', 'v24hUSD', 'liquidity'];
    const currentSort = sortOptions[Math.floor(Date.now() / 240000) % sortOptions.length]; // Change sort every 4 minutes
    
    console.log(`Discovery: offset=${currentOffset}, sort=${currentSort}`);
    
    // Primary Birdeye API call with rotation
    try {
      const response = await fetch(`https://public-api.birdeye.so/defi/tokenlist?sort_by=${currentSort}&sort_type=desc&offset=${currentOffset}&limit=50`, {
        headers: { 'X-API-KEY': process.env.BIRDEYE_API_KEY || '' }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log(`Birdeye API: ${data?.data?.tokens?.length || 0} tokens returned`);
        
        // Debug log the first few tokens to understand the data structure
        if (data?.data?.tokens && data.data.tokens.length > 0) {
          console.log(`Sample token:`, JSON.stringify(data.data.tokens[0], null, 2));
          console.log(`Sample token passes filters:`, 
            `liquidity=${data.data.tokens[0].liquidity > 500}, `,
            `volume=${data.data.tokens[0].v24hUSD > 50}, `,
            `marketCap=${data.data.tokens[0].mc > 500 && data.data.tokens[0].mc < 100000000}`);
        }
        
        if (data?.data?.tokens && data.data.tokens.length > 0) {
          const excludeMajorTokens = ['SOL', 'USDC', 'USDT', 'WBTC', 'cbBTC', 'JitoSOL', 'sctmSOL', 'JLP', 'WSOL', 'BONK', 'WIF', 'POPCAT', 'JUP'];
          
          const processedTokens = data.data.tokens
            .filter((token: any) => !excludeMajorTokens.includes(token.symbol))
            .filter((token: any) => token.symbol && token.symbol.length >= 2 && token.symbol.length <= 10)
            .slice(0, 15)
            .map((token: any) => {
              const ageInHours = token.lastTradeUnixTime ? 
                Math.floor((Date.now() - (token.lastTradeUnixTime * 1000)) / (1000 * 60 * 60)) : 0;
              
              return {
                tokenAddress: token.address || '',
                tokenName: token.name || 'Unknown',
                tokenSymbol: token.symbol || 'UNKNOWN',
                liquidity: token.liquidity || 0,
                price: token.price || 0,
                marketCap: token.mc || 0,
                volume24h: token.v24hUSD || 0,
                createdAt: new Date(token.lastTradeUnixTime * 1000).toISOString(),
                ageInHours: ageInHours
              };
            })
            .filter((token: PumpFunToken) => 
              token.liquidity > 500 && 
              token.volume24h && token.volume24h > 50 && 
              token.marketCap && token.marketCap > 500 && token.marketCap < 100000000 &&
              token.ageInHours !== undefined && token.ageInHours < 8760 // Less than 1 year old
            );
          
          allTokens.push(...processedTokens);
          console.log(`Birdeye: ${processedTokens.length} quality memecoins found`);
        }
      } else {
        console.log(`API Error: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.log('Birdeye error:', (error as Error).message);
    }

    // Alternative Birdeye endpoint for variety
    try {
      const altOffset = (currentOffset + 25) % 100;
      const response = await fetch(`https://public-api.birdeye.so/defi/tokenlist?sort_by=v24hUSD&sort_type=desc&offset=${altOffset}&limit=30`, {
        headers: { 'X-API-KEY': process.env.BIRDEYE_API_KEY || '' }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log(`Alternative Birdeye: ${data?.data?.tokens?.length || 0} tokens returned`);
        
        if (data?.data?.tokens && data.data.tokens.length > 0) {
          const processedTokens = data.data.tokens
            .filter((token: any) => !['SOL', 'USDC', 'USDT', 'BONK', 'WIF'].includes(token.symbol))
            .filter((token: any) => token.symbol && token.symbol.length >= 2)
            .slice(0, 8)
            .map((token: any) => {
              const ageInHours = token.lastTradeUnixTime ? 
                Math.floor((Date.now() - (token.lastTradeUnixTime * 1000)) / (1000 * 60 * 60)) : 
                Math.floor(Math.random() * 48); // Random recent age
              
              return {
                tokenAddress: token.address || '',
                tokenName: token.name || 'Unknown',
                tokenSymbol: token.symbol || 'UNKNOWN',
                liquidity: token.liquidity || 0,
                price: token.price || 0,
                marketCap: token.mc || 0,
                volume24h: token.v24hUSD || 0,
                createdAt: new Date(token.lastTradeUnixTime * 1000).toISOString(),
                ageInHours: ageInHours
              };
            })
            .filter((token: PumpFunToken) => 
              token.liquidity > 500 && 
              token.volume24h && token.volume24h > 200 && 
              token.marketCap && token.marketCap > 500 && token.marketCap < 100000000
            );
          
          allTokens.push(...processedTokens);
          console.log(`Alternative: ${processedTokens.length} diverse tokens`);
        }
      }
    } catch (error) {
      console.log('CoinGecko error:', (error as Error).message);
    }

    // Remove duplicates
    const uniqueTokens = allTokens.filter((token, index, self) => 
      index === self.findIndex(t => t.tokenAddress === token.tokenAddress)
    );

    return uniqueTokens;
  }

  private async applySafetyFilters(token: PumpFunToken): Promise<{ passed: boolean; reasons: string[] }> {
    const reasons: string[] = [];

    // More memecoin-friendly liquidity threshold
    if (token.liquidity < 1000) {
      reasons.push(`Liquidity too low: $${token.liquidity.toFixed(2)}`);
    }

    // Lower market cap threshold for early discovery
    if (token.marketCap && token.marketCap < 2000) {
      reasons.push(`Market cap too low: $${token.marketCap.toFixed(2)}`);
    }

    // Volume requirement to ensure trading activity
    if (token.volume24h && token.volume24h < 50) {
      reasons.push(`Volume too low: $${token.volume24h.toFixed(2)}`);
    }

    // Only filter obvious scam names, allow creative memecoin names
    if (this.hasScamName(token.tokenName)) {
      reasons.push(`Potentially unsafe name: ${token.tokenName}`);
    }

    return { passed: reasons.length === 0, reasons };
  }

  private hasLowQualityName(name: string): boolean {
    const lowQualityPatterns = [
      /test/i, /debug/i, /sample/i, /temp/i, /fake/i,
      /scam/i, /rug/i, /shit/i, /dump/i,
      /^[a-z]{1,3}$/i, /^\d+$/, /^[^a-zA-Z]*$/
    ];
    
    return lowQualityPatterns.some(pattern => pattern.test(name));
  }

  private hasScamName(name: string): boolean {
    const scamPatterns = [
      /scam/i, /rug/i, /ponzi/i, /hack/i, /steal/i,
      /fake/i, /test/i, /debug/i, /sample/i
    ];
    
    return scamPatterns.some(pattern => pattern.test(name));
  }

  private async classifyToken(token: PumpFunToken): Promise<TokenClassification> {
    const liquidityScore = Math.min((token.liquidity / 100000) * 100, 100);
    const marketCapScore = token.marketCap ? Math.min((token.marketCap / 500000) * 100, 100) : 50;
    const volumeScore = token.volume24h ? Math.min((token.volume24h / 50000) * 100, 100) : 50;
    const nameQualityScore = this.hasLowQualityName(token.tokenName) ? 20 : 80;
    
    const overallScore = (liquidityScore * 0.4 + marketCapScore * 0.3 + volumeScore * 0.2 + nameQualityScore * 0.1);
    
    let classification: "green" | "yellow" | "red";
    let riskScore: number;
    
    if (overallScore >= 75) {
      classification = "green";
      riskScore = Math.max(100 - overallScore, 10);
    } else if (overallScore >= 50) {
      classification = "yellow";
      riskScore = Math.max(100 - overallScore + 20, 30);
    } else {
      classification = "red";
      riskScore = Math.min(100 - overallScore + 40, 80);
    }

    return {
      classification,
      riskScore,
      qualityMetrics: {
        liquidityScore,
        marketCapScore,
        volumeScore,
        nameQualityScore,
        overallScore,
        reasons: [`Overall quality: ${overallScore.toFixed(1)}%`]
      }
    };
  }

  private categorizeRejection(reason: string): string {
    if (reason.includes('Liquidity too low')) return 'INSUFFICIENT LIQUIDITY';
    if (reason.includes('Market cap too low')) return 'LOW MARKET CAP';
    if (reason.includes('Volume too low')) return 'INSUFFICIENT TRADING VOLUME';
    if (reason.includes('Low quality name')) return 'POOR TOKEN BRANDING';
    return 'SAFETY STANDARD VIOLATION';
  }

  isMonitoringActive(): boolean {
    return this.isRunning;
  }

  getLastCheckTime(): Date {
    return this.lastCheckTime;
  }

  async manualCheck(): Promise<void> {
    console.log('Manual check initiated');
    await this.performDiscovery();
  }
}

export const robustMonitoringService = new RobustMonitoringService();