import { writeFileSync, readFileSync, existsSync } from 'fs';
import { join } from 'path';

interface TradingConfig {
  enabled: boolean;
  maxInvestmentPerToken: number; // SOL amount
  maxConcurrentPositions: number;
  stopLossPercentage: number;
  takeProfitPercentage: number;
  minLiquidity: number;
  maxMarketCap: number;
  slippageTolerance: number;
  walletPrivateKey?: string;
  // Enhanced risk management
  trailingStopEnabled: boolean;
  trailingStopDistance: number; // percentage from peak
  timeBasedExitHours: number; // auto-exit after X hours
  minTokenAgeMinutes: number; // minimum token age before trading
  maxDevWalletPercentage: number; // max single wallet ownership
  minTradeCountPerHour: number; // minimum DEX activity
  tradeCooldownMinutes: number; // cooldown after failed trades
  portfolioRiskPercentage: number; // % of portfolio per trade
}

interface Position {
  tokenAddress: string;
  tokenSymbol: string;
  buyPrice: number;
  buyAmount: number; // SOL spent
  tokensReceived: number;
  timestamp: number;
  stopLoss: number;
  takeProfit: number;
  status: 'active' | 'sold' | 'stopped';
  // Enhanced tracking
  peakPrice: number; // highest price reached
  trailingStopPrice: number; // dynamic trailing stop
  entryTime: number; // entry timestamp
  lastPriceUpdate: number; // last price check
  exitReason?: string; // reason for exit
}

interface TradingData {
  config: TradingConfig;
  positions: Position[];
  totalInvested: number;
  totalRealized: number;
  winRate: number;
  // Enhanced tracking
  blacklist: string[]; // failed tokens to avoid
  lastTradeTime: number; // for cooldown enforcement
  tradingPaused: boolean; // manual pause flag
  portfolioValue: number; // current portfolio value
}

class AutoTrader {
  private dataFile = './data/trading-data.json';

  constructor() {
    this.ensureDataDir();
  }

  private ensureDataDir(): void {
    const dataDir = './data';
    if (!existsSync(dataDir)) {
      const { mkdirSync } = require('fs');
      mkdirSync(dataDir, { recursive: true });
    }
  }

  private loadData(): TradingData {
    try {
      if (existsSync(this.dataFile)) {
        const data = JSON.parse(readFileSync(this.dataFile, 'utf8'));
        return data;
      }
    } catch (error) {
      console.log('Error loading trading data:', (error as Error).message);
    }

    return {
      config: {
        enabled: false,
        maxInvestmentPerToken: 0.1, // 0.1 SOL per token
        maxConcurrentPositions: 5,
        stopLossPercentage: 20,
        takeProfitPercentage: 100,
        minLiquidity: 10000,
        maxMarketCap: 1000000,
        slippageTolerance: 5,
        // Enhanced risk management defaults
        trailingStopEnabled: true,
        trailingStopDistance: 15, // 15% from peak
        timeBasedExitHours: 8, // auto-exit after 8 hours
        minTokenAgeMinutes: 15, // min 15 minutes old
        maxDevWalletPercentage: 20, // max 20% single wallet ownership
        minTradeCountPerHour: 25, // min 25 trades/hour
        tradeCooldownMinutes: 3, // 3 minute cooldown
        portfolioRiskPercentage: 3 // 3% of portfolio per trade
      },
      positions: [],
      totalInvested: 0,
      totalRealized: 0,
      winRate: 0,
      blacklist: [],
      lastTradeTime: 0,
      tradingPaused: false,
      portfolioValue: 1.0 // 1 SOL initial value
    };
  }

  private saveData(data: TradingData): void {
    try {
      writeFileSync(this.dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.log('Error saving trading data:', (error as Error).message);
    }
  }

  async evaluateTokenForPurchase(token: any): Promise<boolean> {
    try {
      const data = this.loadData();
      
      if (!data.config.enabled || data.tradingPaused) return false;

      // Check cooldown period
      const now = Date.now();
      if (now - data.lastTradeTime < data.config.tradeCooldownMinutes * 60000) {
        return false;
      }

      // Check blacklist
      if (data.blacklist.includes(token.address)) {
        return false;
      }

      // Check if we already have a position
      if (data.positions.some(p => p.tokenAddress === token.address && p.status === 'active')) {
        return false;
      }

      // Check position limits
      const activePositions = data.positions.filter(p => p.status === 'active').length;
      if (activePositions >= data.config.maxConcurrentPositions) {
        return false;
      }

      // Enhanced financial filters
      const liquidity = parseFloat(token.liquidity || '0');
      const marketCap = parseFloat(token.marketCap || token.mc || '0');
      const volume24h = parseFloat(token.volume24h || token.v24hUSD || '0');

      // Basic filters
      if (liquidity < data.config.minLiquidity) return false;
      if (marketCap > data.config.maxMarketCap) return false;
      if (volume24h < 1000) return false;

      // Improved liquidity/market cap ratio (tighter band)
      const liquidityRatio = liquidity / marketCap;
      if (liquidityRatio < 0.20 || liquidityRatio > 1.0) return false;

      // Token age filter (simulated for now)
      const tokenAge = Math.floor(Math.random() * 60) + 10; // 10-70 minutes
      if (tokenAge < data.config.minTokenAgeMinutes) {
        console.log(`🕐 Token ${token.symbol} too young: ${tokenAge} minutes`);
        return false;
      }

      console.log(`💰 Token ${token.symbol} passed enhanced filters - preparing to buy`);
      return true;
    } catch (error) {
      console.log(`Error evaluating token: ${(error as Error).message}`);
      return false;
    }
  }

  async executeJupiterBuy(token: any): Promise<boolean> {
    try {
      const data = this.loadData();
      
      console.log(`🚀 Executing Jupiter buy for ${token.symbol}`);
      
      // Get Jupiter quote
      const quoteResponse = await fetch(`https://quote-api.jup.ag/v6/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=${token.address}&amount=${Math.floor(data.config.maxInvestmentPerToken * 1e9)}&slippageBps=${data.config.slippageTolerance * 100}`);
      
      if (!quoteResponse.ok) {
        console.log(`Failed to get Jupiter quote for ${token.symbol}`);
        return false;
      }

      const quote = await quoteResponse.json();
      
      if (!quote.outAmount) {
        console.log(`No quote available for ${token.symbol}`);
        return false;
      }

      // For now, simulate the trade (would need actual wallet integration)
      const tokensReceived = parseFloat(quote.outAmount) / 1e6; // Adjust decimals
      const buyPrice = parseFloat(token.price || '0');
      
      // Calculate position size based on portfolio percentage
      const positionSize = data.config.portfolioRiskPercentage > 0 
        ? (data.portfolioValue * data.config.portfolioRiskPercentage / 100)
        : data.config.maxInvestmentPerToken;

      const position: Position = {
        tokenAddress: token.address,
        tokenSymbol: token.symbol,
        buyPrice,
        buyAmount: positionSize,
        tokensReceived,
        timestamp: Date.now(),
        stopLoss: buyPrice * (1 - data.config.stopLossPercentage / 100),
        takeProfit: buyPrice * (1 + data.config.takeProfitPercentage / 100),
        status: 'active',
        // Enhanced tracking fields
        peakPrice: buyPrice,
        trailingStopPrice: buyPrice * (1 - data.config.stopLossPercentage / 100),
        entryTime: Date.now(),
        lastPriceUpdate: Date.now()
      };

      data.positions.push(position);
      data.totalInvested += positionSize;
      
      this.saveData(data);
      
      console.log(`✅ Bought ${token.symbol} at $${buyPrice.toFixed(8)} (${positionSize} SOL) - Stop: $${position.stopLoss.toFixed(8)} Target: $${position.takeProfit.toFixed(8)}`);
      
      return true;

    } catch (error) {
      console.log(`Trade execution failed for ${token.symbol}:`, (error as Error).message);
      return false;
    }
  }

  async checkPositions(): Promise<void> {
    const data = this.loadData();
    const activePositions = data.positions.filter(p => p.status === 'active');
    
    if (activePositions.length === 0) return;

    console.log(`📊 Checking ${activePositions.length} active positions...`);

    for (const position of activePositions) {
      try {
        // Simulate current price (in real implementation would fetch from API)
        const priceChange = (Math.random() - 0.5) * 0.2; // -10% to +10%
        const currentPrice = position.buyPrice * (1 + priceChange);
        const now = Date.now();

        // Update peak price and trailing stop
        if (currentPrice > position.peakPrice) {
          position.peakPrice = currentPrice;
          if (data.config.trailingStopEnabled) {
            position.trailingStopPrice = position.peakPrice * (1 - data.config.trailingStopDistance / 100);
          }
        }

        position.lastPriceUpdate = now;

        // Check exit conditions
        let shouldExit = false;
        let exitReason = '';

        // Traditional stop-loss check
        if (currentPrice <= position.stopLoss) {
          shouldExit = true;
          exitReason = 'Stop-loss triggered';
        }
        // Trailing stop-loss check
        else if (data.config.trailingStopEnabled && currentPrice <= position.trailingStopPrice) {
          shouldExit = true;
          exitReason = 'Trailing stop triggered';
        }
        // Take-profit check
        else if (currentPrice >= position.takeProfit) {
          shouldExit = true;
          exitReason = 'Take-profit reached';
        }
        // Time-based exit check
        else if ((now - position.entryTime) > (data.config.timeBasedExitHours * 3600000)) {
          shouldExit = true;
          exitReason = 'Time-based exit';
        }

        if (shouldExit) {
          await this.executeSell(position, currentPrice, exitReason);
        } else {
          const pnlPercent = ((currentPrice - position.buyPrice) / position.buyPrice * 100);
          console.log(`📈 ${position.tokenSymbol}: $${currentPrice.toFixed(8)} (${pnlPercent > 0 ? '+' : ''}${pnlPercent.toFixed(2)}%)`);
        }

        const response = await fetch(`https://public-api.birdeye.so/defi/price?address=${position.tokenAddress}`, {
          headers: { 'X-API-KEY': birdeyeApiKey }
        });

        if (!response.ok) continue;

        const priceData = await response.json();
        const currentPrice = parseFloat(priceData.data?.value || '0');
        
        if (currentPrice <= 0) continue;

        const gainPercent = ((currentPrice - position.buyPrice) / position.buyPrice) * 100;
        
        // Check stop loss
        if (currentPrice <= position.stopLoss) {
          await this.executeSell(position, currentPrice, 'stop_loss');
          console.log(`🔴 Stop loss triggered for ${position.tokenSymbol} at ${gainPercent.toFixed(2)}%`);
        }
        // Check take profit
        else if (currentPrice >= position.takeProfit) {
          await this.executeSell(position, currentPrice, 'take_profit');
          console.log(`🟢 Take profit triggered for ${position.tokenSymbol} at ${gainPercent.toFixed(2)}%`);
        }
        // Update trailing stop (optional enhancement)
        else {
          console.log(`📈 ${position.tokenSymbol}: ${gainPercent.toFixed(2)}% (${currentPrice.toFixed(8)})`);
        }

      } catch (error) {
        console.log(`Position check failed for ${position.tokenSymbol}:`, (error as Error).message);
      }
    }
    
    this.saveData(data);
  }

  private async executeSell(position: Position, sellPrice: number, reason: string): Promise<void> {
    // Simulate sell execution
    const soldValue = position.tokensReceived * sellPrice / 1e6; // Adjust for decimals
    const pnl = soldValue - position.buyAmount;
    
    position.status = 'sold';
    
    const data = this.loadData();
    data.totalRealized += pnl;
    
    // Update win rate
    const closedPositions = data.positions.filter(p => p.status === 'sold');
    const wins = closedPositions.filter(p => {
      const soldVal = p.tokensReceived * sellPrice / 1e6;
      return soldVal > p.buyAmount;
    }).length;
    data.winRate = (wins / closedPositions.length) * 100;
    
    console.log(`💸 Sold ${position.tokenSymbol} - PnL: ${pnl > 0 ? '+' : ''}${pnl.toFixed(4)} SOL (${reason})`);
  }

  getTradingStatus(): any {
    const data = this.loadData();
    const activePositions = data.positions.filter(p => p.status === 'active');
    
    return {
      enabled: data.config.enabled,
      activePositions: activePositions.length,
      totalInvested: data.totalInvested,
      totalRealized: data.totalRealized,
      winRate: data.winRate.toFixed(1),
      config: data.config
    };
  }

  updateConfig(newConfig: Partial<TradingConfig>): void {
    const data = this.loadData();
    data.config = { ...data.config, ...newConfig };
    this.saveData(data);
  }
}

export const autoTrader = new AutoTrader();