import { storage } from './storage';
import { telegramService } from './telegram-singleton';
import { PumpFunToken, TokenClassification } from './monitoring';

interface QueuedToken {
  token: PumpFunToken;
  classification: TokenClassification;
  discoveryTime: Date;
  queuedAt: Date;
}

class PostingService {
  private postingInterval: NodeJS.Timeout | null = null;
  private isActive = false;
  private adaptiveInterval = 45000; // 45 seconds for consistent posting
  private lastPostTime = 0;

  async start(): Promise<void> {
    if (this.isActive) return;
    
    this.isActive = true;
    console.log('🚀 Starting dedicated posting service');
    
    // Start continuous posting loop
    this.startPostingLoop();
  }

  async stop(): Promise<void> {
    this.isActive = false;
    if (this.postingInterval) {
      clearTimeout(this.postingInterval);
      this.postingInterval = null;
    }
  }

  private startPostingLoop(): void {
    const processQueue = async () => {
      if (!this.isActive) return;

      try {
        // Get queued tokens from storage
        const queuedTokens = await this.getQueuedTokens();
        
        if (queuedTokens.length === 0) {
          // No tokens to post, check again in 30 seconds
          this.scheduleNext(30000);
          return;
        }

        const config = await storage.getBotConfiguration();
        if (!config?.isActive || !config.telegramToken || !config.channelId) {
          this.scheduleNext(60000);
          return;
        }

        // Get the highest priority token
        const tokenToPost = this.selectNextToken(queuedTokens);
        if (!tokenToPost) {
          this.scheduleNext(30000);
          return;
        }

        // Post the token
        const success = await this.postToken(tokenToPost, config);
        
        if (success) {
          await this.removeFromQueue(tokenToPost.token.tokenAddress);
          this.lastPostTime = Date.now();
          console.log(`📤 Posted ${tokenToPost.token.tokenSymbol} - ${queuedTokens.length - 1} remaining`);
        }

        // Schedule next posting
        this.scheduleNext(this.adaptiveInterval);

      } catch (error) {
        console.log('Posting service error:', (error as Error).message);
        this.scheduleNext(60000); // Retry in 1 minute on error
      }
    };

    // Start the loop
    processQueue();
  }

  private scheduleNext(delay: number): void {
    if (this.isActive) {
      this.postingInterval = setTimeout(() => {
        console.log('⏰ Posting timer triggered');
        this.processNextToken();
      }, delay);
    }
  }

  private async processNextToken(): Promise<void> {
    try {
      // Get queued tokens from storage
      const queuedTokens = await this.getQueuedTokens();
      
      if (queuedTokens.length === 0) {
        // No tokens to post, check again in 30 seconds
        this.scheduleNext(30000);
        return;
      }

      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.telegramToken || !config.channelId) {
        this.scheduleNext(60000);
        return;
      }

      // Get the highest priority token
      const tokenToPost = this.selectNextToken(queuedTokens);
      if (!tokenToPost) {
        this.scheduleNext(30000);
        return;
      }

      // Post the token
      const success = await this.postToken(tokenToPost, config);
      
      if (success) {
        await this.removeFromQueue(tokenToPost.token.tokenAddress);
        this.lastPostTime = Date.now();
        console.log(`📤 Posted ${tokenToPost.token.tokenSymbol} - ${queuedTokens.length - 1} remaining`);
      }

      // Schedule next posting with consistent 45-second interval
      this.scheduleNext(45000);

    } catch (error) {
      console.log('Posting service error:', (error as Error).message);
      this.scheduleNext(60000); // Retry in 1 minute on error
    }
  }

  private async getQueuedTokens(): Promise<QueuedToken[]> {
    try {
      // Get all unposted tokens from storage
      const allTokens = await storage.getUnpostedTokens();
      
      return allTokens
        .filter((token: any) => !token.posted && token.classification !== 'rejected')
        .map((token: any) => ({
          token: {
            tokenAddress: token.tokenAddress,
            tokenName: token.tokenName,
            tokenSymbol: token.tokenSymbol,
            liquidity: parseFloat(token.liquidity),
            price: parseFloat(token.price),
            marketCap: 0,
            volume24h: 0
          } as PumpFunToken,
          classification: {
            classification: token.classification as any,
            riskScore: token.riskScore,
            qualityMetrics: JSON.parse(token.qualityMetrics || '{}')
          } as TokenClassification,
          discoveryTime: token.createdAt,
          queuedAt: token.createdAt
        }))
        .sort((a: any, b: any) => a.queuedAt.getTime() - b.queuedAt.getTime()); // FIFO order
    } catch (error) {
      console.log('Error getting queued tokens:', (error as Error).message);
      return [];
    }
  }

  private selectNextToken(tokens: QueuedToken[]): QueuedToken | null {
    if (tokens.length === 0) return null;

    // Priority: green > yellow > red, then by queue time (FIFO)
    const priorityMap = { green: 3, yellow: 2, red: 1 };
    
    return tokens.sort((a, b) => {
      const aPriority = priorityMap[a.classification.classification as keyof typeof priorityMap] || 0;
      const bPriority = priorityMap[b.classification.classification as keyof typeof priorityMap] || 0;
      
      if (aPriority !== bPriority) return bPriority - aPriority;
      return a.queuedAt.getTime() - b.queuedAt.getTime();
    })[0];
  }

  private async postToken(queuedToken: QueuedToken, config: any): Promise<boolean> {
    const { token, classification, discoveryTime } = queuedToken;
    
    try {
      const marketCap = token.marketCap ? `$${(token.marketCap / 1000000).toFixed(2)}M` : 'N/A';
      const volume24h = token.volume24h ? `$${(token.volume24h / 1000).toFixed(0)}K` : 'N/A';
      const timeSinceDiscovery = Math.floor((Date.now() - discoveryTime.getTime()) / 60000);
      
      const success = await telegramService.sendTokenMessage(config.channelId, {
        tokenName: token.tokenName,
        tokenSymbol: token.tokenSymbol,
        tokenAddress: token.tokenAddress,
        liquidity: `$${(token.liquidity / 1000).toFixed(0)}K`,
        price: `$${token.price.toFixed(8)}`,
        classification: classification.classification,
        riskScore: classification.riskScore,
        qualityMetrics: JSON.stringify({
          ...classification.qualityMetrics,
          marketCap,
          volume24h,
          timeSinceDiscovery: `${timeSinceDiscovery}m ago`
        }),
        source: 'Birdeye Intelligence + Social Analytics',
        createdAt: token.createdAt
      });

      if (success) {
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${token.tokenSymbol} with ${classification.classification} rating`,
          status: 'success'
        });
      }

      return success;
    } catch (error) {
      console.log(`Error posting token ${token.tokenSymbol}:`, (error as Error).message);
      return false;
    }
  }

  private async removeFromQueue(tokenAddress: string): Promise<void> {
    try {
      await storage.markTokenAsPosted(tokenAddress);
    } catch (error) {
      console.log('Error removing token from queue:', (error as Error).message);
    }
  }

  isPosting(): boolean {
    return this.isActive;
  }

  getStatus(): { active: boolean, lastPost: number, interval: number } {
    return {
      active: this.isActive,
      lastPost: this.lastPostTime,
      interval: this.adaptiveInterval
    };
  }
}

export const postingService = new PostingService();