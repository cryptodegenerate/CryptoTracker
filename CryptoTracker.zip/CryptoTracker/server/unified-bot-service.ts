import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { storage } from './storage';
import { telegramService } from './telegram-singleton';

interface BotState {
  lastPostTime: number;
  lastDiscoveryTime: number;
  tokens: Array<{
    address: string;
    name: string;
    symbol: string;
    liquidity: string;
    price: string;
    classification: string;
    riskScore: number;
    ageInHours?: number;
    marketCap?: string;
    volume24h?: string;
    queuedAt: number;
    posted: boolean;
  }>;
}

class UnifiedBotService {
  private dataDir = './data';
  private stateFile = join(this.dataDir, 'bot-state.json');
  private intervalId: NodeJS.Timeout | null = null;
  private isRunning = false;

  constructor() {
    this.ensureDataDir();
  }

  private ensureDataDir(): void {
    if (!existsSync(this.dataDir)) {
      mkdirSync(this.dataDir, { recursive: true });
    }
  }

  start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    
    console.log('🤖 Starting unified bot service');
    
    // Run main loop every 30 seconds
    this.intervalId = setInterval(() => {
      this.mainLoop().catch(err => 
        console.log('Bot loop error:', err.message)
      );
    }, 30000);
    
    // Initial run
    setTimeout(() => this.mainLoop(), 2000);
  }

  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    console.log('🤖 Unified bot service stopped');
  }

  private async mainLoop(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive) return;

      const state = this.loadState();
      const now = Date.now();

      // Check if we should discover new tokens (every 5 minutes)
      if (now - state.lastDiscoveryTime > 300000) {
        await this.performDiscovery(state);
        state.lastDiscoveryTime = now;
        this.saveState(state);
      }

      // Check if we should post a token (every 45 seconds)
      if (now - state.lastPostTime > 45000) {
        const posted = await this.tryPostNext(state, config);
        if (posted) {
          state.lastPostTime = now;
          this.saveState(state);
        }
      }

    } catch (error) {
      console.log('Main loop error:', (error as Error).message);
    }
  }

  private loadState(): BotState {
    try {
      if (existsSync(this.stateFile)) {
        const data = readFileSync(this.stateFile, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.log('Error loading state:', (error as Error).message);
    }

    return {
      lastPostTime: Date.now() - 50000,
      lastDiscoveryTime: Date.now() - 400000,
      tokens: []
    };
  }

  private saveState(state: BotState): void {
    try {
      writeFileSync(this.stateFile, JSON.stringify(state, null, 2));
    } catch (error) {
      console.log('Error saving state:', (error as Error).message);
    }
  }

  private async performDiscovery(state: BotState): Promise<void> {
    try {
      console.log('🔍 Discovering new tokens...');
      
      const birdeyeApiKey = process.env.BIRDEYE_API_KEY;
      if (!birdeyeApiKey) return;

      const response = await fetch(`https://public-api.birdeye.so/defi/tokenlist?sort_by=v24hChangePercent&sort_type=desc&offset=0&limit=50`, {
        headers: { 'X-API-KEY': birdeyeApiKey }
      });

      if (!response.ok) return;

      const data = await response.json();
      const tokens = data.data?.tokens || [];

      let newTokens = 0;
      for (const token of tokens.slice(0, 10)) {
        if (this.passesFilters(token) && !this.tokenExists(state, token.address)) {
          this.addToken(state, token);
          newTokens++;
        }
      }

      if (newTokens > 0) {
        console.log(`✅ Added ${newTokens} new tokens to queue`);
      }

    } catch (error) {
      console.log('Discovery error:', (error as Error).message);
    }
  }

  private passesFilters(token: any): boolean {
    const liquidity = parseFloat(token.liquidity || '0');
    const volume = parseFloat(token.v24hUSD || '0');
    const marketCap = parseFloat(token.mc || '0');

    return liquidity >= 5000 && // $5K minimum liquidity
           volume >= 0 && // Any volume
           marketCap >= 1000 && // $1K minimum market cap
           marketCap <= 100000000 && // $100M maximum market cap
           token.symbol && 
           token.name &&
           token.address;
  }

  private tokenExists(state: BotState, address: string): boolean {
    return state.tokens.some(t => t.address === address);
  }

  private addToken(state: BotState, token: any): void {
    const ageInHours = this.calculateTokenAge(token);
    
    state.tokens.push({
      address: token.address,
      name: token.name,
      symbol: token.symbol,
      liquidity: token.liquidity?.toString() || '0',
      price: token.price?.toString() || '0',
      classification: 'yellow',
      riskScore: 50,
      ageInHours,
      marketCap: token.mc?.toString(),
      volume24h: token.v24hUSD?.toString(),
      queuedAt: Date.now(),
      posted: false
    });
  }

  private calculateTokenAge(token: any): number {
    if (!token.lastTradeUnixTime) return 0;
    const ageMs = Date.now() - (token.lastTradeUnixTime * 1000);
    return Math.floor(ageMs / (1000 * 60 * 60)); // Convert to hours
  }

  private async tryPostNext(state: BotState, config: any): Promise<boolean> {
    const unpostedTokens = state.tokens.filter(t => !t.posted);
    if (unpostedTokens.length === 0) return false;

    const token = unpostedTokens[0];
    console.log(`📤 Posting: ${token.symbol}`);

    const success = await this.postToken(token, config);
    if (success) {
      token.posted = true;
      const remaining = unpostedTokens.length - 1;
      console.log(`✅ Posted ${token.symbol} - ${remaining} remaining`);
      
      await storage.createActivityLog({
        type: 'token_post',
        message: `Posted ${token.symbol}`,
        status: 'success'
      });
      
      return true;
    }
    
    return false;
  }

  private async postToken(token: any, config: any): Promise<boolean> {
    try {
      const liquidity = parseFloat(token.liquidity) || 0;
      const marketCap = token.marketCap ? parseFloat(token.marketCap) : null;
      const volume = token.volume24h ? parseFloat(token.volume24h) : null;
      const ageFormatted = token.ageInHours ? `${token.ageInHours}h` : 'Unknown';

      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${token.name}** (${token.symbol})

📊 **Market Data:**
💰 Liquidity: $${liquidity.toLocaleString()}
💵 Market Cap: ${marketCap ? `$${marketCap.toLocaleString()}` : 'N/A'}
📈 24h Volume: ${volume ? `$${volume.toLocaleString()}` : 'N/A'}
⏰ Age: ${ageFormatted}

🔗 **Contract:** \`${token.address}\`

🟡 Risk Level: MODERATE
📊 Quality Score: 65%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      return true;
    } catch (error) {
      console.log('Posting failed:', (error as Error).message);
      return false;
    }
  }

  getStatus(): {
    running: boolean;
    queueSize: number;
    lastPost: number;
    nextPostIn: number;
    lastDiscovery: number;
  } {
    const state = this.loadState();
    const now = Date.now();
    const unpostedCount = state.tokens.filter(t => !t.posted).length;
    const nextPostIn = Math.max(0, 45000 - (now - state.lastPostTime));

    return {
      running: this.isRunning,
      queueSize: unpostedCount,
      lastPost: state.lastPostTime,
      nextPostIn,
      lastDiscovery: state.lastDiscoveryTime
    };
  }
}

export const unifiedBotService = new UnifiedBotService();