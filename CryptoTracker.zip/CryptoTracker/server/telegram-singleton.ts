import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';

export interface TelegramMessage {
  tokenName: string;
  tokenSymbol: string;
  tokenAddress: string;
  liquidity: string;
  price: string;
  classification?: "green" | "yellow" | "red";
  riskScore?: number;
  qualityMetrics?: string;
  source?: string;
  createdAt?: string;
}

class TelegramBotSingleton {
  private static instance: TelegramBotSingleton;
  private bot: TelegramBot | null = null;
  private isConnected = false;
  private currentToken: string | null = null;

  private constructor() {}

  static getInstance(): TelegramBotSingleton {
    if (!TelegramBotSingleton.instance) {
      TelegramBotSingleton.instance = new TelegramBotSingleton();
    }
    return TelegramBotSingleton.instance;
  }

  async initialize(token: string): Promise<boolean> {
    // Don't reinitialize if already connected with same token
    if (this.isConnected && this.currentToken === token && this.bot) {
      return true;
    }

    try {
      // Clean up existing connection
      await this.cleanup();

      this.bot = new TelegramBot(token, { 
        polling: {
          interval: 2000,
          autoStart: true,
          params: {
            timeout: 10
          }
        }
      });
      
      await this.bot.getMe();
      this.isConnected = true;
      this.currentToken = token;
      
      this.setupCommands();
      
      await storage.createActivityLog({
        type: 'bot_start',
        message: 'Telegram bot connected successfully with command interface',
        status: 'success',
      });
      
      return true;
    } catch (error) {
      this.isConnected = false;
      this.currentToken = null;
      await storage.createActivityLog({
        type: 'bot_start',
        message: 'Failed to connect to Telegram bot',
        status: 'error',
        details: JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      });
      throw error;
    }
  }

  private setupCommands(): void {
    if (!this.bot) return;

    this.bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      this.bot?.sendMessage(chatId, 'Welcome to the Solana Token Monitor Bot! 🚀\n\nThis bot monitors new Solana tokens and provides real-time updates.');
    });

    this.bot.onText(/\/status/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const stats = await storage.getBotStats();
        const message = `📊 Bot Status:\n\nTotal Posts: ${stats?.totalPosts || 0}\nToday: ${stats?.todayPosts || 0}\nThis Week: ${stats?.weekPosts || 0}\n\n✅ Monitoring Active`;
        this.bot?.sendMessage(chatId, message);
      } catch (error) {
        this.bot?.sendMessage(chatId, 'Error retrieving status information.');
      }
    });
  }

  async sendTokenMessage(channelId: string, tokenData: TelegramMessage): Promise<boolean> {
    if (!this.bot || !this.isConnected) {
      throw new Error('Bot not initialized or connected');
    }

    const getClassificationEmoji = (classification?: string) => {
      switch (classification) {
        case 'green': return '🟢';
        case 'yellow': return '🟡';
        case 'red': return '🔴';
        default: return '⚪';
      }
    };

    const getClassificationLabel = (classification?: string) => {
      switch (classification) {
        case 'green': return 'LOW RISK';
        case 'yellow': return 'MODERATE RISK';
        case 'red': return 'HIGH RISK';
        default: return 'UNCLASSIFIED';
      }
    };

    const riskInfo = tokenData.classification ? 
      `\n${getClassificationEmoji(tokenData.classification)} Risk Level: ${getClassificationLabel(tokenData.classification)}
⚠️ Risk Score: ${tokenData.riskScore}/100` : '';

    const sourceInfo = tokenData.source ? `\n🔍 Source: ${tokenData.source}` : '';
    
    const creationInfo = tokenData.createdAt ? 
      `\n🕐 Created: ${new Date(tokenData.createdAt).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'UTC'
      })} UTC` : '';

    // Add safety filters section
    const safetyFilters = this.formatSafetyFilters(tokenData.qualityMetrics);

    const message = `🚀 **NEW TOKEN DISCOVERED**

💎 **${tokenData.tokenSymbol}** - ${tokenData.tokenName}
📍 Address: \`${tokenData.tokenAddress}\`
💰 Liquidity: ${tokenData.liquidity}
💵 Price: ${tokenData.price}${riskInfo}${sourceInfo}${creationInfo}${safetyFilters}

📈 Trade: https://jup.ag/swap/SOL-${tokenData.tokenAddress}
📊 Chart: https://dexscreener.com/solana/${tokenData.tokenAddress}`;

    try {
      await this.bot.sendMessage(channelId, message, { 
        parse_mode: 'Markdown',
        disable_web_page_preview: true 
      });
      return true;
    } catch (error) {
      console.error('Error sending token message:', error);
      throw error;
    }
  }

  async sendMessage(channelId: string, message: string): Promise<boolean> {
    if (!this.bot || !this.isConnected) {
      throw new Error('Bot not initialized or connected');
    }

    try {
      await this.bot.sendMessage(channelId, message, {
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      });
      
      await storage.createActivityLog({
        type: 'manual_post',
        message: `Manual message sent to ${channelId}`,
        status: 'success',
        details: JSON.stringify({ message }),
      });
      
      return true;
    } catch (error) {
      console.error('Telegram sendMessage error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      await storage.createActivityLog({
        type: 'manual_post',
        message: `Failed to send manual message to ${channelId}: ${errorMessage}`,
        status: 'error',
        details: JSON.stringify({ error: errorMessage, message, channelId }),
      });
      throw new Error(`Telegram error: ${errorMessage}`);
    }
  }

  isConnectedToTelegram(): boolean {
    return this.isConnected;
  }

  private formatSafetyFilters(qualityMetrics?: string): string {
    if (!qualityMetrics) return '';
    
    try {
      const metrics = JSON.parse(qualityMetrics);
      const reasons = metrics.reasons || [];
      
      let safetySection = '\n\n🔒 **SAFETY ANALYSIS:**\n';
      
      // Parse filter results from reasons and metrics
      const liquidityScore = metrics.liquidityScore || 0;
      const volumeScore = metrics.volumeScore || 0;
      const marketCapScore = metrics.marketCapScore || 0;
      const nameQualityScore = metrics.nameQualityScore || 0;
      const tokenAge = metrics.tokenAge || 'Unknown';
      
      // Safety filter assessments
      safetySection += `✅ Liquidity Safety: ${liquidityScore}/100\n`;
      safetySection += `📊 Volume Activity: ${volumeScore}/100\n`;
      safetySection += `💰 Market Cap Score: ${marketCapScore}/100\n`;
      safetySection += `🏷️ Name Quality: ${nameQualityScore}/100\n`;
      safetySection += `⏰ Token Age: ${tokenAge}\n`;
      
      // Add advanced safety checks
      if (metrics.socialScore) {
        safetySection += `👥 Social Score: ${metrics.socialScore}/100\n`;
      }
      
      if (metrics.communityStrength) {
        safetySection += `🎯 Community: ${metrics.communityStrength}\n`;
      }
      
      if (metrics.sentimentScore) {
        safetySection += `📈 Sentiment: ${metrics.sentimentScore}/100\n`;
      }
      
      return safetySection;
    } catch (error) {
      return '\n\n🔒 **SAFETY ANALYSIS:** Assessment in progress...';
    }
  }

  private async cleanup(): Promise<void> {
    if (this.bot) {
      try {
        await this.bot.stopPolling();
        this.bot.removeAllListeners();
      } catch (error) {
        // Ignore cleanup errors
      }
      this.bot = null;
      this.isConnected = false;
      this.currentToken = null;
    }
  }

  async testConnection(token: string): Promise<boolean> {
    try {
      const testBot = new TelegramBot(token, { polling: false });
      await testBot.getMe();
      return true;
    } catch (error) {
      return false;
    }
  }

  async sendManualMessage(channelId: string, message: string): Promise<boolean> {
    return this.sendMessage(channelId, message);
  }

  async disconnect(): Promise<void> {
    await this.cleanup();
  }
}

export const telegramService = TelegramBotSingleton.getInstance();