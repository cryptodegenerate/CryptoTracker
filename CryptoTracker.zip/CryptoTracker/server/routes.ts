import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { telegramService } from "./telegram-singleton";
import { robustMonitoringService as monitoringService } from "./robust-monitor";
import { insertBotConfigurationSchema, insertActivityLogSchema } from "@shared/schema";
import { z } from "zod";
import { tradingRouter } from "./trading-routes";
import { setupAdvancedRoutes } from "./advanced-routes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get bot configuration
  app.get("/api/config", async (req, res) => {
    try {
      const config = await storage.getBotConfiguration();
      if (!config) {
        return res.json({ 
          telegramToken: "", 
          channelId: "", 
          monitoringInterval: 5, 
          maxTokens: 10, 
          isActive: false 
        });
      }
      
      // Don't send the full token for security
      const safeConfig = {
        ...config,
        telegramToken: config.telegramToken ? "***" + config.telegramToken.slice(-4) : "",
      };
      
      res.json(safeConfig);
    } catch (error) {
      res.status(500).json({ message: "Failed to get configuration" });
    }
  });

  // Save bot configuration
  app.post("/api/config", async (req, res) => {
    try {
      const configData = insertBotConfigurationSchema.parse(req.body);
      
      // Test Telegram connection if token is provided
      if (configData.telegramToken) {
        const isValid = await telegramService.testConnection(configData.telegramToken);
        if (!isValid) {
          return res.status(400).json({ message: "Invalid Telegram bot token" });
        }
      }
      
      const config = await storage.createOrUpdateBotConfiguration(configData);
      
      await storage.createActivityLog({
        type: 'config_update',
        message: 'Bot configuration updated',
        status: 'success',
      });
      
      res.json({ message: "Configuration saved successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid configuration data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save configuration" });
    }
  });

  // Test Telegram connection
  app.post("/api/test-connection", async (req, res) => {
    try {
      const { telegramToken, channelId } = req.body;
      
      if (!telegramToken) {
        return res.status(400).json({ message: "Telegram token is required" });
      }
      
      const isValid = await telegramService.testConnection(telegramToken);
      if (!isValid) {
        return res.status(400).json({ message: "Invalid Telegram bot token" });
      }
      
      res.json({ message: "Connection test successful" });
    } catch (error) {
      res.status(400).json({ message: "Connection test failed" });
    }
  });

  // Send manual message
  app.post("/api/send-message", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      const config = await storage.getBotConfiguration();
      if (!config || !config.telegramToken || !config.channelId) {
        return res.status(400).json({ message: "Bot not configured" });
      }
      
      // Initialize Telegram service if not already connected
      if (!telegramService.isConnectedToTelegram()) {
        await telegramService.initialize(config.telegramToken);
      }
      
      await telegramService.sendManualMessage(config.channelId, message);
      
      res.json({ message: "Message sent successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Start bot monitoring
  app.post("/api/start-bot", async (req, res) => {
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.telegramToken || !config.channelId) {
        return res.status(400).json({ message: "Bot not configured" });
      }
      
      // Initialize Telegram service
      await telegramService.initialize(config.telegramToken);
      
      // Update config to active
      await storage.createOrUpdateBotConfiguration({ ...config, isActive: true });
      
      // Start monitoring
      await monitoringService.start();
      
      res.json({ message: "Bot started successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start bot" });
    }
  });

  // Stop bot monitoring
  app.post("/api/stop-bot", async (req, res) => {
    try {
      await monitoringService.stop();
      telegramService.disconnect();
      
      const config = await storage.getBotConfiguration();
      if (config) {
        await storage.createOrUpdateBotConfiguration({ ...config, isActive: false });
      }
      
      res.json({ message: "Bot stopped successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop bot" });
    }
  });

  // Test classification system with multiple sample tokens
  app.post("/api/test-classification", async (req, res) => {
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.telegramToken || !config.channelId) {
        return res.status(400).json({ message: "Bot not configured" });
      }

      // Initialize Telegram service if not connected
      if (!telegramService.isConnectedToTelegram()) {
        await telegramService.initialize(config.telegramToken);
      }

      // Create sample tokens with different risk classifications
      const sampleTokens = [
        {
          tokenAddress: "GREEN" + Date.now(),
          tokenName: "SafeToken",
          tokenSymbol: "SAFE",
          liquidity: "150000",
          price: "0.025",
          classification: "green" as const,
          riskScore: 15,
          qualityMetrics: JSON.stringify({
            liquidityScore: 100,
            marketCapScore: 85,
            volumeScore: 90,
            nameQualityScore: 95,
            overallScore: 92,
            reasons: ["High quality token with strong fundamentals", "Excellent liquidity levels", "Professional naming convention"]
          })
        },
        {
          tokenAddress: "YELLOW" + Date.now(),
          tokenName: "TestCoin",
          tokenSymbol: "TEST",
          liquidity: "25000",
          price: "0.000123",
          classification: "yellow" as const,
          riskScore: 65,
          qualityMetrics: JSON.stringify({
            liquidityScore: 70,
            marketCapScore: 60,
            volumeScore: 50,
            nameQualityScore: 80,
            overallScore: 65,
            reasons: ["Moderate risk token requiring careful evaluation", "Adequate liquidity levels"]
          })
        },
        {
          tokenAddress: "RED" + Date.now(),
          tokenName: "🚀MoonShot💎",
          tokenSymbol: "MOON",
          liquidity: "2500",
          price: "0.000001",
          classification: "red" as const,
          riskScore: 95,
          qualityMetrics: JSON.stringify({
            liquidityScore: 10,
            marketCapScore: 15,
            volumeScore: 20,
            nameQualityScore: 25,
            overallScore: 17,
            reasons: ["High risk token with concerning metrics", "Low liquidity warning", "Small market cap", "Suspicious token name"]
          })
        }
      ];

      for (const token of sampleTokens) {
        // Store the sample token
        await storage.createTokenPost(token);

        // Send to Telegram with classification
        await telegramService.sendTokenMessage(config.channelId, {
          tokenName: token.tokenName,
          tokenSymbol: token.tokenSymbol,
          tokenAddress: token.tokenAddress,
          liquidity: token.liquidity,
          price: token.price,
          classification: token.classification,
          riskScore: token.riskScore,
          qualityMetrics: token.qualityMetrics
        });

        // Small delay between messages
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      res.json({ message: "Classification system tested with 3 sample tokens (Green, Yellow, Red)" });
    } catch (error) {
      console.error('Test classification error:', error);
      res.status(500).json({ message: "Failed to test classification system" });
    }
  });

  // Get all tokens (posted and unposted)
  app.get("/api/tokens", async (req, res) => {
    try {
      const allTokens = await storage.getAllStoredTokens();
      res.json(allTokens);
    } catch (error) {
      res.status(500).json({ message: "Failed to get tokens" });
    }
  });

  // Get only unposted tokens
  app.get("/api/tokens/unposted", async (req, res) => {
    try {
      const tokens = await storage.getUnpostedTokens();
      res.json(tokens);
    } catch (error) {
      res.status(500).json({ message: "Failed to get unposted tokens" });
    }
  });

  // Get bot status
  app.get("/api/status", async (req, res) => {
    try {
      const config = await storage.getBotConfiguration();
      const isMonitoring = monitoringService.isMonitoringActive();
      const isTelegramConnected = telegramService.isConnectedToTelegram();
      const lastCheckTime = monitoringService.getLastCheckTime();
      
      res.json({
        isMonitoring: isMonitoring || false,
        isTelegramConnected: isTelegramConnected || false,
        isConfigured: !!(config?.telegramToken && config?.channelId),
        lastCheckTime: lastCheckTime ? lastCheckTime.toISOString() : new Date().toISOString(),
        isActive: config?.isActive || false,
      });
    } catch (error) {
      console.error('Status endpoint error:', error);
      // Provide default values instead of error
      res.json({
        isMonitoring: false,
        isTelegramConnected: false,
        isConfigured: false,
        lastCheckTime: new Date().toISOString(),
        isActive: false,
      });
    }
  });

  // Manual token check
  app.post("/api/check-tokens", async (req, res) => {
    try {
      await monitoringService.manualCheck();
      res.json({ message: "Token check completed" });
    } catch (error) {
      res.status(500).json({ message: "Failed to check tokens" });
    }
  });

  // Manual check endpoint (alternative)
  app.post("/api/manual-check", async (req, res) => {
    try {
      await monitoringService.manualCheck();
      res.json({ message: "Manual check completed" });
    } catch (error) {
      res.status(500).json({ message: "Failed to perform manual check" });
    }
  });

  // Manual search trigger
  app.post("/api/manual-search", async (req, res) => {
    try {
      const config = await storage.getBotConfiguration();
      if (!config || !config.telegramToken || !config.channelId) {
        return res.status(400).json({ message: "Bot not configured" });
      }

      // Initialize Telegram service if not connected
      if (!telegramService.isConnectedToTelegram()) {
        await telegramService.initialize(config.telegramToken);
      }

      // Send search initiation message
      await telegramService.sendManualMessage(config.channelId, 
        "🔍 Manual search initiated! Scanning pump.fun and DexScreener for new discoveries...");

      // Perform manual check
      await monitoringService.manualCheck();

      await storage.createActivityLog({
        type: 'manual_search',
        message: 'Manual search triggered via web interface',
        status: 'success',
      });

      res.json({ message: "Manual search completed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to perform manual search" });
    }
  });

  // Get activity logs
  app.get("/api/activity", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const logs = await storage.getActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get activity logs" });
    }
  });

  // Clear activity logs
  app.delete("/api/activity", async (req, res) => {
    try {
      await storage.clearActivityLogs();
      res.json({ message: "Activity logs cleared" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear activity logs" });
    }
  });

  // Get bot statistics
  app.get("/api/stats", async (req, res) => {
    try {
      let stats = await storage.getBotStats();
      if (!stats) {
        stats = await storage.createOrUpdateBotStats({});
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get statistics" });
    }
  });

  // Leaderboard endpoints
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const sortBy = req.query.sortBy as string || "performanceScore";
      const leaderboard = await storage.getLeaderboard(limit, sortBy);
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to get leaderboard" });
    }
  });

  app.get("/api/leaderboard/top-performers", async (req, res) => {
    try {
      const timeframe = req.query.timeframe as string || "24h";
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const topPerformers = await storage.getTopPerformers(timeframe, limit);
      res.json(topPerformers);
    } catch (error) {
      res.status(500).json({ message: "Failed to get top performers" });
    }
  });

  app.get("/api/leaderboard/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const entry = await storage.getLeaderboardEntry(tokenAddress);
      if (!entry) {
        return res.status(404).json({ message: "Token not found in leaderboard" });
      }
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Failed to get leaderboard entry" });
    }
  });

  // User scores endpoints
  app.get("/api/users/leaderboard", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const userLeaderboard = await storage.getUserLeaderboard(limit);
      res.json(userLeaderboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user leaderboard" });
    }
  });

  app.get("/api/users/:userId/score", async (req, res) => {
    try {
      const { userId } = req.params;
      let userScore = await storage.getUserScore(userId);
      if (!userScore) {
        userScore = await storage.createOrUpdateUserScore({ 
          userId, 
          tier: "bronze" as const 
        });
      }
      res.json(userScore);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user score" });
    }
  });

  app.post("/api/users/:userId/points", async (req, res) => {
    try {
      const { userId } = req.params;
      const { points } = req.body;
      if (typeof points !== 'number') {
        return res.status(400).json({ message: "Invalid points value" });
      }
      await storage.updateUserPoints(userId, points);
      res.json({ message: "Points updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update user points" });
    }
  });

  // Achievement endpoints
  app.get("/api/achievements", async (req, res) => {
    try {
      const achievements = await storage.getAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Failed to get achievements" });
    }
  });

  app.get("/api/users/:userId/achievements", async (req, res) => {
    try {
      const { userId } = req.params;
      const userAchievements = await storage.getUserAchievements(userId);
      res.json(userAchievements);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user achievements" });
    }
  });

  app.post("/api/users/:userId/achievements/:achievementId", async (req, res) => {
    try {
      const { userId, achievementId } = req.params;
      await storage.unlockAchievement(userId, parseInt(achievementId));
      res.json({ message: "Achievement unlocked successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to unlock achievement" });
    }
  });

  // Register trading routes
  app.use('/api/trading', tradingRouter);
  
  // Register advanced routes
  setupAdvancedRoutes(app);
  
  const httpServer = createServer(app);
  return httpServer;
}
