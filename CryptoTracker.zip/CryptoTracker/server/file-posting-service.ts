import { fileStorage } from './file-storage';
import { telegramService } from './telegram-singleton';
import { storage } from './storage';

class FilePostingService {
  private intervalId: NodeJS.Timeout | null = null;
  private isActive = false;

  async start(): Promise<void> {
    if (this.isActive) return;
    this.isActive = true;
    
    console.log('📁 Starting file-based posting service');
    
    // Clean old tokens on startup
    fileStorage.cleanOldTokens();
    
    // Start posting loop
    this.intervalId = setInterval(() => {
      this.processPostingQueue().catch(err => 
        console.log('File posting error:', err.message)
      );
    }, 10000); // Check every 10 seconds
  }

  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isActive = false;
    console.log('📁 File-based posting service stopped');
  }

  private async processPostingQueue(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive || !config.telegramToken || !config.channelId) {
        return;
      }

      const postingState = fileStorage.getPostingState();
      const now = Date.now();
      
      // Check if enough time has passed since last post
      if (now - postingState.lastPostTime < postingState.postDelay) {
        return;
      }

      const nextToken = fileStorage.getNextUnpostedToken();
      if (!nextToken) {
        return;
      }

      console.log(`📤 File posting: ${nextToken.tokenSymbol}`);
      
      const success = await this.postTokenMessage(nextToken, config);
      
      if (success) {
        fileStorage.markTokenAsPosted(nextToken.tokenAddress);
        fileStorage.savePostingState({
          lastPostTime: now,
          postDelay: 45000,
          isActive: true
        });
        
        const remaining = fileStorage.getUnpostedCount();
        console.log(`✅ Posted ${nextToken.tokenSymbol} - ${remaining} remaining`);
        
        await storage.createActivityLog({
          type: 'token_post',
          message: `Posted ${nextToken.tokenSymbol}`,
          status: 'success'
        });
      }
    } catch (error) {
      console.log('File posting process error:', (error as Error).message);
    }
  }

  private async postTokenMessage(tokenData: any, config: any): Promise<boolean> {
    try {
      const ageInHours = tokenData.ageInHours || 'Unknown';
      const formattedAge = ageInHours === 'Unknown' ? 'Unknown' : `${Math.round(ageInHours)}h`;
      
      const liquidity = parseFloat(tokenData.liquidity) || 0;
      const marketCap = tokenData.marketCap ? parseFloat(tokenData.marketCap) : null;
      const volume = tokenData.volume24h ? parseFloat(tokenData.volume24h) : null;
      
      const riskEmoji = tokenData.classification === 'green' ? '🟢' : 
                       tokenData.classification === 'yellow' ? '🟡' : '🔴';
      
      let qualityScore = 'N/A';
      try {
        if (tokenData.qualityMetrics) {
          const metrics = JSON.parse(tokenData.qualityMetrics);
          qualityScore = metrics.overallScore?.toFixed(1) || 'N/A';
        }
      } catch (e) {
        // Ignore parsing errors
      }

      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${tokenData.tokenName}** (${tokenData.tokenSymbol})

📊 **Market Data:**
💰 Liquidity: $${liquidity.toLocaleString()}
💵 Market Cap: ${marketCap ? `$${marketCap.toLocaleString()}` : 'N/A'}
📈 24h Volume: ${volume ? `$${volume.toLocaleString()}` : 'N/A'}
⏰ Age: ${formattedAge}

🔗 **Contract:** \`${tokenData.tokenAddress}\`

⚡ **Discovery Metrics:**
${riskEmoji} Risk Level: ${(tokenData.classification || 'UNCLASSIFIED').toUpperCase()}
📊 Quality Score: ${qualityScore}%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      return true;
    } catch (error) {
      console.log('Telegram message failed:', (error as Error).message);
      return false;
    }
  }

  queueToken(tokenData: any): void {
    fileStorage.addTokenToQueue(tokenData);
  }

  isRunning(): boolean {
    return this.isActive;
  }

  getStatus(): {
    active: boolean;
    nextPostIn: number;
    queueSize: number;
    lastPostTime: number;
  } {
    const postingState = fileStorage.getPostingState();
    const now = Date.now();
    const timeSinceLastPost = now - postingState.lastPostTime;
    const nextPostIn = Math.max(0, postingState.postDelay - timeSinceLastPost);
    const queueSize = fileStorage.getUnpostedCount();

    return {
      active: this.isActive,
      nextPostIn,
      queueSize,
      lastPostTime: postingState.lastPostTime
    };
  }
}

export const filePostingService = new FilePostingService();