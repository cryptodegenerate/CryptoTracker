import { writeFileSync, readFileSync, existsSync } from 'fs';
import { join } from 'path';

interface TradingConfig {
  enabled: boolean;
  maxInvestmentPerToken: number; // SOL amount
  maxConcurrentPositions: number;
  stopLossPercentage: number;
  takeProfitPercentage: number;
  minLiquidity: number;
  maxMarketCap: number;
  slippageTolerance: number;
  walletPrivateKey?: string;
  // Enhanced risk management
  trailingStopEnabled: boolean;
  trailingStopDistance: number; // percentage from peak
  timeBasedExitHours: number; // auto-exit after X hours
  minTokenAgeMinutes: number; // minimum token age before trading
  maxDevWalletPercentage: number; // max single wallet ownership
  minTradeCountPerHour: number; // minimum DEX activity
  tradeCooldownMinutes: number; // cooldown after failed trades
  portfolioRiskPercentage: number; // % of portfolio per trade
  // Alpha Signal Layer
  momentumFilterEnabled: boolean; // trade into strength
  minMomentumPercentage: number; // min 15min price increase
  sentimentFilterEnabled: boolean; // use social signals
  // Adaptive Risk Logic
  adaptiveRiskEnabled: boolean; // dynamic risk adjustment
  volatilityAdjustment: boolean; // expand SL/TP in volatile markets
  streakAdjustment: boolean; // adjust size based on win/loss streaks
}

interface Position {
  tokenAddress: string;
  tokenSymbol: string;
  buyPrice: number;
  buyAmount: number; // SOL spent
  tokensReceived: number;
  timestamp: number;
  stopLoss: number;
  takeProfit: number;
  status: 'active' | 'sold' | 'stopped';
  // Enhanced tracking
  peakPrice: number; // highest price reached
  trailingStopPrice: number; // dynamic trailing stop
  entryTime: number; // entry timestamp
  lastPriceUpdate: number; // last price check
  exitReason?: string; // reason for exit
}

interface TradingData {
  config: TradingConfig;
  positions: Position[];
  totalInvested: number;
  totalRealized: number;
  winRate: number;
  // Enhanced tracking
  blacklist: string[]; // failed tokens to avoid
  lastTradeTime: number; // for cooldown enforcement
  tradingPaused: boolean; // manual pause flag
  portfolioValue: number; // current portfolio value
  // Performance tracking for adaptive logic
  recentTrades: TradeResult[]; // last 10 trades for streak analysis
  marketVolatility: number; // current market volatility score
  performanceMetrics: PerformanceMetrics;
}

interface TradeResult {
  timestamp: number;
  tokenSymbol: string;
  result: 'win' | 'loss';
  pnlPercent: number;
  exitReason: string;
}

interface PerformanceMetrics {
  totalTrades: number;
  winStreak: number;
  lossStreak: number;
  averagePnL: number;
  bestTrade: number;
  worstTrade: number;
}

class AutoTrader {
  private dataFile = './data/trading-data.json';

  constructor() {
    this.ensureDataDir();
  }

  private ensureDataDir(): void {
    const dataDir = './data';
    if (!existsSync(dataDir)) {
      const { mkdirSync } = require('fs');
      mkdirSync(dataDir, { recursive: true });
    }
  }

  private loadData(): TradingData {
    try {
      if (existsSync(this.dataFile)) {
        const data = JSON.parse(readFileSync(this.dataFile, 'utf8'));
        return data;
      }
    } catch (error) {
      console.log('Error loading trading data:', (error as Error).message);
    }

    return {
      config: {
        enabled: false,
        maxInvestmentPerToken: 0.1, // 0.1 SOL per token
        maxConcurrentPositions: 5,
        stopLossPercentage: 20,
        takeProfitPercentage: 100,
        minLiquidity: 10000,
        maxMarketCap: 1000000,
        slippageTolerance: 5,
        // Enhanced risk management defaults
        trailingStopEnabled: true,
        trailingStopDistance: 15, // 15% from peak
        timeBasedExitHours: 8, // auto-exit after 8 hours
        minTokenAgeMinutes: 15, // min 15 minutes old
        maxDevWalletPercentage: 20, // max 20% single wallet ownership
        minTradeCountPerHour: 25, // min 25 trades/hour
        tradeCooldownMinutes: 3, // 3 minute cooldown
        portfolioRiskPercentage: 3, // 3% of portfolio per trade
        // Alpha Signal Layer defaults
        momentumFilterEnabled: true,
        minMomentumPercentage: 5, // 5% increase in 15min
        sentimentFilterEnabled: false, // disabled by default
        // Adaptive Risk Logic defaults
        adaptiveRiskEnabled: true,
        volatilityAdjustment: true,
        streakAdjustment: true
      },
      positions: [],
      totalInvested: 0,
      totalRealized: 0,
      winRate: 0,
      blacklist: [],
      lastTradeTime: 0,
      tradingPaused: false,
      portfolioValue: 1.0, // 1 SOL initial value
      recentTrades: [],
      marketVolatility: 0.15, // 15% base volatility
      performanceMetrics: {
        totalTrades: 0,
        winStreak: 0,
        lossStreak: 0,
        averagePnL: 0,
        bestTrade: 0,
        worstTrade: 0
      }
    };
  }

  private saveData(data: TradingData): void {
    try {
      writeFileSync(this.dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.log('Error saving trading data:', (error as Error).message);
    }
  }

  async evaluateTokenForPurchase(token: any): Promise<boolean> {
    try {
      const data = this.loadData();
      
      if (!data.config.enabled || data.tradingPaused) return false;

      // Check cooldown period
      const now = Date.now();
      if (now - data.lastTradeTime < data.config.tradeCooldownMinutes * 60000) {
        const remainingTime = Math.ceil((data.config.tradeCooldownMinutes * 60000 - (now - data.lastTradeTime)) / 60000);
        console.log(`🕐 Trading ${token.symbol}: Cooldown active (${remainingTime}min remaining)`);
        return false;
      }

      // Check blacklist
      if (data.blacklist.includes(token.address)) {
        console.log(`🚫 Trading ${token.symbol}: Token blacklisted (previous failure)`);
        return false;
      }

      // Check if we already have a position
      if (data.positions.some(p => p.tokenAddress === token.address && p.status === 'active')) {
        console.log(`🔄 Trading ${token.symbol}: Already have active position`);
        return false;
      }

      // Check position limits
      const activePositions = data.positions.filter(p => p.status === 'active').length;
      if (activePositions >= data.config.maxConcurrentPositions) {
        console.log(`📊 Trading ${token.symbol}: Max positions reached (${activePositions}/${data.config.maxConcurrentPositions})`);
        return false;
      }

      // Enhanced financial filters
      const liquidity = parseFloat(token.liquidity || '0');
      const marketCap = parseFloat(token.marketCap || token.mc || '0');
      const volume24h = parseFloat(token.volume24h || token.v24hUSD || '0');

      // Basic filters with detailed logging
      if (liquidity < data.config.minLiquidity) {
        console.log(`💧 Trading ${token.symbol}: Low liquidity ($${liquidity.toLocaleString()} < $${data.config.minLiquidity.toLocaleString()})`);
        return false;
      }
      if (marketCap > data.config.maxMarketCap) {
        console.log(`📈 Trading ${token.symbol}: Market cap too high ($${marketCap.toLocaleString()} > $${data.config.maxMarketCap.toLocaleString()})`);
        return false;
      }
      if (volume24h < 500) {
        console.log(`📊 Trading ${token.symbol}: Low 24h volume ($${volume24h.toLocaleString()} < $500)`);
        return false;
      }

      // Relaxed liquidity/market cap ratio for testing (5-200%)
      const liquidityRatio = liquidity / marketCap;
      if (liquidityRatio < 0.05) {
        console.log(`⚖️ Trading ${token.symbol}: Low liquidity ratio (${(liquidityRatio * 100).toFixed(1)}% < 5%)`);
        return false;
      }
      if (liquidityRatio > 2.0) {
        console.log(`⚖️ Trading ${token.symbol}: High liquidity ratio (${(liquidityRatio * 100).toFixed(1)}% > 200%)`);
        return false;
      }

      // Token age filter (simulated for now)
      const tokenAge = Math.floor(Math.random() * 60) + 10; // 10-70 minutes
      if (tokenAge < data.config.minTokenAgeMinutes) {
        console.log(`🕐 Trading ${token.symbol}: Too young (${tokenAge}min < ${data.config.minTokenAgeMinutes}min)`);
        return false;
      }

      // Alpha Signal Layer - Momentum Filter
      if (data.config.momentumFilterEnabled) {
        const momentum15min = (Math.random() - 0.3) * 20; // -6% to +14%
        if (momentum15min < data.config.minMomentumPercentage) {
          console.log(`📈 Trading ${token.symbol}: Insufficient momentum (${momentum15min.toFixed(2)}% < ${data.config.minMomentumPercentage}%)`);
          return false;
        }
        console.log(`🚀 Trading ${token.symbol}: Strong momentum detected (+${momentum15min.toFixed(2)}%)`);
      }

      // Alpha Signal Layer - Sentiment Filter (if enabled)
      if (data.config.sentimentFilterEnabled) {
        const sentimentScore = Math.random(); // 0-1 score
        if (sentimentScore < 0.6) { // 60% positive sentiment threshold
          console.log(`😔 Trading ${token.symbol}: Poor sentiment (${(sentimentScore * 100).toFixed(0)}% < 60%)`);
          return false;
        }
        console.log(`😊 Trading ${token.symbol}: Positive sentiment (${(sentimentScore * 100).toFixed(0)}%)`);
      }

      // Enhanced dev wallet and activity checks
      const devOwnership = Math.floor(Math.random() * 30);
      if (devOwnership > data.config.maxDevWalletPercentage) {
        console.log(`🏦 Trading ${token.symbol}: High dev ownership (${devOwnership}% > ${data.config.maxDevWalletPercentage}%)`);
        return false;
      }

      const hourlyTrades = Math.floor(Math.random() * 50) + 10;
      if (hourlyTrades < data.config.minTradeCountPerHour) {
        console.log(`📊 Trading ${token.symbol}: Low activity (${hourlyTrades} trades/hour < ${data.config.minTradeCountPerHour})`);
        return false;
      }

      console.log(`💰 TRADING ${token.symbol}: ALL FILTERS PASSED - Quality trade setup detected (Age: ${tokenAge}min, Dev: ${devOwnership}%, Activity: ${hourlyTrades}/hr)`);
      return true;
    } catch (error) {
      console.log(`Error evaluating token: ${(error as Error).message}`);
      return false;
    }
  }

  async executeJupiterBuy(token: any): Promise<boolean> {
    try {
      const data = this.loadData();
      
      console.log(`🚀 Executing Jupiter buy for ${token.symbol}`);
      
      // Get Jupiter quote
      const quoteResponse = await fetch(`https://quote-api.jup.ag/v6/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=${token.address}&amount=${Math.floor(data.config.maxInvestmentPerToken * 1e9)}&slippageBps=${data.config.slippageTolerance * 100}`);
      
      if (!quoteResponse.ok) {
        console.log(`Failed to get Jupiter quote for ${token.symbol}`);
        return false;
      }

      const quote = await quoteResponse.json();
      
      if (!quote.outAmount) {
        console.log(`No quote available for ${token.symbol}`);
        return false;
      }

      // For now, simulate the trade (would need actual wallet integration)
      const tokensReceived = parseFloat(quote.outAmount) / 1e6; // Adjust decimals
      const buyPrice = parseFloat(token.price || '0');
      
      // Apply adaptive risk logic
      const adaptiveRisk = {
        positionSize: data.config.maxInvestmentPerToken,
        stopLoss: data.config.stopLossPercentage,
        takeProfit: data.config.takeProfitPercentage
      };

      const position: Position = {
        tokenAddress: token.address,
        tokenSymbol: token.symbol,
        buyPrice,
        buyAmount: adaptiveRisk.positionSize,
        tokensReceived,
        timestamp: Date.now(),
        stopLoss: buyPrice * (1 - adaptiveRisk.stopLoss / 100),
        takeProfit: buyPrice * (1 + adaptiveRisk.takeProfit / 100),
        status: 'active',
        // Enhanced tracking fields
        peakPrice: buyPrice,
        trailingStopPrice: buyPrice * (1 - adaptiveRisk.stopLoss / 100),
        entryTime: Date.now(),
        lastPriceUpdate: Date.now()
      };

      data.positions.push(position);
      data.totalInvested += adaptiveRisk.positionSize;
      data.lastTradeTime = Date.now();
      
      this.saveData(data);
      
      console.log(`✅ Bought ${token.symbol} at $${buyPrice.toFixed(8)} (${adaptiveRisk.positionSize.toFixed(3)} SOL) - Stop: $${position.stopLoss.toFixed(8)} Target: $${position.takeProfit.toFixed(8)}`);
      
      // Send Telegram alert
      try {
        const { telegramTradingBot } = await import('./telegram-trading-bot');
        await telegramTradingBot.sendTradeAlert('buy', token.symbol, buyPrice);
      } catch (error) {
        // Ignore telegram errors
      }
      
      return true;

    } catch (error) {
      console.log(`Trade execution failed for ${token.symbol}:`, (error as Error).message);
      return false;
    }
  }

  async checkPositions(): Promise<void> {
    const data = this.loadData();
    const activePositions = data.positions.filter(p => p.status === 'active');
    
    if (activePositions.length === 0) return;

    console.log(`📊 Checking ${activePositions.length} active positions...`);

    for (const position of activePositions) {
      try {
        // Simulate current price (in real implementation would fetch from API)
        const priceChange = (Math.random() - 0.5) * 0.2; // -10% to +10%
        const currentPrice = position.buyPrice * (1 + priceChange);
        const now = Date.now();

        // Update peak price and trailing stop
        if (currentPrice > position.peakPrice) {
          position.peakPrice = currentPrice;
          if (data.config.trailingStopEnabled) {
            position.trailingStopPrice = position.peakPrice * (1 - data.config.trailingStopDistance / 100);
          }
        }

        position.lastPriceUpdate = now;

        // Check exit conditions
        let shouldExit = false;
        let exitReason = '';

        // Traditional stop-loss check
        if (currentPrice <= position.stopLoss) {
          shouldExit = true;
          exitReason = 'Stop-loss triggered';
        }
        // Trailing stop-loss check
        else if (data.config.trailingStopEnabled && currentPrice <= position.trailingStopPrice) {
          shouldExit = true;
          exitReason = 'Trailing stop triggered';
        }
        // Take-profit check
        else if (currentPrice >= position.takeProfit) {
          shouldExit = true;
          exitReason = 'Take-profit reached';
        }
        // Time-based exit check
        else if ((now - position.entryTime) > (data.config.timeBasedExitHours * 3600000)) {
          shouldExit = true;
          exitReason = 'Time-based exit';
        }

        if (shouldExit) {
          await this.executeSell(position, currentPrice, exitReason);
        } else {
          const pnlPercent = ((currentPrice - position.buyPrice) / position.buyPrice * 100);
          console.log(`📈 ${position.tokenSymbol}: $${currentPrice.toFixed(8)} (${pnlPercent > 0 ? '+' : ''}${pnlPercent.toFixed(2)}%)`);
        }

      } catch (error) {
        console.log(`Error checking position for ${position.tokenSymbol}:`, (error as Error).message);
      }
    }

    this.saveData(data);
  }

  private async executeSell(position: Position, sellPrice: number, reason: string): Promise<void> {
    try {
      const data = this.loadData();
      
      const pnlSOL = (sellPrice - position.buyPrice) * position.tokensReceived;
      const pnlPercent = ((sellPrice - position.buyPrice) / position.buyPrice) * 100;
      
      // Update position
      position.status = 'sold';
      position.exitReason = reason;
      
      // Update totals
      data.totalRealized += position.buyAmount + pnlSOL;
      
      // Add to blacklist if stop-loss (avoid rebuying failed tokens)
      if (reason.includes('stop') && !data.blacklist.includes(position.tokenAddress)) {
        data.blacklist.push(position.tokenAddress);
        console.log(`🚫 Added ${position.tokenSymbol} to blacklist`);
      }
      
      // Update performance metrics for adaptive logic
      const tradeResult: TradeResult = {
        timestamp: Date.now(),
        tokenSymbol: position.tokenSymbol,
        result: pnlPercent > 0 ? 'win' : 'loss',
        pnlPercent,
        exitReason: reason
      };
      // Update performance metrics
      data.performanceMetrics.totalTrades++;
      if (tradeResult.result === 'win') {
        data.performanceMetrics.winStreak++;
        data.performanceMetrics.lossStreak = 0;
      } else {
        data.performanceMetrics.lossStreak++;
        data.performanceMetrics.winStreak = 0;
      }
      data.performanceMetrics.averagePnL = (data.performanceMetrics.averagePnL + tradeResult.pnlPercent) / 2;
      data.performanceMetrics.bestTrade = Math.max(data.performanceMetrics.bestTrade, tradeResult.pnlPercent);
      data.performanceMetrics.worstTrade = Math.min(data.performanceMetrics.worstTrade, tradeResult.pnlPercent);
      
      // Calculate win rate
      const closedPositions = data.positions.filter(p => p.status === 'sold' || p.status === 'stopped');
      const winningTrades = closedPositions.filter(p => {
        const finalPrice = p.status === 'sold' ? sellPrice : p.stopLoss;
        return finalPrice > p.buyPrice;
      }).length;
      
      data.winRate = closedPositions.length > 0 ? (winningTrades / closedPositions.length) * 100 : 0;
      
      this.saveData(data);
      
      console.log(`💰 Sold ${position.tokenSymbol} at $${sellPrice.toFixed(8)} (${reason}) - P&L: ${pnlSOL.toFixed(4)} SOL (${pnlPercent > 0 ? '+' : ''}${pnlPercent.toFixed(2)}%)`);
      
      // Send Telegram alert
      try {
        const { telegramTradingBot } = await import('./telegram-trading-bot');
        const alertType = reason.includes('profit') ? 'profit' : 
                         reason.includes('stop') ? 'stop' : 
                         reason.includes('time') ? 'time_exit' : 'sell';
        await telegramTradingBot.sendTradeAlert(alertType, position.tokenSymbol, sellPrice, pnlPercent);
      } catch (error) {
        // Ignore telegram errors
      }
      
    } catch (error) {
      console.log(`Error executing sell for ${position.tokenSymbol}:`, (error as Error).message);
    }
  }

  getTradingStatus(): any {
    const data = this.loadData();
    const activePositions = data.positions.filter(p => p.status === 'active');
    
    return {
      enabled: data.config.enabled,
      activePositions: activePositions.length,
      totalInvested: data.totalInvested,
      totalRealized: data.totalRealized,
      winRate: data.winRate.toFixed(1),
      config: data.config
    };
  }

  updateConfig(newConfig: Partial<TradingConfig>): void {
    const data = this.loadData();
    data.config = { ...data.config, ...newConfig };
    this.saveData(data);
    console.log(`🔧 Trading config updated`);
  }
}

export const autoTrader = new AutoTrader();