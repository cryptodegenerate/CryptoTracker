import { storage } from './storage.js';
import { telegramService } from './telegram-singleton.js';
import { statelessBot } from './stateless-bot.js';

interface AutoConfig {
  telegramToken: string;
  channelId: string;
  monitoringInterval: number;
  maxTokens: number;
  isActive: boolean;
  // Safety filter configuration
  minLiquidity: number;
  requireLiquidityLocked: boolean;
  requireMintRevoked: boolean;
  requireFreezeRevoked: boolean;
  maxTopHolderPercent: number;
  minHolders: number;
  minDailyVolume: number;
  minTokenAge: number;
  maxTokenAge: number;
  minTwitterFollowers: number;
}

// Auto-configuration settings with comprehensive safety filters
const AUTO_CONFIG: AutoConfig = {
  telegramToken: "7665713229:AAHoGqx4vCbCv3Ui4HDbntmyKnXlYN7UEtc",
  channelId: "-1002602692386",
  monitoringInterval: 5,
  maxTokens: 3,
  isActive: true,
  // Professional-grade safety requirements
  minLiquidity: 100000,           // $100K minimum liquidity
  requireLiquidityLocked: true,   // Liquidity must be locked/burned
  requireMintRevoked: true,       // Mint authority must be revoked
  requireFreezeRevoked: true,     // Freeze authority must be revoked
  maxTopHolderPercent: 10,        // Max 10% held by single wallet
  minHolders: 300,                // Minimum 300 unique holders
  minDailyVolume: 10000,          // $10K minimum daily volume
  minTokenAge: 10,                // At least 10 minutes old
  maxTokenAge: 360,               // Maximum 6 hours old
  minTwitterFollowers: 100        // Minimum Twitter following
};

export async function initializeAutoConfig(): Promise<void> {
  try {
    console.log('🔧 Auto-configuration starting...');
    
    // Check if configuration already exists
    const existingConfig = await storage.getBotConfiguration();
    
    if (!existingConfig) {
      console.log('📝 Creating initial bot configuration...');
      
      // Create the configuration
      await storage.createOrUpdateBotConfiguration(AUTO_CONFIG);
      
      await storage.createActivityLog({
        type: 'config_update',
        message: 'Auto-configuration applied on startup',
        status: 'success',
      });
      
      console.log('✅ Bot configuration created automatically');
    } else {
      console.log('📋 Bot configuration already exists, skipping auto-config');
    }
    
    // Always attempt to start the bot services if active
    if (AUTO_CONFIG.isActive) {
      console.log('🚀 Starting bot services...');
      
      // Initialize Telegram service
      const telegramInitialized = await telegramService.initialize(AUTO_CONFIG.telegramToken);
      
      if (telegramInitialized) {
        console.log('📱 Telegram service initialized');
        
        // Start monitoring service
        try {
          // Check bot state on startup
          await statelessBot.checkAndRun();
          console.log('🤖 Stateless bot initialized');
          
          // Set up periodic checks
          setInterval(async () => {
            await statelessBot.checkAndRun();
          }, 30000);
          
          await storage.createActivityLog({
            type: 'bot_start',
            message: 'Auto-configuration: Bot services started successfully',
            status: 'success',
          });
          
          // Send startup notification
          await telegramService.sendMessage(AUTO_CONFIG.channelId, 
            '🔄 BOT AUTO-RESTART COMPLETE\n\n' +
            '✅ Enhanced monitoring system automatically reconfigured\n' +
            '📊 Professional liquidity assessment active\n' +
            '⚡ 1-minute scanning intervals operational\n' +
            '🎯 Institutional-grade evaluation standards restored'
          );
          
        } catch (monitoringError) {
          console.log('⚠️ Monitoring service already running or error:', monitoringError);
        }
        
      } else {
        console.error('❌ Failed to initialize Telegram service');
      }
    }
    
  } catch (error) {
    console.error('❌ Auto-configuration failed:', error);
    
    await storage.createActivityLog({
      type: 'config_update',
      message: 'Auto-configuration failed on startup',
      status: 'error',
      details: JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
    });
  }
}