import { spawn, ChildProcess } from 'child_process';
import { writeFileSync, existsSync } from 'fs';

export class ProcessMonitor {
  private childProcess: ChildProcess | null = null;
  private restartCount = 0;
  private maxRestarts = 10;
  private lastRestartTime = 0;
  private restartCooldown = 60000; // 1 minute between restarts
  private pidFile = './server.pid';
  private isShuttingDown = false;

  start(): void {
    this.spawnServer();
    this.setupProcessMonitoring();
  }

  private spawnServer(): void {
    if (this.isShuttingDown) return;

    console.log('🚀 Starting server process...');
    
    this.childProcess = spawn('npm', ['run', 'dev'], {
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: false
    });

    if (this.childProcess.pid) {
      writeFileSync(this.pidFile, this.childProcess.pid.toString());
    }

    this.childProcess.stdout?.on('data', (data) => {
      process.stdout.write(data);
    });

    this.childProcess.stderr?.on('data', (data) => {
      process.stderr.write(data);
    });

    this.childProcess.on('exit', (code, signal) => {
      console.log(`Server process exited with code ${code}, signal ${signal}`);
      
      if (!this.isShuttingDown && this.shouldRestart()) {
        console.log('🔄 Auto-restarting server process...');
        setTimeout(() => this.spawnServer(), 5000); // 5 second delay
        this.restartCount++;
        this.lastRestartTime = Date.now();
      }
    });

    this.childProcess.on('error', (error) => {
      console.error('Server process error:', error);
    });
  }

  private shouldRestart(): boolean {
    const now = Date.now();
    
    // Don't restart too frequently
    if (now - this.lastRestartTime < this.restartCooldown) {
      console.log('Restart cooldown active, waiting...');
      return false;
    }

    // Don't restart if we've hit the maximum
    if (this.restartCount >= this.maxRestarts) {
      console.log('Maximum restart count reached');
      return false;
    }

    return true;
  }

  private setupProcessMonitoring(): void {
    // Monitor for unexpected shutdowns
    setInterval(() => {
      if (this.childProcess && this.childProcess.killed) {
        console.log('⚠️ Child process was killed, attempting restart...');
        this.spawnServer();
      }
    }, 30000); // Check every 30 seconds

    // Graceful shutdown handling
    process.on('SIGINT', () => this.shutdown());
    process.on('SIGTERM', () => this.shutdown());
    process.on('exit', () => this.shutdown());
  }

  private shutdown(): void {
    this.isShuttingDown = true;
    
    if (this.childProcess && !this.childProcess.killed) {
      console.log('🛑 Shutting down server process...');
      this.childProcess.kill('SIGTERM');
    }

    // Clean up PID file
    if (existsSync(this.pidFile)) {
      try {
        require('fs').unlinkSync(this.pidFile);
      } catch (error) {
        // Ignore cleanup errors
      }
    }
  }

  getStatus(): { running: boolean, restarts: number, pid?: number } {
    return {
      running: this.childProcess ? !this.childProcess.killed : false,
      restarts: this.restartCount,
      pid: this.childProcess?.pid
    };
  }
}

// Self-monitoring wrapper that runs independently
if (require.main === module) {
  const monitor = new ProcessMonitor();
  monitor.start();
  
  console.log('🔄 Process monitor started - will auto-restart on failures');
}