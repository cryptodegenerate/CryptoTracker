import { robustMonitoringService } from './robust-monitor';
import { storage } from './storage';
import { telegramService } from './telegram-singleton';

export class QuietResetManager {
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private isActive = false;
  private consecutiveFailures = 0;
  private maxFailures = 3;
  private lastSuccessfulPost = Date.now();
  private resetInProgress = false;

  start(): void {
    if (this.isActive) return;
    
    this.isActive = true;
    console.log('🔄 Quiet reset manager started');
    
    // Check system health every 2 minutes
    this.healthCheckInterval = setInterval(() => {
      this.performHealthCheck();
    }, 2 * 60 * 1000);
  }

  stop(): void {
    this.isActive = false;
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }

  private async performHealthCheck(): Promise<void> {
    if (this.resetInProgress) return;

    try {
      // Check if monitoring service is still active
      if (!robustMonitoringService.isMonitoringActive()) {
        console.log('⚠️ Monitoring service inactive - initiating quiet reset');
        await this.performQuietReset();
        return;
      }

      // Check if posts are still happening
      const recentPosts = await this.checkRecentActivity();
      if (!recentPosts && Date.now() - this.lastSuccessfulPost > 10 * 60 * 1000) {
        console.log('⚠️ No recent posting activity - initiating quiet reset');
        await this.performQuietReset();
        return;
      }

      // Reset failure counter on successful check
      this.consecutiveFailures = 0;

    } catch (error) {
      this.consecutiveFailures++;
      console.log(`Health check failed (${this.consecutiveFailures}/${this.maxFailures}):`, (error as Error).message);
      
      if (this.consecutiveFailures >= this.maxFailures) {
        console.log('🚨 Maximum failures reached - initiating quiet reset');
        await this.performQuietReset();
      }
    }
  }

  private async checkRecentActivity(): Promise<boolean> {
    try {
      const activities = await storage.getActivityLogs();
      const recentActivity = activities.find(activity => 
        activity.type === 'token_post' && 
        activity.timestamp && 
        Date.now() - new Date(activity.timestamp).getTime() < 5 * 60 * 1000
      );
      
      if (recentActivity) {
        this.lastSuccessfulPost = Date.now();
        return true;
      }
      
      return false;
    } catch {
      return false;
    }
  }

  private async performQuietReset(): Promise<void> {
    if (this.resetInProgress) return;
    
    this.resetInProgress = true;
    console.log('🔄 Performing quiet reset...');

    try {
      // Stop current monitoring service
      await robustMonitoringService.stop();
      
      // Brief pause to ensure clean shutdown
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Restart monitoring service
      await robustMonitoringService.start();
      
      // Log the reset
      await storage.createActivityLog({
        type: 'system_reset',
        message: 'Quiet reset completed - service restored',
        status: 'success'
      });

      // Send quiet notification to channel
      await this.sendQuietResetNotification();
      
      this.consecutiveFailures = 0;
      this.lastSuccessfulPost = Date.now();
      
      console.log('✅ Quiet reset completed successfully');

    } catch (error) {
      console.log('❌ Quiet reset failed:', (error as Error).message);
      
      await storage.createActivityLog({
        type: 'system_reset',
        message: `Quiet reset failed: ${(error as Error).message}`,
        status: 'error'
      });
    } finally {
      this.resetInProgress = false;
    }
  }

  private async sendQuietResetNotification(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.channelId || !config.isActive) return;

      const message = `🔄 **SYSTEM MAINTENANCE COMPLETE**

⚡ **Service Status:** Fully Operational
🔍 **Token Discovery:** Active  
📤 **Posting System:** Restored
🛡️ **Safety Filters:** Online

**Automatic restoration completed**
Zero downtime achieved through quiet reset protocol.

🚀 **Ready to discover new opportunities!**`;

      await telegramService.sendMessage(config.channelId, message);
      console.log('📢 Quiet reset notification sent');

    } catch (error) {
      console.log('Error sending reset notification:', (error as Error).message);
    }
  }

  isResetInProgress(): boolean {
    return this.resetInProgress;
  }

  getStatus(): { active: boolean; failures: number; lastReset: number } {
    return {
      active: this.isActive,
      failures: this.consecutiveFailures,
      lastReset: this.lastSuccessfulPost
    };
  }
}

export const quietResetManager = new QuietResetManager();