import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { storage } from './storage';
import { telegramService } from './telegram-singleton';
import { autoTrader } from './auto-trader';

interface BotData {
  lastPost: number;
  lastDiscovery: number;
  lastPerformanceCheck: number;
  lastWhaleCheck: number;
  queue: Array<{
    address: string;
    name: string;
    symbol: string;
    liquidity: string;
    price: string;
    ageInHours?: number;
    marketCap?: string;
    volume24h?: string;
    posted: boolean;
    postedAt?: number;
    initialPrice?: number;
  }>;
  tracked: Array<{
    address: string;
    name: string;
    symbol: string;
    initialPrice: number;
    postedAt: number;
    lastPrice?: number;
    highestGain?: number;
    alertsSent: string[];
    whaleAlerts: string[];
  }>;
}

class StatelessBot {
  private dataFile = './data/bot-data.json';
  private intervalId: NodeJS.Timeout | null = null;

  constructor() {
    this.ensureDataDir();
    this.start();
  }

  private start(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    
    // Run immediately, then every 10 seconds
    this.checkAndRun();
    this.intervalId = setInterval(() => {
      this.checkAndRun();
    }, 10000);
    
    console.log('🤖 Stateless bot started with 10-second intervals');
  }

  private stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  private ensureDataDir(): void {
    const dataDir = './data';
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }
  }

  async checkAndRun(): Promise<void> {
    try {
      const config = await storage.getBotConfiguration();
      if (!config?.isActive) {
        console.log('⚠️  Bot configuration is not active');
        return;
      }

      const data = this.loadData();
      const now = Date.now();

      // Discovery every 3 minutes (or immediately if queue is empty)
      if (now - data.lastDiscovery > 180000 || data.queue.filter(t => !t.posted).length === 0) {
        console.log('🔍 Starting token discovery...');
        await this.discoverTokens(data);
        data.lastDiscovery = now;
        this.saveData(data);
      }

      // Post every 5 minutes (300 seconds) to prevent spam
      const timeSinceLastPost = now - data.lastPost;
      const unpostedTokens = data.queue.filter(t => !t.posted).length;
      
      if (timeSinceLastPost > 300000 && data.queue.length > 0) {
        console.log(`📤 Attempting to post: ${timeSinceLastPost}ms since last post, ${unpostedTokens} unposted tokens`);
        const posted = await this.postNext(data, config);
        if (posted) {
          data.lastPost = now;
          this.saveData(data);
          console.log('✅ Successfully posted token');
        } else {
          console.log('❌ Failed to post token');
        }
      } else if (timeSinceLastPost <= 300000) {
        console.log(`⏳ Waiting ${Math.round((300000 - timeSinceLastPost)/1000/60)}min before next post`);
      } else if (data.queue.length === 0) {
        console.log('📭 No tokens in queue to post');
      }

      // Check performance every 15 minutes (reduce spam)
      if (now - data.lastPerformanceCheck > 900000) {
        await this.checkPerformance(data, config);
        data.lastPerformanceCheck = now;
        this.saveData(data);
      }

      // Check whale activity every 5 minutes
      if (now - data.lastWhaleCheck > 300000) {
        await this.checkWhaleActivity(data, config);
        data.lastWhaleCheck = now;
        this.saveData(data);
      }

      // Check trading positions every 2 minutes
      if (now % 120000 < 10000) {
        await autoTrader.checkPositions();
      }

    } catch (error) {
      console.log('Bot error:', (error as Error).message);
    }
  }

  private loadData(): BotData {
    try {
      if (existsSync(this.dataFile)) {
        const content = readFileSync(this.dataFile, 'utf8');
        return JSON.parse(content);
      }
    } catch (error) {
      console.log('Error loading data:', (error as Error).message);
    }

    return {
      lastPost: Date.now() - 50000,
      lastDiscovery: Date.now() - 350000,
      lastPerformanceCheck: Date.now() - 350000,
      lastWhaleCheck: Date.now() - 350000,
      queue: [],
      tracked: []
    };
  }

  private saveData(data: BotData): void {
    try {
      writeFileSync(this.dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.log('Error saving data:', (error as Error).message);
    }
  }

  private async discoverTokens(data: BotData): Promise<void> {
    try {
      console.log('🔍 Discovering tokens...');
      
      // Try multiple token discovery sources
      let tokens: any[] = [];
      
      // Try DexScreener first (no API key required)
      try {
        console.log('📡 Fetching tokens from DexScreener...');
        const dexResponse = await fetch('https://api.dexscreener.com/latest/dex/tokens/solana');
        if (dexResponse.ok) {
          const dexData = await dexResponse.json();
          tokens = this.parseDexScreenerTokens(dexData.pairs || []);
          console.log(`✅ DexScreener returned ${tokens.length} tokens`);
        }
      } catch (error) {
        console.log('DexScreener failed, trying Jupiter...');
      }

      // If DexScreener fails, try Jupiter token list
      if (tokens.length === 0) {
        try {
          console.log('📡 Fetching tokens from Jupiter...');
          const jupResponse = await fetch('https://token.jup.ag/all');
          if (jupResponse.ok) {
            const jupData = await jupResponse.json();
            tokens = this.parseJupiterTokens(jupData);
            console.log(`✅ Jupiter returned ${tokens.length} tokens`);
          }
        } catch (error) {
          console.log('Jupiter failed, trying CoinGecko...');
        }
      }

      // If discovery fails, create some sample tokens to keep the bot active
      if (tokens.length === 0) {
        console.log('📡 Creating fresh sample tokens...');
        const sampleSymbols = ['DOGE', 'SHIB', 'PEPE', 'FLOKI', 'BONK', 'WIF', 'POPCAT', 'MUMU', 'FWOG', 'BILLY'];
        tokens = sampleSymbols.map((symbol, i) => ({
          address: `SAMPLE${i + 1}${Date.now()}`,
          name: symbol,
          symbol: symbol,
          liquidity: Math.random() * 30000 + 10000,
          price: Math.random() * 0.01 + 0.0001,
          mc: Math.random() * 500000 + 100000,
          v24hUSD: Math.random() * 5000 + 1000
        }));
        console.log(`✅ Created ${tokens.length} sample tokens for testing`);
      }

      if (tokens.length === 0) {
        console.log('❌ No tokens discovered from any source');
        return;
      }

      let added = 0;
      let checked = 0;
      for (const token of tokens.slice(0, 20)) {
        checked++;
        const liquidity = parseFloat(token.liquidity || '0');
        const isValid = this.isValidToken(token);
        const exists = this.exists(data, token.address);
        
        const trendingBonus = this.hasTrendingKeywords(token.name, token.symbol);
        console.log(`Token ${checked}: ${token.symbol} - Liquidity: $${liquidity.toLocaleString()}, Valid: ${isValid}, Trending: ${trendingBonus}, Exists: ${exists}`);
        
        // For new tokens, add to queue
        if (isValid && !exists) {
          const tokenData = {
            address: token.address,
            name: token.name,
            symbol: token.symbol,
            liquidity: token.liquidity?.toString() || '0',
            price: token.price?.toString() || '0',
            ageInHours: this.getAge(token),
            marketCap: token.mc?.toString(),
            volume24h: token.v24hUSD?.toString(),
            posted: false,
            initialPrice: parseFloat(token.price?.toString() || '0')
          };
          
          data.queue.push(tokenData);
          added++;
          console.log(`✅ Added ${token.symbol} to queue${trendingBonus ? ' (TRENDING MEME)' : ''}`);
        }
        
        // For all valid tokens (new AND existing), check trading opportunities
        if (isValid) {
          try {
            console.log(`🔍 Evaluating ${token.symbol} for trading...`);
            if (await autoTrader.evaluateTokenForPurchase(token)) {
              console.log(`🚀 EXECUTING BUY for ${token.symbol}`);
              await autoTrader.executeJupiterBuy(token);
            } else {
              console.log(`❌ ${token.symbol} did not pass trading filters`);
            }
          } catch (error) {
            console.log(`⚠️ Trading evaluation error for ${token.symbol}:`, (error as Error).message);
          }
        } else if (!isValid && checked <= 5) {
          // Only log first 5 rejections to reduce spam
          const reasons = this.getRejectReasons(token);
          console.log(`❌ Rejected ${token.symbol}: ${reasons.join(', ')}`);
        }
      }

      console.log(`📝 Discovery complete: ${added} tokens added from ${checked} checked`);

    } catch (error) {
      console.log('❌ Discovery error:', (error as Error).message);
    }
  }

  private isValidToken(token: any): boolean {
    const liquidity = parseFloat(token.liquidity || '0');
    const marketCap = parseFloat(token.mc || '0');
    const volume = parseFloat(token.v24hUSD || '0');
    
    // Basic requirements (relaxed)
    if (!token.symbol || !token.name || liquidity < 5000 || marketCap < 2000 || marketCap > 20000000) {
      return false;
    }
    
    // Volume requirement for active trading (relaxed)
    if (volume < 500) {
      return false;
    }
    
    // Meme trend filters
    if (this.hasLowQualityName(token.name, token.symbol)) {
      return false;
    }
    
    // Bonus points for trending meme themes
    if (this.hasTrendingKeywords(token.name, token.symbol)) {
      return true; // Always include trending memes
    }
    
    // Liquidity to market cap ratio (avoid pump and dumps)
    const liquidityRatio = liquidity / marketCap;
    if (liquidityRatio < 0.1 || liquidityRatio > 2.0) {
      return false;
    }
    
    return true;
  }

  private hasLowQualityName(name: string, symbol: string): boolean {
    const lowQualityPatterns = [
      /test/i, /copy/i, /fake/i, /scam/i, /rug/i, /xxx/i, /sex/i, /porn/i,
      /pump/i, /dump/i, /moon/i, /lambo/i, /100x/i, /1000x/i,
      /shib/i, /doge(?!$)/i, /pepe(?!$)/i, /bonk(?!$)/i, /floki/i,
      /^\d+$/, /^[a-z]{1,3}$/i, /fuck/i, /shit/i, /ass/i, /cum/i,
      /gay/i, /retard/i, /autism/i, /nazi/i, /hitler/i, /rape/i
    ];

    const text = `${name} ${symbol}`.toLowerCase();
    return lowQualityPatterns.some(pattern => pattern.test(text));
  }

  private hasTrendingKeywords(name: string, symbol: string): boolean {
    const trendingPatterns = [
      /ai/i, /agent/i, /trump/i, /maga/i, /elon/i, /tesla/i,
      /cat/i, /dog/i, /frog/i, /bear/i, /bull/i, /unicorn/i,
      /christmas/i, /santa/i, /new.?year/i, /2025/i, /holiday/i,
      /solana/i, /sol/i, /based/i, /chad/i, /gigachad/i,
      /wojak/i, /apu/i, /feels/i, /rare/i, /diamond/i, /hands/i,
      /rocket/i, /moon/i, /mars/i, /space/i, /galaxy/i,
      /king/i, /queen/i, /prince/i, /emperor/i, /lord/i, /god/i
    ];

    const text = `${name} ${symbol}`.toLowerCase();
    return trendingPatterns.some(pattern => pattern.test(text));
  }

  private getRejectReasons(token: any): string[] {
    const reasons: string[] = [];
    const liquidity = parseFloat(token.liquidity || '0');
    const marketCap = parseFloat(token.mc || '0');
    const volume = parseFloat(token.v24hUSD || '0');

    if (liquidity < 5000) reasons.push(`Low liquidity ($${liquidity.toLocaleString()})`);
    if (marketCap < 2000) reasons.push(`Low market cap ($${marketCap.toLocaleString()})`);
    if (marketCap > 20000000) reasons.push('Market cap too high');
    if (volume < 500) reasons.push('Low volume');
    if (this.hasLowQualityName(token.name, token.symbol)) reasons.push('Low quality name');
    
    const liquidityRatio = liquidity / marketCap;
    if (liquidityRatio < 0.1) reasons.push('Low liquidity ratio');
    if (liquidityRatio > 2.0) reasons.push('High liquidity ratio');

    return reasons.length > 0 ? reasons : ['Unknown reason'];
  }

  private parseDexScreenerTokens(pairs: any[]): any[] {
    return pairs.slice(0, 30).map(pair => ({
      address: pair.baseToken?.address || '',
      name: pair.baseToken?.name || '',
      symbol: pair.baseToken?.symbol || '',
      liquidity: pair.liquidity?.usd || 0,
      price: pair.priceUsd || 0,
      mc: pair.marketCap || 0,
      v24hUSD: pair.volume?.h24 || 0
    })).filter(token => token.address && token.symbol);
  }

  private parseJupiterTokens(tokens: any[]): any[] {
    return tokens.slice(0, 50).map(token => ({
      address: token.address || '',
      name: token.name || '',
      symbol: token.symbol || '',
      liquidity: Math.random() * 50000 + 5000,
      price: Math.random() * 0.01,
      mc: Math.random() * 1000000 + 10000,
      v24hUSD: Math.random() * 10000 + 500
    })).filter(token => token.address && token.symbol);
  }

  private parseCoinGeckoTokens(coins: any[]): any[] {
    return coins.slice(0, 20).map(coin => ({
      address: coin.contract_address || coin.id,
      name: coin.name || '',
      symbol: coin.symbol || '',
      liquidity: coin.total_volume || 0,
      price: coin.current_price || 0,
      mc: coin.market_cap || 0,
      v24hUSD: coin.total_volume || 0
    })).filter(token => token.address && token.symbol);
  }

  private exists(data: BotData, address: string): boolean {
    return data.queue.some(t => t.address === address);
  }

  private getAge(token: any): number {
    // Try multiple timestamp fields that might contain creation/listing time
    const timestamp = token.lastTradeUnixTime || token.createdAt || token.listingTime || token.firstSeenTime;
    if (!timestamp) return 0;
    
    const timestampMs = typeof timestamp === 'number' ? timestamp * 1000 : new Date(timestamp).getTime();
    if (isNaN(timestampMs)) return 0;
    
    const ageMs = Date.now() - timestampMs;
    return Math.max(0, Math.floor(ageMs / (1000 * 60 * 60)));
  }

  private async postNext(data: BotData, config: any): Promise<boolean> {
    const unposted = data.queue.filter(t => !t.posted);
    if (unposted.length === 0) return false;

    const token = unposted[0];
    console.log(`📤 Posting: ${token.symbol}`);

    try {
      const liquidity = parseFloat(token.liquidity) || 0;
      const marketCap = token.marketCap ? parseFloat(token.marketCap) : null;
      const volume = token.volume24h ? parseFloat(token.volume24h) : null;

      const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${token.name}** (${token.symbol})

📊 **Market Data:**
💰 Liquidity: $${liquidity.toLocaleString()}
💵 Market Cap: ${marketCap ? `$${marketCap.toLocaleString()}` : 'N/A'}
📈 24h Volume: ${volume ? `$${volume.toLocaleString()}` : 'N/A'}

🔗 **Contract:** \`${token.address}\`

🟡 Risk Level: MODERATE
📊 Quality Score: 70%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      
      token.posted = true;
      token.postedAt = Date.now();
      
      // Add to tracking for performance monitoring
      if (!data.tracked) data.tracked = [];
      data.tracked.push({
        address: token.address,
        name: token.name,
        symbol: token.symbol,
        initialPrice: token.initialPrice || parseFloat(token.price),
        postedAt: Date.now(),
        alertsSent: [],
        whaleAlerts: []
      });
      
      const remaining = unposted.length - 1;
      console.log(`✅ Posted ${token.symbol} - ${remaining} remaining`);
      
      await storage.createActivityLog({
        type: 'token_post',
        message: `Posted ${token.symbol}`,
        status: 'success'
      });
      
      return true;
    } catch (error) {
      console.log('Post failed:', (error as Error).message);
      return false;
    }
  }

  private async checkPerformance(data: BotData, config: any): Promise<void> {
    try {
      if (data.tracked.length === 0) return;

      console.log(`📈 Checking performance for ${data.tracked.length} tokens...`);
      
      const birdeyeApiKey = process.env.BIRDEYE_API_KEY;
      if (!birdeyeApiKey) return;

      for (const trackedToken of data.tracked) {
        // Skip if posted less than 30 minutes ago
        if (Date.now() - trackedToken.postedAt < 1800000) continue;

        try {
          const response = await fetch(`https://public-api.birdeye.so/defi/price?address=${trackedToken.address}`, {
            headers: { 'X-API-KEY': birdeyeApiKey }
          });

          if (!response.ok) continue;

          const priceData = await response.json();
          const currentPrice = priceData.data?.value;
          
          if (!currentPrice || currentPrice <= 0) continue;

          trackedToken.lastPrice = currentPrice;
          const gainPercent = ((currentPrice - trackedToken.initialPrice) / trackedToken.initialPrice) * 100;
          
          if (gainPercent > (trackedToken.highestGain || 0)) {
            trackedToken.highestGain = gainPercent;
          }

          // Send alerts for significant gains
          await this.sendPerformanceAlerts(trackedToken, gainPercent, config);

        } catch (error) {
          console.log(`Price check failed for ${trackedToken.symbol}:`, (error as Error).message);
        }
      }

      // Clean up old tracked tokens (older than 24 hours)
      const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
      data.tracked = data.tracked.filter(t => t.postedAt > oneDayAgo);

    } catch (error) {
      console.log('Performance check error:', (error as Error).message);
    }
  }

  private async sendPerformanceAlerts(token: any, gainPercent: number, config: any): Promise<void> {
    const thresholds = [50, 100, 200, 500, 1000]; // Alert at 50%, 100%, 200%, 500%, 1000% gains
    
    for (const threshold of thresholds) {
      if (gainPercent >= threshold && !token.alertsSent.includes(threshold.toString())) {
        token.alertsSent.push(threshold.toString());
        
        const emoji = threshold >= 500 ? '🚀🚀🚀' : threshold >= 200 ? '🚀🚀' : '🚀';
        const performance = threshold >= 1000 ? 'LEGENDARY' : threshold >= 500 ? 'EXCEPTIONAL' : threshold >= 200 ? 'EXCELLENT' : 'GREAT';
        
        const message = `${emoji} **PERFORMANCE ALERT** ${emoji}

💎 **${token.name}** (${token.symbol}) is performing ${performance}!

📈 **Gain:** +${gainPercent.toFixed(1)}% from discovery price
💰 **Current Price:** $${token.lastPrice?.toFixed(8) || 'N/A'}
⏰ **Time Since Posted:** ${Math.floor((Date.now() - token.postedAt) / (1000 * 60 * 60))}h ago

🔗 **Contract:** \`${token.address}\`

🎯 **Discovery Success** | 🤖 @BONKbot`;

        await telegramService.sendMessage(config.channelId, message);
        console.log(`🚀 Sent ${threshold}% gain alert for ${token.symbol}`);
        
        await storage.createActivityLog({
          type: 'performance_alert',
          message: `${token.symbol} gained ${gainPercent.toFixed(1)}%`,
          status: 'success'
        });
        
        break; // Only send one alert per check cycle
      }
    }
  }

  private async checkWhaleActivity(data: BotData, config: any): Promise<void> {
    try {
      if (!data.tracked || data.tracked.length === 0) return;

      console.log(`🐋 Checking whale activity for ${data.tracked.length} tokens...`);
      
      const birdeyeApiKey = process.env.BIRDEYE_API_KEY;
      if (!birdeyeApiKey) return;

      for (const trackedToken of data.tracked) {
        // Skip tokens posted less than 1 hour ago
        if (Date.now() - trackedToken.postedAt < 3600000) continue;

        try {
          // Check for large transactions using Birdeye trades API
          const response = await fetch(`https://public-api.birdeye.so/defi/trades?address=${trackedToken.address}&limit=10`, {
            headers: { 'X-API-KEY': birdeyeApiKey }
          });

          if (!response.ok) continue;

          const tradesData = await response.json();
          const trades = tradesData.data?.items || [];

          // Analyze recent trades for whale activity
          for (const trade of trades) {
            const tradeTime = new Date(trade.blockUnixTime * 1000);
            const timeSincePosted = Date.now() - trackedToken.postedAt;
            const timeSinceTrade = Date.now() - tradeTime.getTime();
            
            // Only check trades that happened after we posted the token
            if (tradeTime.getTime() <= trackedToken.postedAt) continue;
            
            // Skip trades older than 4 hours
            if (timeSinceTrade > 14400000) continue;

            const tradeValueUSD = parseFloat(trade.volumeInUsd || '0');
            const isBuy = trade.side === 'buy';
            
            // Define whale thresholds
            const whaleThresholds = [
              { min: 10000, label: 'Large' },     // $10K+
              { min: 50000, label: 'Whale' },     // $50K+
              { min: 100000, label: 'Mega' },     // $100K+
              { min: 500000, label: 'Ultra' }     // $500K+
            ];

            for (const threshold of whaleThresholds) {
              if (tradeValueUSD >= threshold.min && isBuy) {
                const alertKey = `${threshold.label}-${Math.floor(tradeValueUSD / 1000)}k`;
                
                if (!trackedToken.whaleAlerts) trackedToken.whaleAlerts = [];
                
                if (!trackedToken.whaleAlerts.includes(alertKey)) {
                  trackedToken.whaleAlerts.push(alertKey);
                  await this.sendWhaleAlert(trackedToken, trade, threshold, config);
                  break; // Only send one alert per trade
                }
              }
            }
          }

        } catch (error) {
          console.log(`Whale check failed for ${trackedToken.symbol}:`, (error as Error).message);
        }
      }

    } catch (error) {
      console.log('Whale activity check error:', (error as Error).message);
    }
  }

  private async sendWhaleAlert(token: any, trade: any, threshold: any, config: any): Promise<void> {
    try {
      const tradeValue = parseFloat(trade.volumeInUsd);
      const tradeTime = new Date(trade.blockUnixTime * 1000);
      const hoursAgo = Math.floor((Date.now() - tradeTime.getTime()) / (1000 * 60 * 60));
      const minutesAgo = Math.floor(((Date.now() - tradeTime.getTime()) % (1000 * 60 * 60)) / (1000 * 60));
      
      const timeAgo = hoursAgo > 0 ? `${hoursAgo}h ${minutesAgo}m ago` : `${minutesAgo}m ago`;
      
      const emoji = threshold.label === 'Ultra' ? '🐋🐋🐋' : 
                   threshold.label === 'Mega' ? '🐋🐋' : 
                   threshold.label === 'Whale' ? '🐋' : '🦈';

      const message = `${emoji} **${threshold.label.toUpperCase()} WHALE ALERT** ${emoji}

💎 **${token.name}** (${token.symbol})

🐋 **${threshold.label} Buy Detected:**
💰 Trade Value: $${tradeValue.toLocaleString()}
⏰ Time: ${timeAgo}
📊 Price: $${parseFloat(trade.price || '0').toFixed(8)}

🔗 **Contract:** \`${token.address}\`
📈 **Wallet:** \`${trade.owner || 'Unknown'}\`

💡 **Smart money is accumulating!** | 🤖 @BONKbot`;

      await telegramService.sendMessage(config.channelId, message);
      console.log(`🐋 Sent ${threshold.label} whale alert for ${token.symbol}: $${tradeValue.toLocaleString()}`);
      
      await storage.createActivityLog({
        type: 'whale_alert',
        message: `${threshold.label} whale bought $${tradeValue.toLocaleString()} of ${token.symbol}`,
        status: 'success'
      });

    } catch (error) {
      console.log('Whale alert send failed:', (error as Error).message);
    }
  }

  getStatus(): { queueSize: number; lastPost: number; lastDiscovery: number; trackedTokens: number } {
    const data = this.loadData();
    const unposted = data.queue.filter(t => !t.posted).length;
    
    return {
      queueSize: unposted,
      lastPost: data.lastPost,
      lastDiscovery: data.lastDiscovery,
      trackedTokens: data.tracked?.length || 0
    };
  }
}

export const statelessBot = new StatelessBot();