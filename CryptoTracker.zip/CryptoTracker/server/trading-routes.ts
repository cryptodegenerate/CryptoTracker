import { Router } from 'express';
import { autoTrader } from './auto-trader';

export const tradingRouter = Router();

// Get trading status
tradingRouter.get('/status', async (req, res) => {
  try {
    const status = autoTrader.getTradingStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get trading status' });
  }
});

// Update trading configuration
tradingRouter.post('/config', async (req, res) => {
  try {
    const config = req.body;
    autoTrader.updateConfig(config);
    res.json({ success: true, message: 'Trading config updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update trading config' });
  }
});

// Get active positions
tradingRouter.get('/positions', async (req, res) => {
  try {
    const status = autoTrader.getTradingStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get positions' });
  }
});

// Manual position check
tradingRouter.post('/check-positions', async (req, res) => {
  try {
    await autoTrader.checkPositions();
    res.json({ success: true, message: 'Position check completed' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to check positions' });
  }
});

// Test buy functionality
tradingRouter.post('/test-buy', async (req, res) => {
  try {
    const { tokenAddress, symbol, price } = req.body;
    const mockToken = {
      address: tokenAddress,
      symbol,
      name: symbol,
      price: price.toString(),
      liquidity: '15000',
      marketCap: '500000',
      volume24h: '2000'
    };
    
    const canBuy = await autoTrader.evaluateTokenForPurchase(mockToken);
    if (canBuy) {
      const success = await autoTrader.executeJupiterBuy(mockToken);
      res.json({ success, canBuy, message: success ? 'Test buy executed' : 'Buy failed' });
    } else {
      res.json({ success: false, canBuy: false, message: 'Token does not meet trading criteria' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Test buy failed' });
  }
});