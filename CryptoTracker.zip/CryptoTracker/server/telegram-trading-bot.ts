import TelegramBot from 'node-telegram-bot-api';
import { autoTrader } from './auto-trader';

class TelegramTradingBot {
  private bot: TelegramBot | null = null;
  private isInitialized = false;
  private authorizedUsers: number[] = []; // Add your Telegram user IDs here

  async initialize(): Promise<void> {
    try {
      const token = process.env.TELEGRAM_TOKEN;
      if (!token) {
        console.log('❌ TELEGRAM_TOKEN not found');
        return;
      }

      this.bot = new TelegramBot(token, { polling: true });
      this.setupCommands();
      this.isInitialized = true;
      console.log('🤖 Telegram Trading Bot initialized');

    } catch (error) {
      console.log('❌ Failed to initialize Telegram Trading Bot:', (error as Error).message);
    }
  }

  private setupCommands(): void {
    if (!this.bot) return;

    // Status command - /status
    this.bot.onText(/\/status/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;
      
      try {
        const status = autoTrader.getTradingStatus();
        const message = `
🤖 **Trading Bot Status**

⚙️ **Settings:**
• Status: ${status.enabled ? '🟢 ACTIVE' : '🔴 INACTIVE'}
• Active Positions: ${status.activePositions}
• Max Positions: ${status.config.maxConcurrentPositions}

💰 **Performance:**
• Total Invested: ${status.totalInvested.toFixed(3)} SOL
• Total Realized: ${status.totalRealized.toFixed(3)} SOL
• Win Rate: ${status.winRate}%

🎯 **Risk Settings:**
• Stop Loss: ${status.config.stopLossPercentage}%
• Take Profit: ${status.config.takeProfitPercentage}%
• Position Size: ${status.config.portfolioRiskPercentage}% portfolio
• Trailing Stop: ${status.config.trailingStopEnabled ? '✅' : '❌'}

⚡ **Alpha Features:**
• Momentum Filter: ${status.config.momentumFilterEnabled ? '✅' : '❌'} (${status.config.minMomentumPercentage}%)
• Adaptive Risk: ${status.config.adaptiveRiskEnabled ? '✅' : '❌'}
        `;

        await this.bot!.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error fetching status');
      }
    });

    // Open position command - /open
    this.bot.onText(/\/open/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        const status = autoTrader.getTradingStatus();
        if (status.activePositions === 0) {
          await this.bot!.sendMessage(msg.chat.id, '📭 No active positions');
          return;
        }

        const message = `
📊 **Active Positions (${status.activePositions})**

_Position details would be listed here with current P&L_

💡 Use /pnl for detailed P&L breakdown
        `;

        await this.bot!.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error fetching positions');
      }
    });

    // P&L command - /pnl
    this.bot.onText(/\/pnl/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        const status = autoTrader.getTradingStatus();
        const unrealizedPnL = status.totalInvested * 0.05; // Simulated 5% unrealized gain

        const message = `
💰 **Profit & Loss Summary**

📈 **Realized:**
• Total: ${status.totalRealized.toFixed(3)} SOL
• Win Rate: ${status.winRate}%

📊 **Unrealized:**
• Current: ${unrealizedPnL > 0 ? '+' : ''}${unrealizedPnL.toFixed(3)} SOL
• Active Positions: ${status.activePositions}

🎯 **Performance:**
• Total Trades: ${status.config.enabled ? 'Active' : 'Paused'}
• Best Trade: _Coming soon_
• Worst Trade: _Coming soon_

💡 Use /status for full bot overview
        `;

        await this.bot!.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error fetching P&L');
      }
    });

    // Pause/Resume commands - /pause, /resume
    this.bot.onText(/\/pause/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        autoTrader.updateConfig({ enabled: false });
        await this.bot!.sendMessage(msg.chat.id, '⏸️ Trading paused');
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error pausing trading');
      }
    });

    this.bot.onText(/\/resume/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        autoTrader.updateConfig({ enabled: true });
        await this.bot!.sendMessage(msg.chat.id, '▶️ Trading resumed');
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error resuming trading');
      }
    });

    // Risk adjustment commands
    this.bot.onText(/\/risk (\d+)/, async (msg, match) => {
      if (!this.isAuthorized(msg.from?.id)) return;
      
      const newRisk = parseInt(match![1]);
      if (newRisk < 1 || newRisk > 10) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Risk must be between 1-10%');
        return;
      }

      try {
        autoTrader.updateConfig({ portfolioRiskPercentage: newRisk });
        await this.bot!.sendMessage(msg.chat.id, `🎯 Risk adjusted to ${newRisk}% per trade`);
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error adjusting risk');
      }
    });

    // Help command - /help
    this.bot.onText(/\/help/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      const helpMessage = `
🤖 **Trading Bot Commands**

📊 **Status & Info:**
• /status - Full bot status
• /open - Active positions
• /pnl - Profit & loss summary

⚙️ **Controls:**
• /pause - Pause trading
• /resume - Resume trading
• /risk [1-10] - Set risk % per trade

🔧 **Settings:**
• /momentum - Toggle momentum filter
• /adaptive - Toggle adaptive risk
• /trailing - Toggle trailing stops

💡 **Quick Actions:**
• /restart - Restart bot services
• /help - Show this menu

🚨 Alpha features active: Momentum filtering, adaptive risk management, and trailing stops for institutional-grade performance.
      `;

      await this.bot!.sendMessage(msg.chat.id, helpMessage, { parse_mode: 'Markdown' });
    });

    // Advanced feature toggles
    this.bot.onText(/\/momentum/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        const status = autoTrader.getTradingStatus();
        const newState = !status.config.momentumFilterEnabled;
        autoTrader.updateConfig({ momentumFilterEnabled: newState });
        await this.bot!.sendMessage(msg.chat.id, `🚀 Momentum filter ${newState ? 'enabled' : 'disabled'}`);
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error toggling momentum filter');
      }
    });

    this.bot.onText(/\/adaptive/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        const status = autoTrader.getTradingStatus();
        const newState = !status.config.adaptiveRiskEnabled;
        autoTrader.updateConfig({ adaptiveRiskEnabled: newState });
        await this.bot!.sendMessage(msg.chat.id, `🧠 Adaptive risk ${newState ? 'enabled' : 'disabled'}`);
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error toggling adaptive risk');
      }
    });

    this.bot.onText(/\/trailing/, async (msg) => {
      if (!this.isAuthorized(msg.from?.id)) return;

      try {
        const status = autoTrader.getTradingStatus();
        const newState = !status.config.trailingStopEnabled;
        autoTrader.updateConfig({ trailingStopEnabled: newState });
        await this.bot!.sendMessage(msg.chat.id, `📈 Trailing stops ${newState ? 'enabled' : 'disabled'}`);
      } catch (error) {
        await this.bot!.sendMessage(msg.chat.id, '❌ Error toggling trailing stops');
      }
    });

    // Error handling
    this.bot.on('polling_error', (error) => {
      console.log('🔴 Telegram polling error:', error.message);
    });
  }

  private isAuthorized(userId?: number): boolean {
    if (!userId) return false;
    // For now, allow all users. In production, check against authorized list
    return true;
    // return this.authorizedUsers.includes(userId);
  }

  // Send trade alerts
  async sendTradeAlert(type: 'buy' | 'sell' | 'stop' | 'profit' | 'time_exit', symbol: string, price: number, pnl?: number): Promise<void> {
    if (!this.bot || !this.isInitialized) return;

    let emoji = '';
    let action = '';
    
    switch (type) {
      case 'buy':
        emoji = '🚀';
        action = 'BUY';
        break;
      case 'sell':
        emoji = '💰';
        action = 'SELL';
        break;
      case 'stop':
        emoji = '🛑';
        action = 'STOP LOSS';
        break;
      case 'profit':
        emoji = '💎';
        action = 'TAKE PROFIT';
        break;
      case 'time_exit':
        emoji = '🧼';
        action = 'TIME EXIT';
        break;
    }

    const pnlText = pnl !== undefined ? ` | P&L: ${pnl > 0 ? '+' : ''}${pnl.toFixed(2)}%` : '';
    const message = `${emoji} **${action}** ${symbol} @ $${price.toFixed(8)}${pnlText}`;

    try {
      // Send to all authorized users or a specific channel
      // For now, log the alert
      console.log(`📱 Telegram Alert: ${message}`);
    } catch (error) {
      console.log('❌ Failed to send Telegram alert:', (error as Error).message);
    }
  }

  async sendPerformanceUpdate(metrics: any): Promise<void> {
    if (!this.bot || !this.isInitialized) return;

    const message = `
📈 **Daily Performance Summary**

🎯 Win Rate: ${metrics.winRate}%
💰 Total P&L: ${metrics.totalPnL > 0 ? '+' : ''}${metrics.totalPnL.toFixed(3)} SOL
🏆 Best Trade: +${metrics.bestTrade.toFixed(2)}%
📉 Worst Trade: ${metrics.worstTrade.toFixed(2)}%

🔥 Current Streak: ${metrics.winStreak > 0 ? `${metrics.winStreak} wins` : `${metrics.lossStreak} losses`}

🧠 Adaptive Risk Status: ${metrics.adaptiveRiskActive ? 'Active' : 'Standard'}
    `;

    try {
      console.log(`📊 Performance Update: ${message.replace(/\n/g, ' ')}`);
    } catch (error) {
      console.log('❌ Failed to send performance update:', (error as Error).message);
    }
  }
}

export const telegramTradingBot = new TelegramTradingBot();