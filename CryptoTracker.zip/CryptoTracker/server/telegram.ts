import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';

let botInstance: TelegramBot | null = null;

export interface TelegramMessage {
  tokenName: string;
  tokenSymbol: string;
  tokenAddress: string;
  liquidity: string;
  price: string;
  classification?: "green" | "yellow" | "red";
  riskScore?: number;
  qualityMetrics?: string;
  source?: string;
  createdAt?: string;
  ageInHours?: string;
}

export class TelegramService {
  private bot: TelegramBot | null = null;
  private isConnected = false;

  async cleanup(): Promise<void> {
    if (this.bot) {
      try {
        await this.bot.stopPolling();
        this.bot.removeAllListeners();
      } catch (error) {
        console.log('Error during bot cleanup:', error);
      }
      this.bot = null;
      this.isConnected = false;
    }
  }

  async initialize(token: string): Promise<boolean> {
    try {
      // Close any existing bot instance first
      if (this.bot) {
        await this.cleanup();
      }
      
      // Close global bot instance if it exists
      if (botInstance) {
        try {
          await botInstance.stopPolling();
        } catch (e) {
          // Ignore errors when stopping polling
        }
        botInstance = null;
      }
      
      this.bot = new TelegramBot(token, { 
        polling: {
          interval: 1000,
          autoStart: true,
          params: {
            timeout: 10
          }
        }
      });
      
      await this.bot.getMe();
      this.isConnected = true;
      botInstance = this.bot;
      
      // Set up command handlers
      this.setupCommands();
      
      await storage.createActivityLog({
        type: 'bot_start',
        message: 'Telegram bot connected successfully with command interface',
        status: 'success',
      });
      
      return true;
    } catch (error) {
      this.isConnected = false;
      await storage.createActivityLog({
        type: 'bot_start',
        message: 'Failed to connect to Telegram bot',
        status: 'error',
        details: JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      });
      throw error;
    }
  }

  private setupCommands(): void {
    if (!this.bot) return;

    // Set bot commands menu
    this.bot.setMyCommands([
      { command: 'search', description: 'Search for tokens manually' },
      { command: 'status', description: 'Check bot monitoring status' },
      { command: 'latest', description: 'Get latest token discoveries' },
      { command: 'stats', description: 'View bot statistics' },
      { command: 'help', description: 'Show available commands' }
    ]);

    // Handle /search command
    this.bot.onText(/\/search/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const { monitoringService } = await import('./monitoring');
        await monitoringService.manualCheck();
        this.bot?.sendMessage(chatId, '🔍 Manual token search initiated! Scanning both pump.fun and DexScreener for new discoveries...');
        
        await storage.createActivityLog({
          type: 'manual_search',
          message: `Manual search triggered by user ${msg.from?.username || msg.from?.id}`,
          status: 'success',
        });
      } catch (error) {
        this.bot?.sendMessage(chatId, '❌ Search failed. Please try again.');
      }
    });

    // Handle /status command
    this.bot.onText(/\/status/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const { monitoringService } = await import('./monitoring');
        const isMonitoring = monitoringService.isMonitoringActive();
        const lastCheck = monitoringService.getLastCheckTime();
        const config = await storage.getBotConfiguration();
        
        const statusMsg = `🤖 **Bot Status**\n\n` +
          `📊 Monitoring: ${isMonitoring ? '✅ Active' : '❌ Inactive'}\n` +
          `🔗 Telegram: ${this.isConnected ? '✅ Connected' : '❌ Disconnected'}\n` +
          `⏰ Last Check: ${lastCheck.toLocaleString()}\n` +
          `🔍 Platforms: pump.fun + DexScreener\n` +
          `⚡ Interval: ${config?.monitoringInterval || 5} minutes\n` +
          `🎯 Max Tokens: ${config?.maxTokens || 10}`;
        
        this.bot?.sendMessage(chatId, statusMsg, { parse_mode: 'Markdown' });
      } catch (error) {
        this.bot?.sendMessage(chatId, '❌ Failed to get status.');
      }
    });

    // Handle /latest command
    this.bot.onText(/\/latest/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const tokens = await storage.getUnpostedTokens();
        if (tokens.length === 0) {
          this.bot?.sendMessage(chatId, '📭 No recent token discoveries. Use /search to scan manually.');
          return;
        }

        const latestTokens = tokens.slice(-3); // Get last 3 tokens
        let response = '🔥 **Latest Token Discoveries**\n\n';
        
        latestTokens.forEach((token, index) => {
          const riskEmoji = token.classification === 'green' ? '🟢' : 
                           token.classification === 'yellow' ? '🟡' : '🔴';
          response += `${riskEmoji} **${token.tokenName}** (${token.tokenSymbol})\n`;
          response += `💰 Price: ${token.price}\n`;
          response += `💧 Liquidity: ${token.liquidity}\n`;
          response += `📈 Risk Score: ${token.riskScore}/100\n`;
          response += `📍 Address: \`${token.tokenAddress}\`\n\n`;
        });

        this.bot?.sendMessage(chatId, response, { parse_mode: 'Markdown' });
      } catch (error) {
        this.bot?.sendMessage(chatId, '❌ Failed to get latest tokens.');
      }
    });

    // Handle /stats command
    this.bot.onText(/\/stats/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const stats = await storage.getBotStats();
        const activity = await storage.getActivityLogs(10);
        
        const statsMsg = `📊 **Bot Statistics**\n\n` +
          `📝 Total Posts: ${stats?.totalPosts || 0}\n` +
          `📅 Today: ${stats?.todayPosts || 0}\n` +
          `📈 This Week: ${stats?.weekPosts || 0}\n` +
          `✅ Success Rate: ${stats?.successRate || '0%'}\n` +
          `⚡ Avg Response: ${stats?.avgResponseTime || '0s'}\n` +
          `🕐 Uptime: ${stats?.uptime || '0h'}\n\n` +
          `📋 Recent Activity: ${activity.length} events`;
        
        this.bot?.sendMessage(chatId, statsMsg, { parse_mode: 'Markdown' });
      } catch (error) {
        this.bot?.sendMessage(chatId, '❌ Failed to get statistics.');
      }
    });

    // Handle /help command
    this.bot.onText(/\/help/, async (msg) => {
      const chatId = msg.chat.id;
      const helpMsg = `🤖 **Solana Memecoin Bot Commands**\n\n` +
        `🔍 /search - Manually scan for new tokens\n` +
        `📊 /status - Check monitoring status\n` +
        `🔥 /latest - View recent discoveries\n` +
        `📈 /stats - Show bot statistics\n` +
        `❓ /help - Show this help menu\n\n` +
        `**About the Bot:**\n` +
        `• Monitors pump.fun and DexScreener\n` +
        `• Uses traffic light risk system (🟢🟡🔴)\n` +
        `• Scans every 5 minutes automatically\n` +
        `• Filters for quality tokens only`;
      
      this.bot?.sendMessage(chatId, helpMsg, { parse_mode: 'Markdown' });
    });

    // Handle unknown commands
    this.bot.on('message', (msg) => {
      if (msg.text?.startsWith('/') && !msg.text.match(/\/(search|status|latest|stats|help)/)) {
        this.bot?.sendMessage(msg.chat.id, '❓ Unknown command. Use /help to see available commands.');
      }
    });
  }

  async testConnection(token: string): Promise<boolean> {
    try {
      const testBot = new TelegramBot(token, { polling: false });
      await testBot.getMe();
      return true;
    } catch (error) {
      return false;
    }
  }

  private formatSafetyFilters(qualityMetrics?: string): string {
    if (!qualityMetrics) return '';
    
    try {
      const metrics = JSON.parse(qualityMetrics);
      const reasons = metrics.reasons || [];
      
      let safetySection = '\n\n🔒 SAFETY FILTERS:\n';
      
      // Parse filter results from reasons
      const filterResults = {
        liquidity: reasons.some((r: string) => r.includes('Liquidity under')) ? '❌' : '✅',
        liquidityLocked: reasons.some((r: string) => r.includes('not locked')) ? '❌' : '✅',
        mintRevoked: reasons.some((r: string) => r.includes('Mint authority')) ? '❌' : '✅',
        freezeRevoked: reasons.some((r: string) => r.includes('Freeze authority')) ? '❌' : '✅',
        holderLimit: reasons.some((r: string) => r.includes('Top holder exceeds')) ? '❌' : '✅',
        volume: reasons.some((r: string) => r.includes('volume under')) ? '❌' : '✅',
        holders: reasons.some((r: string) => r.includes('holders required')) ? '❌' : '✅',
        tokenAge: reasons.some((r: string) => r.includes('age outside')) ? '❌' : '✅',
        twitter: reasons.some((r: string) => r.includes('Twitter followers')) ? '⚠️' : '✅',
        telegram: reasons.some((r: string) => r.includes('Telegram community')) ? '⚠️' : '✅'
      };
      
      safetySection += `${filterResults.liquidity} Liquidity ($100K+)\n`;
      safetySection += `${filterResults.liquidityLocked} Liquidity Locked\n`;
      safetySection += `${filterResults.mintRevoked} Mint Authority Revoked\n`;
      safetySection += `${filterResults.freezeRevoked} Freeze Authority Revoked\n`;
      safetySection += `${filterResults.holderLimit} Top Holder <10%\n`;
      safetySection += `${filterResults.volume} Daily Volume ($10K+)\n`;
      safetySection += `${filterResults.holders} Holders (300+)\n`;
      safetySection += `${filterResults.tokenAge} Token Age (10min-6h)\n`;
      safetySection += `${filterResults.twitter} Twitter Presence\n`;
      safetySection += `${filterResults.telegram} Telegram Community`;
      
      // Add specific failure reasons
      const failures = reasons.filter((r: string) => r.includes('❌')).slice(0, 3);
      if (failures.length > 0) {
        safetySection += '\n\n⚠️ ISSUES:\n';
        failures.forEach((failure: string) => {
          safetySection += `• ${failure.replace('❌ ', '')}\n`;
        });
      }
      
      return safetySection;
    } catch (error) {
      return '';
    }
  }

  async sendTokenMessage(channelId: string, tokenData: TelegramMessage): Promise<boolean> {
    if (!this.bot || !this.isConnected) {
      throw new Error('Bot not initialized or connected');
    }

    // Get classification emoji and label
    const getClassificationEmoji = (classification?: string) => {
      switch (classification) {
        case 'green': return '🟢';
        case 'yellow': return '🟡';
        case 'red': return '🔴';
        default: return '⚪';
      }
    };

    const getClassificationLabel = (classification?: string) => {
      switch (classification) {
        case 'green': return 'LOW RISK';
        case 'yellow': return 'MODERATE RISK';
        case 'red': return 'HIGH RISK';
        default: return 'UNCLASSIFIED';
      }
    };

    const riskInfo = tokenData.classification ? 
      `\n${getClassificationEmoji(tokenData.classification)} Risk Level: ${getClassificationLabel(tokenData.classification)}
⚠️ Risk Score: ${tokenData.riskScore}/100` : '';

    const sourceInfo = tokenData.source ? `\n🔍 Source: ${tokenData.source}` : '';
    
    // Format creation time
    const creationInfo = tokenData.createdAt ? 
      `\n🕐 Created: ${new Date(tokenData.createdAt).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'UTC'
      })} UTC` : '';

    // Add detailed safety filter information
    const safetyFilters = this.formatSafetyFilters(tokenData.qualityMetrics);

    // Display token age from ageInHours field
    const tokenAgeDisplay = tokenData.ageInHours ? `\n⏰ Age: ${tokenData.ageInHours}` : '';

    const message = `🔥 New Solana Memecoin Listed!

📛 Name: ${tokenData.tokenName}
🪙 Symbol: ${tokenData.tokenSymbol}
💧 Liquidity: ${tokenData.liquidity}
📈 Price: ${tokenData.price} SOL${tokenAgeDisplay}${riskInfo}${sourceInfo}${creationInfo}${safetyFilters}

📊 Chart: https://birdeye.so/token/${tokenData.tokenAddress}
🔗 Address: ${tokenData.tokenAddress}
#solana #memecoin`;

    try {
      await this.bot.sendMessage(channelId, message);
      
      await storage.createActivityLog({
        type: 'token_post',
        message: `Posted ${tokenData.tokenSymbol} token to ${channelId}`,
        status: 'success',
        details: JSON.stringify(tokenData),
      });
      
      return true;
    } catch (error) {
      await storage.createActivityLog({
        type: 'token_post',
        message: `Failed to post ${tokenData.tokenSymbol} token to ${channelId}`,
        status: 'error',
        details: JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error', tokenData }),
      });
      throw error;
    }
  }

  async sendManualMessage(channelId: string, message: string): Promise<boolean> {
    if (!this.bot || !this.isConnected) {
      throw new Error('Bot not initialized or connected');
    }

    try {
      console.log(`Attempting to send message to ${channelId}: ${message}`);
      await this.bot.sendMessage(channelId, message);
      
      await storage.createActivityLog({
        type: 'manual_post',
        message: `Manual message sent to ${channelId}`,
        status: 'success',
        details: JSON.stringify({ message }),
      });
      
      return true;
    } catch (error) {
      console.error('Telegram sendMessage error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      await storage.createActivityLog({
        type: 'manual_post',
        message: `Failed to send manual message to ${channelId}: ${errorMessage}`,
        status: 'error',
        details: JSON.stringify({ error: errorMessage, message, channelId }),
      });
      throw new Error(`Telegram error: ${errorMessage}`);
    }
  }

  isConnectedToTelegram(): boolean {
    return this.isConnected;
  }

  async disconnect(): Promise<void> {
    await this.cleanup();
    if (botInstance) {
      botInstance = null;
    }
  }
}

export const telegramService = new TelegramService();
