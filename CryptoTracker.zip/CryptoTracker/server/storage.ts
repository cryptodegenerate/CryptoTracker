import { 
  type BotConfiguration, 
  type InsertBotConfiguration,
  type ActivityLog,
  type InsertActivityLog,
  type TokenPost,
  type InsertTokenPost,
  type BotStats,
  type InsertBotStats,
  type LeaderboardEntry,
  type InsertLeaderboardEntry,
  type UserScore,
  type InsertUserScore,
  type Achievement,
  type InsertAchievement,
  type PostingState,
  type InsertPostingState
} from "@shared/schema";

export interface IStorage {
  // Bot Configuration
  getBotConfiguration(): Promise<BotConfiguration | undefined>;
  createOrUpdateBotConfiguration(config: InsertBotConfiguration): Promise<BotConfiguration>;
  
  // Activity Logs
  getActivityLogs(limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  clearActivityLogs(): Promise<void>;
  
  // Token Posts
  getTokenPost(tokenAddress: string): Promise<TokenPost | undefined>;
  createTokenPost(post: InsertTokenPost): Promise<TokenPost>;
  markTokenAsPosted(tokenAddress: string): Promise<void>;
  getUnpostedTokens(): Promise<TokenPost[]>;
  getAllStoredTokens(): Promise<TokenPost[]>;
  
  // Bot Stats
  getBotStats(): Promise<BotStats | undefined>;
  createOrUpdateBotStats(stats: Partial<InsertBotStats>): Promise<BotStats>;
  
  // Leaderboard
  getLeaderboard(limit?: number, sortBy?: string): Promise<LeaderboardEntry[]>;
  getLeaderboardEntry(tokenAddress: string): Promise<LeaderboardEntry | undefined>;
  createOrUpdateLeaderboardEntry(entry: InsertLeaderboardEntry): Promise<LeaderboardEntry>;
  updateTokenPerformance(tokenAddress: string, performance: Partial<LeaderboardEntry>): Promise<void>;
  getTopPerformers(timeframe: string, limit?: number): Promise<LeaderboardEntry[]>;
  
  // User Scores
  getUserScore(userId: string): Promise<UserScore | undefined>;
  createOrUpdateUserScore(score: InsertUserScore): Promise<UserScore>;
  getUserLeaderboard(limit?: number): Promise<UserScore[]>;
  updateUserPoints(userId: string, points: number): Promise<void>;
  
  // Achievements
  getAchievements(): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  getUserAchievements(userId: string): Promise<Achievement[]>;
  unlockAchievement(userId: string, achievementId: number): Promise<void>;
  
  // Posting State
  getPostingState(): Promise<PostingState | undefined>;
  updatePostingState(state: Partial<InsertPostingState>): Promise<PostingState>;
}

export class MemStorage implements IStorage {
  private botConfiguration: BotConfiguration | undefined;
  private activityLogs: Map<number, ActivityLog>;
  private tokenPosts: Map<string, TokenPost>;
  private botStats: BotStats | undefined;
  private leaderboardEntries: Map<string, LeaderboardEntry>;
  private userScores: Map<string, UserScore>;
  private achievements: Map<number, Achievement>;
  private postingState: PostingState | undefined;
  private currentLogId: number;
  private currentTokenId: number;
  private currentLeaderboardId: number;
  private currentUserScoreId: number;
  private currentAchievementId: number;

  constructor() {
    this.activityLogs = new Map();
    this.tokenPosts = new Map();
    this.leaderboardEntries = new Map();
    this.userScores = new Map();
    this.achievements = new Map();
    this.currentLogId = 1;
    this.currentTokenId = 1;
    this.currentLeaderboardId = 1;
    this.currentUserScoreId = 1;
    this.currentAchievementId = 1;
    this.initializeDefaultAchievements();
  }

  async getBotConfiguration(): Promise<BotConfiguration | undefined> {
    return this.botConfiguration;
  }

  async createOrUpdateBotConfiguration(config: InsertBotConfiguration): Promise<BotConfiguration> {
    const now = new Date();
    const defaults = {
      monitoringInterval: 5,
      maxTokens: 10,
      isActive: false,
      minLiquidity: 100000,
      requireLiquidityLocked: true,
      requireMintRevoked: true,
      requireFreezeRevoked: true,
      maxTopHolderPercent: 10,
      minHolders: 300,
      minDailyVolume: 10000,
      minTokenAge: 10,
      maxTokenAge: 360,
      minTwitterFollowers: 100,
    };

    if (this.botConfiguration) {
      this.botConfiguration = {
        ...this.botConfiguration,
        ...config,
        updatedAt: now,
      };
    } else {
      this.botConfiguration = {
        id: 1,
        ...defaults,
        ...config,
        createdAt: now,
        updatedAt: now,
      };
    }
    return this.botConfiguration;
  }

  async getActivityLogs(limit = 50): Promise<ActivityLog[]> {
    const logs = Array.from(this.activityLogs.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return logs;
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentLogId++;
    const activityLog: ActivityLog = {
      id,
      type: log.type,
      message: log.message,
      status: log.status,
      details: log.details || null,
      timestamp: new Date(),
    };
    this.activityLogs.set(id, activityLog);
    return activityLog;
  }

  async clearActivityLogs(): Promise<void> {
    this.activityLogs.clear();
    this.currentLogId = 1;
  }

  async getTokenPost(tokenAddress: string): Promise<TokenPost | undefined> {
    return this.tokenPosts.get(tokenAddress);
  }

  async createTokenPost(post: InsertTokenPost): Promise<TokenPost> {
    const id = this.currentTokenId++;
    const tokenPost: TokenPost = {
      id,
      ...post,
      classification: post.classification || "yellow",
      riskScore: post.riskScore || 50,
      qualityMetrics: post.qualityMetrics || null,
      posted: false,
      postedAt: null,
      createdAt: new Date(),
    };
    this.tokenPosts.set(post.tokenAddress, tokenPost);
    return tokenPost;
  }

  async markTokenAsPosted(tokenAddress: string): Promise<void> {
    const token = this.tokenPosts.get(tokenAddress);
    if (token) {
      token.posted = true;
      token.postedAt = new Date();
    }
  }

  async getUnpostedTokens(): Promise<TokenPost[]> {
    return Array.from(this.tokenPosts.values()).filter(token => !token.posted);
  }

  async getAllStoredTokens(): Promise<TokenPost[]> {
    return Array.from(this.tokenPosts.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getBotStats(): Promise<BotStats | undefined> {
    return this.botStats;
  }

  async createOrUpdateBotStats(stats: Partial<InsertBotStats>): Promise<BotStats> {
    if (this.botStats) {
      this.botStats = {
        ...this.botStats,
        ...stats,
        lastUpdated: new Date(),
      };
    } else {
      this.botStats = {
        id: 1,
        totalPosts: 0,
        todayPosts: 0,
        weekPosts: 0,
        successRate: "0",
        avgResponseTime: "0s",
        uptime: "0",
        ...stats,
        lastUpdated: new Date(),
      };
    }
    return this.botStats;
  }

  private async initializeDefaultAchievements(): Promise<void> {
    const defaultAchievements = [
      { name: "First Discovery", description: "Discover your first token", icon: "🔍", category: "discovery" as const, requirement: "discover_1_token", points: 100, rarity: "common" as const },
      { name: "Early Bird", description: "Discover 10 tokens", icon: "🐦", category: "discovery" as const, requirement: "discover_10_tokens", points: 500, rarity: "rare" as const },
      { name: "Token Hunter", description: "Discover 50 tokens", icon: "🏹", category: "discovery" as const, requirement: "discover_50_tokens", points: 2500, rarity: "epic" as const },
      { name: "Performance King", description: "Have a token with 100%+ gain", icon: "👑", category: "performance" as const, requirement: "token_100_percent_gain", points: 1000, rarity: "epic" as const },
      { name: "Diamond Hands", description: "Maintain 7-day winning streak", icon: "💎", category: "streak" as const, requirement: "7_day_streak", points: 1500, rarity: "legendary" as const },
      { name: "Whale Spotter", description: "Discover a token with >$1M volume", icon: "🐋", category: "discovery" as const, requirement: "discover_whale_token", points: 2000, rarity: "legendary" as const },
      { name: "Safety First", description: "Discover 10 green-rated tokens", icon: "🛡️", category: "discovery" as const, requirement: "discover_10_green_tokens", points: 750, rarity: "rare" as const },
      { name: "Community Builder", description: "Engage with 25 token communities", icon: "🏘️", category: "community" as const, requirement: "engage_25_communities", points: 1250, rarity: "epic" as const }
    ];

    for (const achievement of defaultAchievements) {
      await this.createAchievement(achievement);
    }
  }

  // Leaderboard methods
  async getLeaderboard(limit = 50, sortBy = "performanceScore"): Promise<LeaderboardEntry[]> {
    const entries = Array.from(this.leaderboardEntries.values());
    
    entries.sort((a, b) => {
      switch (sortBy) {
        case "performance24h":
          return parseFloat(b.performance24h) - parseFloat(a.performance24h);
        case "performance7d":
          return parseFloat(b.performance7d) - parseFloat(a.performance7d);
        case "marketCap":
          return parseFloat(b.marketCap) - parseFloat(a.marketCap);
        case "volume24h":
          return parseFloat(b.volume24h) - parseFloat(a.volume24h);
        case "safetyScore":
          return b.safetyScore - a.safetyScore;
        default:
          return b.performanceScore - a.performanceScore;
      }
    });

    // Update ranks
    entries.forEach((entry, index) => {
      entry.rank = index + 1;
    });

    return entries.slice(0, limit);
  }

  async getLeaderboardEntry(tokenAddress: string): Promise<LeaderboardEntry | undefined> {
    return this.leaderboardEntries.get(tokenAddress);
  }

  async createOrUpdateLeaderboardEntry(entry: InsertLeaderboardEntry): Promise<LeaderboardEntry> {
    const now = new Date();
    const existing = this.leaderboardEntries.get(entry.tokenAddress);
    
    if (existing) {
      const updated: LeaderboardEntry = {
        ...existing,
        ...entry,
        lastUpdated: now,
      };
      this.leaderboardEntries.set(entry.tokenAddress, updated);
      return updated;
    } else {
      const newEntry: LeaderboardEntry = {
        id: this.currentLeaderboardId++,
        ...entry,
        firstSeenAt: now,
        lastUpdated: now,
      };
      this.leaderboardEntries.set(entry.tokenAddress, newEntry);
      return newEntry;
    }
  }

  async updateTokenPerformance(tokenAddress: string, performance: Partial<LeaderboardEntry>): Promise<void> {
    const entry = this.leaderboardEntries.get(tokenAddress);
    if (entry) {
      const updated = {
        ...entry,
        ...performance,
        lastUpdated: new Date(),
      };
      this.leaderboardEntries.set(tokenAddress, updated);
    }
  }

  async getTopPerformers(timeframe: string, limit = 10): Promise<LeaderboardEntry[]> {
    const entries = Array.from(this.leaderboardEntries.values());
    
    entries.sort((a, b) => {
      switch (timeframe) {
        case "1h":
          return parseFloat(b.performance1h) - parseFloat(a.performance1h);
        case "24h":
          return parseFloat(b.performance24h) - parseFloat(a.performance24h);
        case "7d":
          return parseFloat(b.performance7d) - parseFloat(a.performance7d);
        default:
          return b.performanceScore - a.performanceScore;
      }
    });

    return entries.slice(0, limit);
  }

  // User Score methods
  async getUserScore(userId: string): Promise<UserScore | undefined> {
    return this.userScores.get(userId);
  }

  async createOrUpdateUserScore(score: InsertUserScore): Promise<UserScore> {
    const now = new Date();
    const existing = this.userScores.get(score.userId);
    
    if (existing) {
      const updated: UserScore = {
        ...existing,
        ...score,
        lastActive: now,
      };
      this.userScores.set(score.userId, updated);
      return updated;
    } else {
      const newScore: UserScore = {
        id: this.currentUserScoreId++,
        ...score,
        joinedAt: now,
        lastActive: now,
      };
      this.userScores.set(score.userId, newScore);
      return newScore;
    }
  }

  async getUserLeaderboard(limit = 50): Promise<UserScore[]> {
    const scores = Array.from(this.userScores.values())
      .sort((a, b) => b.totalPoints - a.totalPoints)
      .slice(0, limit);

    // Update ranks
    scores.forEach((score, index) => {
      score.rank = index + 1;
    });

    return scores;
  }

  async updateUserPoints(userId: string, points: number): Promise<void> {
    const userScore = this.userScores.get(userId);
    if (userScore) {
      userScore.totalPoints += points;
      userScore.lastActive = new Date();
      
      // Update level based on points
      const newLevel = Math.floor(userScore.totalPoints / 1000) + 1;
      if (newLevel > userScore.level) {
        userScore.level = newLevel;
      }
      
      this.userScores.set(userId, userScore);
    }
  }

  // Achievement methods
  async getAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values())
      .filter(achievement => achievement.isActive)
      .sort((a, b) => a.points - b.points);
  }

  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const newAchievement: Achievement = {
      id: this.currentAchievementId++,
      ...achievement,
      createdAt: new Date(),
    };
    this.achievements.set(newAchievement.id, newAchievement);
    return newAchievement;
  }

  async getUserAchievements(userId: string): Promise<Achievement[]> {
    const userScore = this.userScores.get(userId);
    if (!userScore) return [];
    
    const unlockedAchievementIds = JSON.parse(userScore.achievements) as number[];
    return unlockedAchievementIds
      .map(id => this.achievements.get(id))
      .filter((achievement): achievement is Achievement => achievement !== undefined);
  }

  async unlockAchievement(userId: string, achievementId: number): Promise<void> {
    const userScore = this.userScores.get(userId);
    const achievement = this.achievements.get(achievementId);
    
    if (userScore && achievement) {
      const achievements = JSON.parse(userScore.achievements) as number[];
      if (!achievements.includes(achievementId)) {
        achievements.push(achievementId);
        userScore.achievements = JSON.stringify(achievements);
        userScore.totalPoints += achievement.points;
        userScore.lastActive = new Date();
        this.userScores.set(userId, userScore);
      }
    }
  }

  async getPostingState(): Promise<PostingState | undefined> {
    return this.postingState;
  }

  async updatePostingState(state: Partial<InsertPostingState>): Promise<PostingState> {
    const now = new Date();
    if (!this.postingState) {
      this.postingState = {
        id: 1,
        lastPostTime: state.lastPostTime || now,
        isActive: state.isActive ?? true,
        postDelay: state.postDelay ?? 45000,
        createdAt: now,
        updatedAt: now
      };
    } else {
      this.postingState = {
        ...this.postingState,
        ...state,
        updatedAt: now
      };
    }
    return this.postingState;
  }
}

export const storage = new MemStorage();
