import { storage } from './storage';
import { telegramService } from './telegram-singleton';

export async function forcePost(): Promise<boolean> {
  try {
    console.log('🚀 Force posting triggered');
    
    const config = await storage.getBotConfiguration();
    if (!config?.isActive || !config.telegramToken || !config.channelId) {
      console.log('Bot not configured for posting');
      return false;
    }

    // Get unposted tokens
    const unpostedTokens = await storage.getUnpostedTokens();
    if (unpostedTokens.length === 0) {
      console.log('No tokens to post');
      return false;
    }

    // Post the first token
    const tokenToPost = unpostedTokens[0];
    const success = await postToken(tokenToPost, config);
    
    if (success) {
      await storage.markTokenAsPosted(tokenToPost.tokenAddress);
      
      console.log(`📤 Posted ${tokenToPost.tokenSymbol} - ${unpostedTokens.length - 1} remaining`);
      
      await storage.createActivityLog({
        type: 'token_post',
        message: `Posted ${tokenToPost.tokenSymbol}`,
        status: 'success'
      });
      
      return true;
    }

    return false;
  } catch (error) {
    console.log('Force posting error:', (error as Error).message);
    return false;
  }
}

async function postToken(tokenData: any, config: any): Promise<boolean> {
  try {
    const ageInHours = tokenData.ageInHours || 'Unknown';
    const formattedAge = ageInHours === 'Unknown' ? 'Unknown' : `${Math.round(ageInHours)}h`;
    
    const message = `🔍 **NEW SOLANA TOKEN DISCOVERED** 🔍

💎 **${tokenData.tokenName}** (${tokenData.tokenSymbol})

📊 **Market Data:**
💰 Liquidity: $${tokenData.liquidity?.toLocaleString() || 'N/A'}
💵 Market Cap: $${tokenData.marketCap?.toLocaleString() || 'N/A'}
📈 24h Volume: $${tokenData.volume24h?.toLocaleString() || 'N/A'}
⏰ Age: ${formattedAge}

🔗 **Contract:** \`${tokenData.tokenAddress}\`

⚡ **Discovery Metrics:**
${tokenData.classification === 'green' ? '🟢' : tokenData.classification === 'yellow' ? '🟡' : '🔴'} Risk Level: ${tokenData.classification?.toUpperCase() || 'UNCLASSIFIED'}
📊 Quality Score: ${tokenData.qualityMetrics?.overallScore?.toFixed(1) || 'N/A'}%

🛡️ **Safety Verified** | 🤖 @BONKbot`;

    await telegramService.sendMessage(config.channelId, message);
    return true;
  } catch (error) {
    console.log('Token posting error:', (error as Error).message);
    return false;
  }
}