import { ConfigurationPanel } from "@/components/configuration-panel";
import { StatusSidebar } from "@/components/status-sidebar";
import { ActivityLog } from "@/components/activity-log";
import { useBotStatus } from "@/hooks/use-bot-status";
import { Bot, Settings, Trophy } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Dashboard() {
  const { data: status } = useBotStatus();

  const getConnectionStatus = () => {
    if (status?.isTelegramConnected && status?.isMonitoring) {
      return { text: "Connected", color: "text-green-600", dotColor: "bg-green-500" };
    } else if (status?.isConfigured) {
      return { text: "Configured", color: "text-yellow-600", dotColor: "bg-yellow-500" };
    } else {
      return { text: "Disconnected", color: "text-red-600", dotColor: "bg-red-500" };
    }
  };

  const connectionStatus = getConnectionStatus();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Bot className="h-5 w-5 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-slate-800">Solana Memecoin Bot</h1>
            </div>
            <div className="flex items-center space-x-4">
              <nav className="flex items-center space-x-4">
                <Link href="/" className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors">
                  Dashboard
                </Link>
                <Link href="/leaderboard" className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors flex items-center gap-1">
                  <Trophy className="h-4 w-4" />
                  Leaderboard
                </Link>
              </nav>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${connectionStatus.dotColor} ${status?.isMonitoring ? 'animate-pulse' : ''}`}></div>
                <span className={`text-sm ${connectionStatus.color}`}>{connectionStatus.text}</span>
              </div>
              <button className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Configuration Panel */}
          <div className="lg:col-span-2 space-y-6">
            <ConfigurationPanel />
            <ActivityLog />
          </div>

          {/* Status Sidebar */}
          <div>
            <StatusSidebar />
          </div>
        </div>
      </main>
    </div>
  );
}
