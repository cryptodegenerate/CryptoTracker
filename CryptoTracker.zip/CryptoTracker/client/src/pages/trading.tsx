import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface TradingStatus {
  enabled: boolean;
  activePositions: number;
  totalInvested: number;
  totalRealized: number;
  winRate: string;
  config: {
    maxInvestmentPerToken: number;
    maxConcurrentPositions: number;
    stopLossPercentage: number;
    takeProfitPercentage: number;
    minLiquidity: number;
    maxMarketCap: number;
    slippageTolerance: number;
  };
}

export default function TradingPage() {
  const [status, setStatus] = useState<TradingStatus | null>(null);
  const [config, setConfig] = useState({
    enabled: false,
    maxInvestmentPerToken: 0.1,
    maxConcurrentPositions: 5,
    stopLossPercentage: 20,
    takeProfitPercentage: 100,
    minLiquidity: 10000,
    maxMarketCap: 1000000,
    slippageTolerance: 5,
    // Enhanced settings
    trailingStopEnabled: true,
    trailingStopDistance: 15,
    timeBasedExitHours: 8,
    minTokenAgeMinutes: 15,
    maxDevWalletPercentage: 20,
    minTradeCountPerHour: 25,
    tradeCooldownMinutes: 3,
    portfolioRiskPercentage: 3
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/trading/status');
      const data = await response.json();
      setStatus(data);
      setConfig(data.config);
    } catch (error) {
      console.error('Failed to fetch trading status:', error);
    }
  };

  const updateConfig = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/trading/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      
      if (response.ok) {
        toast({ title: 'Success', description: 'Trading configuration updated' });
        fetchStatus();
      } else {
        toast({ title: 'Error', description: 'Failed to update configuration', variant: 'destructive' });
      }
    } catch (error) {
      toast({ title: 'Error', description: 'Network error', variant: 'destructive' });
    }
    setLoading(false);
  };

  const testBuy = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/trading/test-buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tokenAddress: 'TEST123',
          symbol: 'TEST',
          price: 0.0001
        })
      });
      
      const result = await response.json();
      toast({ 
        title: result.success ? 'Success' : 'Failed',
        description: result.message,
        variant: result.success ? 'default' : 'destructive'
      });
    } catch (error) {
      toast({ title: 'Error', description: 'Test buy failed', variant: 'destructive' });
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Memecoin Auto-Trading</h1>
      
      {/* Trading Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Status</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant={status?.enabled ? 'default' : 'secondary'}>
              {status?.enabled ? 'Active' : 'Disabled'}
            </Badge>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Positions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{status?.activePositions || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total P&L</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {status ? `${(status.totalRealized - status.totalInvested).toFixed(4)} SOL` : '0 SOL'}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{status?.winRate || '0'}%</div>
          </CardContent>
        </Card>
      </div>

      {/* Trading Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Trading Configuration</CardTitle>
          <CardDescription>Configure your auto-trading parameters</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => setConfig({ ...config, enabled: checked })}
            />
            <Label>Enable Auto-Trading</Label>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="investment">Max Investment per Token (SOL)</Label>
              <Input
                id="investment"
                type="number"
                step="0.01"
                value={config.maxInvestmentPerToken}
                onChange={(e) => setConfig({ ...config, maxInvestmentPerToken: parseFloat(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="portfolioRisk">Portfolio Risk per Trade (%)</Label>
              <Input
                id="portfolioRisk"
                type="number"
                step="0.5"
                value={config.portfolioRiskPercentage || 3}
                onChange={(e) => setConfig({ ...config, portfolioRiskPercentage: parseFloat(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="positions">Max Concurrent Positions</Label>
              <Input
                id="positions"
                type="number"
                value={config.maxConcurrentPositions}
                onChange={(e) => setConfig({ ...config, maxConcurrentPositions: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="stoploss">Stop Loss (%)</Label>
              <Input
                id="stoploss"
                type="number"
                value={config.stopLossPercentage}
                onChange={(e) => setConfig({ ...config, stopLossPercentage: parseFloat(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="takeprofit">Take Profit (%)</Label>
              <Input
                id="takeprofit"
                type="number"
                value={config.takeProfitPercentage}
                onChange={(e) => setConfig({ ...config, takeProfitPercentage: parseFloat(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="liquidity">Min Liquidity ($)</Label>
              <Input
                id="liquidity"
                type="number"
                value={config.minLiquidity}
                onChange={(e) => setConfig({ ...config, minLiquidity: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="marketcap">Max Market Cap ($)</Label>
              <Input
                id="marketcap"
                type="number"
                value={config.maxMarketCap}
                onChange={(e) => setConfig({ ...config, maxMarketCap: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="tokenAge">Min Token Age (minutes)</Label>
              <Input
                id="tokenAge"
                type="number"
                value={config.minTokenAgeMinutes || 15}
                onChange={(e) => setConfig({ ...config, minTokenAgeMinutes: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="devWallet">Max Dev Wallet (%)</Label>
              <Input
                id="devWallet"
                type="number"
                value={config.maxDevWalletPercentage || 20}
                onChange={(e) => setConfig({ ...config, maxDevWalletPercentage: parseInt(e.target.value) })}
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              checked={config.trailingStopEnabled || true}
              onCheckedChange={(checked) => setConfig({ ...config, trailingStopEnabled: checked })}
            />
            <Label>Enable Trailing Stop-Loss</Label>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="trailingDistance">Trailing Stop Distance (%)</Label>
              <Input
                id="trailingDistance"
                type="number"
                value={config.trailingStopDistance || 15}
                onChange={(e) => setConfig({ ...config, trailingStopDistance: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="timeExit">Time-Based Exit (hours)</Label>
              <Input
                id="timeExit"
                type="number"
                value={config.timeBasedExitHours || 8}
                onChange={(e) => setConfig({ ...config, timeBasedExitHours: parseInt(e.target.value) })}
              />
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button onClick={updateConfig} disabled={loading}>
              {loading ? 'Updating...' : 'Update Configuration'}
            </Button>
            <Button variant="outline" onClick={testBuy} disabled={loading}>
              Test Buy
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Risk Warning */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="text-orange-800">Risk Warning</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-orange-700">
            Auto-trading involves significant risk. Only trade with funds you can afford to lose. 
            Memecoin markets are highly volatile and unpredictable. Always test your configuration 
            with small amounts first.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}