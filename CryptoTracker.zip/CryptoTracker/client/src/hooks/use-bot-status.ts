import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export function useBotStatus() {
  return useQuery({
    queryKey: ["/api/status"],
    queryFn: () => api.getStatus(),
    refetchInterval: 5000, // Refetch every 5 seconds for real-time updates
  });
}

export function useBotConfig() {
  return useQuery({
    queryKey: ["/api/config"],
    queryFn: () => api.getConfig(),
  });
}

export function useActivityLogs(limit = 50) {
  return useQuery({
    queryKey: ["/api/activity", limit],
    queryFn: () => api.getActivity(limit),
    refetchInterval: 10000, // Refetch every 10 seconds
  });
}

export function useBotStats() {
  return useQuery({
    queryKey: ["/api/stats"],
    queryFn: () => api.getStats(),
    refetchInterval: 30000, // Refetch every 30 seconds
  });
}
