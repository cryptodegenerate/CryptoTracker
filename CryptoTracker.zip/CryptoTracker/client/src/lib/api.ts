import { apiRequest } from "./queryClient";

export interface BotConfiguration {
  telegramToken: string;
  channelId: string;
  monitoringInterval: number;
  maxTokens: number;
  isActive: boolean;
}

export interface BotStatus {
  isMonitoring: boolean;
  isTelegramConnected: boolean;
  isConfigured: boolean;
  lastCheckTime: string;
  isActive: boolean;
}

export interface ActivityLog {
  id: number;
  type: string;
  message: string;
  status: string;
  details?: string;
  timestamp: string;
}

export interface BotStats {
  totalPosts: number;
  todayPosts: number;
  weekPosts: number;
  successRate: string;
  avgResponseTime: string;
  uptime: string;
}

export interface LeaderboardEntry {
  id: number;
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  initialPrice: string;
  currentPrice: string;
  priceChange24h: string;
  priceChangePercent: string;
  marketCap: string;
  volume24h: string;
  liquidityUsd: string;
  holders: number;
  performance1h: string;
  performance24h: string;
  performance7d: string;
  performanceScore: number;
  rank: number;
  tier: "bronze" | "silver" | "gold" | "diamond" | "legendary";
  streak: number;
  badges: string;
  discoveryPoints: number;
  riskCategory: "low" | "medium" | "high";
  safetyScore: number;
  communityScore: number;
  tradingActivity: "low" | "medium" | "high" | "extreme";
  volatilityIndex: string;
  momentumScore: number;
  qualityRating: "A+" | "A" | "B" | "C" | "D" | "F";
  trendDirection: "bullish" | "bearish" | "neutral";
  socialSentiment: "positive" | "negative" | "neutral";
  whaleActivity: boolean;
  devActivity: boolean;
  firstSeenAt: string;
  lastUpdated: string;
}

export interface UserScore {
  id: number;
  userId: string;
  username?: string;
  totalPoints: number;
  level: number;
  streak: number;
  badges: string;
  tokensDiscovered: number;
  successfulPicks: number;
  accuracyRate: string;
  bestPerformance: string;
  rank: number;
  tier: "bronze" | "silver" | "gold" | "diamond" | "legendary";
  achievements: string;
  joinedAt: string;
  lastActive: string;
}

export interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  category: "discovery" | "performance" | "streak" | "social" | "trading" | "community";
  requirement: string;
  points: number;
  rarity: "common" | "rare" | "epic" | "legendary";
  isActive: boolean;
  createdAt: string;
}

export const api = {
  // Configuration
  async getConfig(): Promise<BotConfiguration> {
    const response = await fetch("/api/config");
    if (!response.ok) throw new Error("Failed to fetch configuration");
    return response.json();
  },

  async saveConfig(config: Partial<BotConfiguration>): Promise<void> {
    await apiRequest("POST", "/api/config", config);
  },

  async testConnection(telegramToken: string, channelId: string): Promise<void> {
    await apiRequest("POST", "/api/test-connection", { telegramToken, channelId });
  },

  // Bot Control
  async startBot(): Promise<void> {
    await apiRequest("POST", "/api/start-bot");
  },

  async stopBot(): Promise<void> {
    await apiRequest("POST", "/api/stop-bot");
  },

  async getStatus(): Promise<BotStatus> {
    const response = await fetch("/api/status");
    if (!response.ok) throw new Error("Failed to fetch status");
    return response.json();
  },

  // Messaging
  async sendMessage(message: string): Promise<void> {
    await apiRequest("POST", "/api/send-message", { message });
  },

  async checkTokens(): Promise<void> {
    await apiRequest("POST", "/api/check-tokens");
  },

  // Activity & Stats
  async getActivity(limit = 50): Promise<ActivityLog[]> {
    const response = await fetch(`/api/activity?limit=${limit}`);
    if (!response.ok) throw new Error("Failed to fetch activity");
    return response.json();
  },

  async clearActivity(): Promise<void> {
    await apiRequest("DELETE", "/api/activity");
  },

  async getStats(): Promise<BotStats> {
    const response = await fetch("/api/stats");
    if (!response.ok) throw new Error("Failed to fetch stats");
    return response.json();
  },

  // Leaderboard
  async getLeaderboard(limit = 50, sortBy = "performanceScore"): Promise<LeaderboardEntry[]> {
    const response = await fetch(`/api/leaderboard?limit=${limit}&sortBy=${sortBy}`);
    if (!response.ok) throw new Error("Failed to fetch leaderboard");
    return response.json();
  },

  async getTopPerformers(timeframe = "24h", limit = 10): Promise<LeaderboardEntry[]> {
    const response = await fetch(`/api/leaderboard/top-performers?timeframe=${timeframe}&limit=${limit}`);
    if (!response.ok) throw new Error("Failed to fetch top performers");
    return response.json();
  },

  async getLeaderboardEntry(tokenAddress: string): Promise<LeaderboardEntry> {
    const response = await fetch(`/api/leaderboard/${tokenAddress}`);
    if (!response.ok) throw new Error("Failed to fetch leaderboard entry");
    return response.json();
  },

  // User Scores
  async getUserLeaderboard(limit = 50): Promise<UserScore[]> {
    const response = await fetch(`/api/users/leaderboard?limit=${limit}`);
    if (!response.ok) throw new Error("Failed to fetch user leaderboard");
    return response.json();
  },

  async getUserScore(userId: string): Promise<UserScore> {
    const response = await fetch(`/api/users/${userId}/score`);
    if (!response.ok) throw new Error("Failed to fetch user score");
    return response.json();
  },

  async updateUserPoints(userId: string, points: number): Promise<void> {
    await apiRequest("POST", `/api/users/${userId}/points`, { points });
  },

  // Achievements
  async getAchievements(): Promise<Achievement[]> {
    const response = await fetch("/api/achievements");
    if (!response.ok) throw new Error("Failed to fetch achievements");
    return response.json();
  },

  async getUserAchievements(userId: string): Promise<Achievement[]> {
    const response = await fetch(`/api/users/${userId}/achievements`);
    if (!response.ok) throw new Error("Failed to fetch user achievements");
    return response.json();
  },

  async unlockAchievement(userId: string, achievementId: number): Promise<void> {
    await apiRequest("POST", `/api/users/${userId}/achievements/${achievementId}`);
  },
};
