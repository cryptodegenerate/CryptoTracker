import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useBotConfig } from "@/hooks/use-bot-status";
import { Settings, TestTube, Save, Send, Eye, EyeOff, Search } from "lucide-react";

export function ConfigurationPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: config, isLoading } = useBotConfig();
  
  const [formData, setFormData] = useState({
    telegramToken: "",
    channelId: "",
    monitoringInterval: 5,
    maxTokens: 10,
  });
  
  const [manualMessage, setManualMessage] = useState("");
  const [showToken, setShowToken] = useState(false);

  // Update form data when config is loaded
  useState(() => {
    if (config) {
      setFormData({
        telegramToken: config.telegramToken === "" ? "" : "********",
        channelId: config.channelId,
        monitoringInterval: config.monitoringInterval,
        maxTokens: config.maxTokens,
      });
    }
  });

  const saveConfigMutation = useMutation({
    mutationFn: (data: any) => api.saveConfig(data),
    onSuccess: () => {
      toast({
        title: "Configuration saved",
        description: "Bot configuration has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/config"] });
      queryClient.invalidateQueries({ queryKey: ["/api/status"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save configuration",
        variant: "destructive",
      });
    },
  });

  const testConnectionMutation = useMutation({
    mutationFn: () => api.testConnection(formData.telegramToken, formData.channelId),
    onSuccess: () => {
      toast({
        title: "Connection successful",
        description: "Telegram bot connection test passed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Connection failed",
        description: error.message || "Failed to connect to Telegram",
        variant: "destructive",
      });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: (message: string) => api.sendMessage(message),
    onSuccess: () => {
      toast({
        title: "Message sent",
        description: "Manual message has been sent successfully.",
      });
      setManualMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const manualSearchMutation = useMutation({
    mutationFn: () => fetch('/api/manual-search', { method: 'POST' }).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Search initiated",
        description: "Manual token search has been started.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to start manual search",
        variant: "destructive",
      });
    },
  });

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Only include token if it's been changed (not masked)
    const configToSave: any = {
      channelId: formData.channelId,
      monitoringInterval: formData.monitoringInterval,
      maxTokens: formData.maxTokens,
    };
    
    if (formData.telegramToken && !formData.telegramToken.includes("*")) {
      configToSave.telegramToken = formData.telegramToken;
    }
    
    saveConfigMutation.mutate(configToSave);
  };

  const handleTestConnection = () => {
    if (!formData.telegramToken || !formData.channelId) {
      toast({
        title: "Missing information",
        description: "Please enter both bot token and channel ID",
        variant: "destructive",
      });
      return;
    }
    
    testConnectionMutation.mutate();
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualMessage.trim()) {
      toast({
        title: "Empty message",
        description: "Please enter a message to send",
        variant: "destructive",
      });
      return;
    }
    
    sendMessageMutation.mutate(manualMessage);
  };

  if (isLoading) {
    return <div>Loading configuration...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Bot Configuration Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <Settings className="h-4 w-4 text-blue-600" />
            </div>
            <h2 className="text-lg font-semibold text-slate-800">Bot Configuration</h2>
          </div>
          
          <form onSubmit={handleSaveConfig} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telegramToken">Telegram Bot Token</Label>
                <div className="relative">
                  <Input
                    id="telegramToken"
                    type={showToken ? "text" : "password"}
                    placeholder="Enter your bot token"
                    value={formData.telegramToken}
                    onChange={(e) => setFormData({ ...formData, telegramToken: e.target.value })}
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1 h-8 w-8 p-0"
                    onClick={() => setShowToken(!showToken)}
                  >
                    {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="channelId">Channel/Group ID</Label>
                <Input
                  id="channelId"
                  placeholder="@yourchannelname"
                  value={formData.channelId}
                  onChange={(e) => setFormData({ ...formData, channelId: e.target.value })}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="monitoringInterval">Monitoring Interval (minutes)</Label>
                <Select value={formData.monitoringInterval.toString()} onValueChange={(value) => setFormData({ ...formData, monitoringInterval: parseInt(value) })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 minute</SelectItem>
                    <SelectItem value="5">5 minutes</SelectItem>
                    <SelectItem value="10">10 minutes</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="maxTokens">Max Tokens per Check</Label>
                <Input
                  id="maxTokens"
                  type="number"
                  min="1"
                  max="50"
                  value={formData.maxTokens}
                  onChange={(e) => setFormData({ ...formData, maxTokens: parseInt(e.target.value) || 10 })}
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-3 pt-2">
              <Button type="submit" disabled={saveConfigMutation.isPending}>
                <Save className="h-4 w-4 mr-2" />
                {saveConfigMutation.isPending ? "Saving..." : "Save Configuration"}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleTestConnection}
                disabled={testConnectionMutation.isPending}
              >
                <TestTube className="h-4 w-4 mr-2" />
                {testConnectionMutation.isPending ? "Testing..." : "Test Connection"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Manual Controls Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
              <Search className="h-4 w-4 text-purple-600" />
            </div>
            <h2 className="text-lg font-semibold text-slate-800">Manual Controls</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <div>
                <h3 className="font-medium text-slate-800">Search for Tokens</h3>
                <p className="text-sm text-slate-600">Instantly scan pump.fun and DexScreener for new discoveries</p>
              </div>
              <Button 
                onClick={() => manualSearchMutation.mutate()}
                disabled={manualSearchMutation.isPending}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Search className="h-4 w-4 mr-2" />
                {manualSearchMutation.isPending ? "Searching..." : "Search Now"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Manual Posting Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
              <Send className="h-4 w-4 text-green-600" />
            </div>
            <h2 className="text-lg font-semibold text-slate-800">Manual Post</h2>
          </div>
          
          <form onSubmit={handleSendMessage} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="manualMessage">Message</Label>
              <Textarea
                id="manualMessage"
                rows={4}
                placeholder="Enter your message here..."
                value={manualMessage}
                onChange={(e) => setManualMessage(e.target.value)}
                className="resize-none"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-slate-500">
                <span>Message will be sent to configured channel</span>
              </div>
              <Button type="submit" disabled={sendMessageMutation.isPending}>
                <Send className="h-4 w-4 mr-2" />
                {sendMessageMutation.isPending ? "Sending..." : "Send Message"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
