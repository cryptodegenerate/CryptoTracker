import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api, type LeaderboardEntry } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, TrendingDown, Crown, Trophy, Medal, Award, Flame, Shield, Activity, Users } from "lucide-react";

const tierColors = {
  bronze: "bg-orange-100 text-orange-800 border-orange-200",
  silver: "bg-gray-100 text-gray-800 border-gray-200",
  gold: "bg-yellow-100 text-yellow-800 border-yellow-200",
  diamond: "bg-blue-100 text-blue-800 border-blue-200",
  legendary: "bg-purple-100 text-purple-800 border-purple-200"
};

const rankIcons = {
  1: Crown,
  2: Trophy,
  3: Medal
};

const getRiskColor = (category: string) => {
  switch (category) {
    case "low": return "text-green-600 bg-green-50";
    case "medium": return "text-yellow-600 bg-yellow-50";
    case "high": return "text-red-600 bg-red-50";
    default: return "text-gray-600 bg-gray-50";
  }
};

const getGradeColor = (grade: string) => {
  switch (grade) {
    case "A+": case "A": return "text-green-600 bg-green-50";
    case "B": return "text-blue-600 bg-blue-50";
    case "C": return "text-yellow-600 bg-yellow-50";
    case "D": case "F": return "text-red-600 bg-red-50";
    default: return "text-gray-600 bg-gray-50";
  }
};

const formatNumber = (num: string | number) => {
  const value = typeof num === 'string' ? parseFloat(num) : num;
  if (isNaN(value)) return "0";
  
  if (value >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
  return value.toFixed(2);
};

const formatPercent = (value: string) => {
  const num = parseFloat(value);
  if (isNaN(num)) return "0%";
  const sign = num >= 0 ? "+" : "";
  return `${sign}${num.toFixed(2)}%`;
};

interface TokenRowProps {
  token: LeaderboardEntry;
  showDetailed?: boolean;
}

function TokenRow({ token, showDetailed = false }: TokenRowProps) {
  const RankIcon = rankIcons[token.rank as keyof typeof rankIcons];
  const performance24h = parseFloat(token.performance24h) || 0;
  const isPositive = performance24h >= 0;

  return (
    <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            {RankIcon && <RankIcon className="h-5 w-5 text-yellow-500" />}
            <span className="text-lg font-bold text-gray-700">#{token.rank}</span>
          </div>
          
          <div>
            <div className="font-semibold text-lg">{token.tokenSymbol}</div>
            <div className="text-sm text-gray-600">{token.tokenName}</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Badge className={tierColors[token.tier]}>
            {token.tier.toUpperCase()}
          </Badge>
          
          <Badge className={getRiskColor(token.riskCategory)}>
            <Shield className="h-3 w-3 mr-1" />
            {token.riskCategory.toUpperCase()}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-3">
        <div className="text-center">
          <div className="text-xs text-gray-500">24h Performance</div>
          <div className={`font-bold ${isPositive ? 'text-green-600' : 'text-red-600'} flex items-center justify-center gap-1`}>
            {isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
            {formatPercent(token.performance24h)}
          </div>
        </div>

        <div className="text-center">
          <div className="text-xs text-gray-500">Score</div>
          <div className="font-bold text-blue-600">{token.performanceScore}</div>
        </div>

        <div className="text-center">
          <div className="text-xs text-gray-500">Safety</div>
          <div className="font-bold">{token.safetyScore}/100</div>
        </div>

        <div className="text-center">
          <div className="text-xs text-gray-500">Grade</div>
          <Badge className={getGradeColor(token.qualityRating)}>
            {token.qualityRating}
          </Badge>
        </div>

        <div className="text-center">
          <div className="text-xs text-gray-500">Volume 24h</div>
          <div className="font-semibold">${formatNumber(token.volume24h)}</div>
        </div>

        <div className="text-center">
          <div className="text-xs text-gray-500">Market Cap</div>
          <div className="font-semibold">${formatNumber(token.marketCap)}</div>
        </div>
      </div>

      {showDetailed && (
        <div className="border-t pt-3 mt-3">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-500">Liquidity:</span>
              <span className="ml-2 font-medium">${formatNumber(token.liquidityUsd)}</span>
            </div>
            <div>
              <span className="text-gray-500">Holders:</span>
              <span className="ml-2 font-medium flex items-center gap-1">
                <Users className="h-3 w-3" />
                {formatNumber(token.holders)}
              </span>
            </div>
            <div>
              <span className="text-gray-500">Streak:</span>
              <span className="ml-2 font-medium flex items-center gap-1">
                <Flame className="h-3 w-3" />
                {token.streak} days
              </span>
            </div>
            <div>
              <span className="text-gray-500">Activity:</span>
              <Badge variant="outline" className="ml-2">
                <Activity className="h-3 w-3 mr-1" />
                {token.tradingActivity}
              </Badge>
            </div>
          </div>
          
          <div className="mt-2 text-xs text-gray-500">
            Address: {token.tokenAddress}
          </div>
        </div>
      )}
    </div>
  );
}

export function TokenLeaderboard() {
  const [sortBy, setSortBy] = useState("performanceScore");
  const [timeframe, setTimeframe] = useState("24h");
  const [showDetailed, setShowDetailed] = useState(false);

  const { data: leaderboard, isLoading: leaderboardLoading } = useQuery({
    queryKey: ["/api/leaderboard", sortBy],
    queryFn: () => api.getLeaderboard(50, sortBy),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: topPerformers, isLoading: performersLoading } = useQuery({
    queryKey: ["/api/leaderboard/top-performers", timeframe],
    queryFn: () => api.getTopPerformers(timeframe, 10),
    refetchInterval: 30000,
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Token Discovery Leaderboard
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Live performance tracking with gamification rewards
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant={showDetailed ? "default" : "outline"}
                size="sm"
                onClick={() => setShowDetailed(!showDetailed)}
              >
                {showDetailed ? "Simple View" : "Detailed View"}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="leaderboard" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="leaderboard">Full Leaderboard</TabsTrigger>
          <TabsTrigger value="performers">Top Performers</TabsTrigger>
        </TabsList>

        <TabsContent value="leaderboard" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="performanceScore">Performance Score</SelectItem>
                  <SelectItem value="performance24h">24h Performance</SelectItem>
                  <SelectItem value="performance7d">7d Performance</SelectItem>
                  <SelectItem value="marketCap">Market Cap</SelectItem>
                  <SelectItem value="volume24h">Volume 24h</SelectItem>
                  <SelectItem value="safetyScore">Safety Score</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Card>
            <CardContent className="p-6">
              {leaderboardLoading ? (
                <div className="space-y-4">
                  {[...Array(10)].map((_, i) => (
                    <div key={i} className="h-24 bg-gray-100 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {leaderboard?.map((token) => (
                    <TokenRow 
                      key={token.tokenAddress} 
                      token={token} 
                      showDetailed={showDetailed}
                    />
                  ))}
                  {!leaderboard?.length && (
                    <div className="text-center py-8 text-gray-500">
                      No tokens in leaderboard yet. Start discovering tokens to see them here!
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performers" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Timeframe:</span>
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">1 Hour</SelectItem>
                  <SelectItem value="24h">24 Hours</SelectItem>
                  <SelectItem value="7d">7 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Card>
            <CardContent className="p-6">
              {performersLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-24 bg-gray-100 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {topPerformers?.map((token) => (
                    <TokenRow 
                      key={token.tokenAddress} 
                      token={token} 
                      showDetailed={showDetailed}
                    />
                  ))}
                  {!topPerformers?.length && (
                    <div className="text-center py-8 text-gray-500">
                      No top performers found for the selected timeframe.
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}