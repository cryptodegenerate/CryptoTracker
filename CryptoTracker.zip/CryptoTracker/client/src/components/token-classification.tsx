import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, AlertTriangle, XCircle } from "lucide-react";

interface TokenClassificationProps {
  classification: "green" | "yellow" | "red";
  riskScore: number;
  qualityMetrics?: string;
}

export function TokenClassification({ classification, riskScore, qualityMetrics }: TokenClassificationProps) {
  const getClassificationConfig = (classification: string) => {
    switch (classification) {
      case 'green':
        return {
          icon: Shield,
          label: 'LOW RISK',
          color: 'bg-green-500',
          badgeVariant: 'default' as const,
          description: 'High quality token with strong fundamentals'
        };
      case 'yellow':
        return {
          icon: AlertTriangle,
          label: 'MODERATE RISK',
          color: 'bg-yellow-500',
          badgeVariant: 'secondary' as const,
          description: 'Moderate risk token requiring careful evaluation'
        };
      case 'red':
        return {
          icon: XCircle,
          label: 'HIGH RISK',
          color: 'bg-red-500',
          badgeVariant: 'destructive' as const,
          description: 'High risk token with concerning metrics'
        };
      default:
        return {
          icon: Shield,
          label: 'UNCLASSIFIED',
          color: 'bg-gray-500',
          badgeVariant: 'outline' as const,
          description: 'Classification pending'
        };
    }
  };

  const config = getClassificationConfig(classification);
  const Icon = config.icon;

  let metrics;
  try {
    metrics = qualityMetrics ? JSON.parse(qualityMetrics) : null;
  } catch (e) {
    metrics = null;
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <div className={`w-3 h-3 rounded-full ${config.color}`}></div>
          Token Risk Assessment
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Icon className="w-4 h-4" />
            <span className="font-medium">{config.label}</span>
          </div>
          <Badge variant={config.badgeVariant}>
            Risk Score: {riskScore}/100
          </Badge>
        </div>
        
        <p className="text-sm text-muted-foreground">{config.description}</p>
        
        {metrics && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Quality Metrics</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex justify-between">
                <span>Liquidity:</span>
                <span>{metrics.liquidityScore}/100</span>
              </div>
              <div className="flex justify-between">
                <span>Market Cap:</span>
                <span>{metrics.marketCapScore}/100</span>
              </div>
              <div className="flex justify-between">
                <span>Volume:</span>
                <span>{metrics.volumeScore}/100</span>
              </div>
              <div className="flex justify-between">
                <span>Name Quality:</span>
                <span>{metrics.nameQualityScore}/100</span>
              </div>
            </div>
            <div className="pt-2 border-t">
              <div className="flex justify-between text-sm font-medium">
                <span>Overall Score:</span>
                <span>{metrics.overallScore}/100</span>
              </div>
            </div>
            {metrics.reasons && metrics.reasons.length > 0 && (
              <div className="space-y-1">
                <h5 className="text-xs font-medium">Risk Factors:</h5>
                <ul className="text-xs text-muted-foreground space-y-1">
                  {metrics.reasons.map((reason: string, index: number) => (
                    <li key={index} className="flex items-start gap-1">
                      <span className="text-xs">•</span>
                      <span>{reason}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface TokenListItemProps {
  token: {
    id: number;
    tokenAddress: string;
    tokenName: string;
    tokenSymbol: string;
    liquidity: string;
    price: string;
    classification: "green" | "yellow" | "red";
    riskScore: number;
    qualityMetrics?: string;
    posted: boolean;
    createdAt: string;
  };
}

export function TokenListItem({ token }: TokenListItemProps) {
  const getClassificationColor = (classification: string) => {
    switch (classification) {
      case 'green': return 'text-green-600';
      case 'yellow': return 'text-yellow-600';
      case 'red': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getClassificationEmoji = (classification: string) => {
    switch (classification) {
      case 'green': return '🟢';
      case 'yellow': return '🟡';
      case 'red': return '🔴';
      default: return '⚪';
    }
  };

  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-lg">{getClassificationEmoji(token.classification)}</span>
          <h3 className="font-medium">{token.tokenName}</h3>
          <Badge variant="outline">{token.tokenSymbol}</Badge>
        </div>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span>Liquidity: {token.liquidity} SOL</span>
          <span>Price: {token.price} SOL</span>
          <span className={getClassificationColor(token.classification)}>
            Risk: {token.riskScore}/100
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {token.posted && <Badge variant="secondary">Posted</Badge>}
        <Badge variant="outline" className="text-xs">
          {new Date(token.createdAt).toLocaleTimeString()}
        </Badge>
      </div>
    </div>
  );
}