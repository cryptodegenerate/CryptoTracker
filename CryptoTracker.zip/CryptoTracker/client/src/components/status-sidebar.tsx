import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useBotStatus, useBotStats } from "@/hooks/use-bot-status";
import { 
  Activity, 
  BarChart3, 
  Zap, 
  Play, 
  Square, 
  RefreshCw, 
  Trash2, 
  Download, 
  RotateCcw 
} from "lucide-react";

export function StatusSidebar() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: status, isLoading: statusLoading } = useBotStatus();
  const { data: stats, isLoading: statsLoading } = useBotStats();

  const startBotMutation = useMutation({
    mutationFn: () => api.startBot(),
    onSuccess: () => {
      toast({
        title: "Bot started",
        description: "Monitoring service has been started successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to start bot",
        variant: "destructive",
      });
    },
  });

  const stopBotMutation = useMutation({
    mutationFn: () => api.stopBot(),
    onSuccess: () => {
      toast({
        title: "Bot stopped",
        description: "Monitoring service has been stopped.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to stop bot",
        variant: "destructive",
      });
    },
  });

  const checkTokensMutation = useMutation({
    mutationFn: () => api.checkTokens(),
    onSuccess: () => {
      toast({
        title: "Token check completed",
        description: "Manual token check has been completed.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to check tokens",
        variant: "destructive",
      });
    },
  });

  const clearActivityMutation = useMutation({
    mutationFn: () => api.clearActivity(),
    onSuccess: () => {
      toast({
        title: "Activity cleared",
        description: "Activity log has been cleared.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to clear activity",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (isActive: boolean) => {
    return isActive ? "bg-green-500" : "bg-red-500";
  };

  const getStatusText = (isActive: boolean) => {
    return isActive ? "Active" : "Inactive";
  };

  const formatLastCheck = (lastCheckTime: string) => {
    if (!lastCheckTime) return "Never";
    
    const now = new Date();
    const lastCheck = new Date(lastCheckTime);
    const diffMs = now.getTime() - lastCheck.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "Just now";
    if (diffMins === 1) return "1 min ago";
    return `${diffMins} min ago`;
  };

  return (
    <div className="space-y-6">
      {/* Bot Status Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <Activity className="h-4 w-4 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800">Bot Status</h3>
          </div>
          
          {statusLoading ? (
            <div className="space-y-4">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Monitoring</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${status?.isMonitoring ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                  <Badge variant={status?.isMonitoring ? "default" : "secondary"}>
                    {getStatusText(status?.isMonitoring || false)}
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Telegram Connection</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(status?.isTelegramConnected || false)}`}></div>
                  <Badge variant={status?.isTelegramConnected ? "default" : "secondary"}>
                    {getStatusText(status?.isTelegramConnected || false)}
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Configuration</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(status?.isConfigured || false)}`}></div>
                  <Badge variant={status?.isConfigured ? "default" : "secondary"}>
                    {status?.isConfigured ? "Ready" : "Incomplete"}
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Last Check</span>
                <span className="text-sm font-medium text-slate-800">
                  {formatLastCheck(status?.lastCheckTime || "")}
                </span>
              </div>
            </div>
          )}
          
          <div className="mt-6 pt-4 border-t border-slate-200">
            <div className="flex space-x-2">
              <Button 
                className="flex-1" 
                onClick={() => startBotMutation.mutate()}
                disabled={startBotMutation.isPending || status?.isMonitoring}
              >
                <Play className="h-4 w-4 mr-1" />
                Start
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => stopBotMutation.mutate()}
                disabled={stopBotMutation.isPending || !status?.isMonitoring}
              >
                <Square className="h-4 w-4 mr-1" />
                Stop
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
              <BarChart3 className="h-4 w-4 text-yellow-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800">Statistics</h3>
          </div>
          
          {statsLoading ? (
            <div className="space-y-4">
              <div className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded-lg mb-3"></div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="h-12 bg-gray-200 rounded-lg"></div>
                  <div className="h-12 bg-gray-200 rounded-lg"></div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <div className="text-2xl font-bold text-slate-800">{stats?.totalPosts || 0}</div>
                <div className="text-sm text-slate-600">Total Posts</div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-lg font-bold text-green-600">{stats?.todayPosts || 0}</div>
                  <div className="text-xs text-slate-600">Today</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-lg font-bold text-blue-600">{stats?.weekPosts || 0}</div>
                  <div className="text-xs text-slate-600">This Week</div>
                </div>
              </div>
              
              <div className="space-y-2 pt-2 border-t border-slate-200">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Success Rate</span>
                  <span className="font-medium text-green-600">{stats?.successRate || "0"}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Avg Response Time</span>
                  <span className="font-medium text-slate-800">{stats?.avgResponseTime || "0s"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Uptime</span>
                  <span className="font-medium text-green-600">{stats?.uptime || "0"}%</span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
              <Zap className="h-4 w-4 text-indigo-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800">Quick Actions</h3>
          </div>
          
          <div className="space-y-3">
            <Button 
              variant="ghost" 
              className="w-full justify-start"
              onClick={() => checkTokensMutation.mutate()}
              disabled={checkTokensMutation.isPending}
            >
              <RefreshCw className="h-4 w-4 mr-3" />
              {checkTokensMutation.isPending ? "Checking..." : "Check for New Tokens"}
            </Button>
            
            <Button 
              variant="ghost" 
              className="w-full justify-start"
              onClick={() => clearActivityMutation.mutate()}
              disabled={clearActivityMutation.isPending}
            >
              <Trash2 className="h-4 w-4 mr-3" />
              {clearActivityMutation.isPending ? "Clearing..." : "Clear Activity Log"}
            </Button>
            
            <Button variant="ghost" className="w-full justify-start">
              <Download className="h-4 w-4 mr-3" />
              Export Logs
            </Button>
            
            <Button 
              variant="ghost" 
              className="w-full justify-start"
              onClick={() => {
                stopBotMutation.mutate();
                setTimeout(() => startBotMutation.mutate(), 1000);
              }}
              disabled={startBotMutation.isPending || stopBotMutation.isPending}
            >
              <RotateCcw className="h-4 w-4 mr-3" />
              Restart Bot
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
