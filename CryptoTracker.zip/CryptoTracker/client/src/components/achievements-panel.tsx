import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api, type Achievement, type UserScore } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Crown, Medal, Star, Lock, CheckCircle, TrendingUp } from "lucide-react";

const rarityColors = {
  common: "bg-gray-100 text-gray-800 border-gray-200",
  rare: "bg-blue-100 text-blue-800 border-blue-200",
  epic: "bg-purple-100 text-purple-800 border-purple-200",
  legendary: "bg-yellow-100 text-yellow-800 border-yellow-200"
};

const categoryIcons = {
  discovery: Trophy,
  performance: TrendingUp,
  streak: Medal,
  social: Star,
  trading: Crown,
  community: CheckCircle
};

const tierColors = {
  bronze: "bg-orange-100 text-orange-800",
  silver: "bg-gray-100 text-gray-800",
  gold: "bg-yellow-100 text-yellow-800",
  diamond: "bg-blue-100 text-blue-800",
  legendary: "bg-purple-100 text-purple-800"
};

function UserScoreCard({ userScore }: { userScore: UserScore }) {
  const nextLevelPoints = userScore.level * 1000;
  const currentLevelPoints = (userScore.level - 1) * 1000;
  const progressPoints = userScore.totalPoints - currentLevelPoints;
  const levelProgress = (progressPoints / (nextLevelPoints - currentLevelPoints)) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-yellow-500" />
          Player Profile
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold">{userScore.username || `Player ${userScore.userId.slice(0, 8)}`}</div>
            <Badge className={tierColors[userScore.tier]}>
              {userScore.tier.toUpperCase()} TIER
            </Badge>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-600">Global Rank</div>
            <div className="text-2xl font-bold text-blue-600">#{userScore.rank}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{userScore.totalPoints.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Total Points</div>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{userScore.level}</div>
            <div className="text-sm text-gray-600">Level</div>
          </div>
        </div>

        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Level {userScore.level}</span>
            <span>Level {userScore.level + 1}</span>
          </div>
          <Progress value={levelProgress} className="h-2" />
          <div className="text-xs text-gray-600 mt-1">
            {progressPoints} / {nextLevelPoints - currentLevelPoints} points to next level
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 text-sm">
          <div className="text-center">
            <div className="font-semibold">{userScore.tokensDiscovered}</div>
            <div className="text-gray-600">Discovered</div>
          </div>
          <div className="text-center">
            <div className="font-semibold">{userScore.successfulPicks}</div>
            <div className="text-gray-600">Successful</div>
          </div>
          <div className="text-center">
            <div className="font-semibold">{userScore.accuracyRate}%</div>
            <div className="text-gray-600">Accuracy</div>
          </div>
        </div>

        {userScore.streak > 0 && (
          <div className="flex items-center justify-center gap-2 p-2 bg-orange-50 rounded-lg">
            <Medal className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-700">
              {userScore.streak} day streak!
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function AchievementCard({ achievement, isUnlocked }: { achievement: Achievement; isUnlocked: boolean }) {
  const CategoryIcon = categoryIcons[achievement.category as keyof typeof categoryIcons] || Trophy;

  return (
    <Card className={`relative ${isUnlocked ? 'border-green-200 bg-green-50' : 'opacity-60'}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${isUnlocked ? 'bg-green-100' : 'bg-gray-100'}`}>
              {isUnlocked ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <Lock className="h-5 w-5 text-gray-400" />
              )}
            </div>
            <div>
              <div className="font-semibold flex items-center gap-1">
                {achievement.icon} {achievement.name}
              </div>
              <div className="text-sm text-gray-600">{achievement.description}</div>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-1">
            <Badge className={rarityColors[achievement.rarity as keyof typeof rarityColors]}>
              {achievement.rarity.toUpperCase()}
            </Badge>
            <div className="text-sm font-medium text-blue-600">{achievement.points} pts</div>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <CategoryIcon className="h-3 w-3" />
            {achievement.category}
          </div>
          {isUnlocked && (
            <div className="text-green-600 font-medium">UNLOCKED</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function AchievementsPanel() {
  const [userId] = useState(() => 
    localStorage.getItem('userId') || 
    (() => {
      const id = 'user_' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('userId', id);
      return id;
    })()
  );

  const { data: userScore } = useQuery({
    queryKey: ["/api/users/score", userId],
    queryFn: () => api.getUserScore(userId),
    refetchInterval: 30000,
  });

  const { data: achievements } = useQuery({
    queryKey: ["/api/achievements"],
    queryFn: () => api.getAchievements(),
  });

  const { data: userAchievements } = useQuery({
    queryKey: ["/api/users/achievements", userId],
    queryFn: () => api.getUserAchievements(userId),
  });

  const { data: userLeaderboard } = useQuery({
    queryKey: ["/api/users/leaderboard"],
    queryFn: () => api.getUserLeaderboard(20),
    refetchInterval: 60000,
  });

  const unlockedAchievementIds = new Set(userAchievements?.map(a => a.id) || []);
  const achievementsByCategory = achievements?.reduce((acc, achievement) => {
    if (!acc[achievement.category]) acc[achievement.category] = [];
    acc[achievement.category].push(achievement);
    return acc;
  }, {} as Record<string, Achievement[]>) || {};

  return (
    <div className="space-y-6">
      {userScore && <UserScoreCard userScore={userScore} />}

      <Tabs defaultValue="achievements" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="leaderboard">Global Leaderboard</TabsTrigger>
        </TabsList>

        <TabsContent value="achievements" className="space-y-6">
          {Object.entries(achievementsByCategory).map(([category, categoryAchievements]) => {
            const CategoryIcon = categoryIcons[category as keyof typeof categoryIcons] || Trophy;
            const unlockedCount = categoryAchievements.filter(a => unlockedAchievementIds.has(a.id)).length;
            const progress = (unlockedCount / categoryAchievements.length) * 100;

            return (
              <Card key={category}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 capitalize">
                      <CategoryIcon className="h-5 w-5" />
                      {category} Achievements
                    </CardTitle>
                    <div className="text-sm text-gray-600">
                      {unlockedCount} / {categoryAchievements.length}
                    </div>
                  </div>
                  <Progress value={progress} className="h-2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4">
                    {categoryAchievements.map((achievement) => (
                      <AchievementCard
                        key={achievement.id}
                        achievement={achievement}
                        isUnlocked={unlockedAchievementIds.has(achievement.id)}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="leaderboard">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Global Player Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userLeaderboard?.map((player, index) => (
                  <div
                    key={player.userId}
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      player.userId === userId ? 'border-blue-200 bg-blue-50' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-lg font-bold text-gray-700">#{player.rank}</div>
                      <div>
                        <div className="font-semibold">
                          {player.username || `Player ${player.userId.slice(0, 8)}`}
                        </div>
                        <div className="text-sm text-gray-600">
                          Level {player.level} • {player.tokensDiscovered} tokens discovered
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <Badge className={tierColors[player.tier]}>
                        {player.tier.toUpperCase()}
                      </Badge>
                      <div className="text-right">
                        <div className="font-bold text-blue-600">
                          {player.totalPoints.toLocaleString()} pts
                        </div>
                        <div className="text-sm text-gray-600">
                          {player.accuracyRate}% accuracy
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {!userLeaderboard?.length && (
                  <div className="text-center py-8 text-gray-500">
                    No players on the leaderboard yet. Be the first to start discovering tokens!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}