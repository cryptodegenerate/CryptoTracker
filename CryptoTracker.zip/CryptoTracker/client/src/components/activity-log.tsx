import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { useActivityLogs } from "@/hooks/use-bot-status";
import { History, RefreshCw, CheckCircle, XCircle, Settings, Send, Play, Square } from "lucide-react";

export function ActivityLog() {
  const queryClient = useQueryClient();
  const { data: logs, isLoading } = useActivityLogs();

  const refreshLogs = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
  };

  const getActivityIcon = (type: string, status: string) => {
    if (status === "error") {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
    
    switch (type) {
      case "token_post":
        return <Send className="h-4 w-4 text-green-500" />;
      case "manual_post":
        return <Send className="h-4 w-4 text-blue-500" />;
      case "config_update":
        return <Settings className="h-4 w-4 text-blue-500" />;
      case "bot_start":
        return <Play className="h-4 w-4 text-green-500" />;
      case "bot_stop":
        return <Square className="h-4 w-4 text-red-500" />;
      default:
        return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
  };

  const getActivityColor = (type: string, status: string) => {
    if (status === "error") return "bg-red-50";
    
    switch (type) {
      case "token_post":
      case "bot_start":
        return "bg-green-50";
      case "manual_post":
      case "config_update":
        return "bg-blue-50";
      case "bot_stop":
        return "bg-red-50";
      default:
        return "bg-slate-50";
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hours ago`;
    return `${diffDays} days ago`;
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
              <History className="h-4 w-4 text-purple-600" />
            </div>
            <h2 className="text-lg font-semibold text-slate-800">Recent Activity</h2>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={refreshLogs}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        <div className="space-y-3">
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
                    <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : logs && logs.length > 0 ? (
            logs.map((log) => (
              <div key={log.id} className={`flex items-center space-x-3 p-3 rounded-lg ${getActivityColor(log.type, log.status)}`}>
                <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                  {getActivityIcon(log.type, log.status)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">{log.message}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <p className="text-xs text-slate-500">{formatTimestamp(log.timestamp)}</p>
                    <Badge variant={log.status === "success" ? "default" : "destructive"} className="text-xs">
                      {log.status}
                    </Badge>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <History className="h-12 w-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500">No activity logged yet</p>
              <p className="text-sm text-slate-400">Bot activities will appear here when they occur</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
