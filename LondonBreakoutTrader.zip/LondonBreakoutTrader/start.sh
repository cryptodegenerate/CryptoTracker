#!/bin/bash

# London Breakout Trading Bot - VPS Startup Script
# Usage: ./start.sh [--test|--live]

set -e  # Exit on any error

echo "🚀 Starting London Breakout Trading Bot..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js 18+ first.${NC}"
    echo "Visit: https://nodejs.org or run: curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install -y nodejs"
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node --version | cut -d'.' -f1 | sed 's/v//')
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}❌ Node.js version 18+ required. Current version: $(node --version)${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Node.js $(node --version) detected${NC}"

# Create necessary directories
mkdir -p logs
mkdir -p data

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚠️  .env file not found. Creating from .env.example...${NC}"
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo -e "${YELLOW}📝 Please edit .env file with your API keys before continuing.${NC}"
        exit 1
    else
        echo -e "${RED}❌ No .env.example file found. Please create .env manually.${NC}"
        exit 1
    fi
fi

# Load environment variables
if [ -f ".env" ]; then
    echo -e "${GREEN}✅ Loading environment variables from .env${NC}"
    export $(cat .env | grep -v '^#' | xargs)
fi

# Validate required environment variables
REQUIRED_VARS=("TELEGRAM_BOT_TOKEN" "TELEGRAM_CHAT_ID")
MISSING_VARS=()

for var in "${REQUIRED_VARS[@]}"; do
    if [ -z "${!var}" ]; then
        MISSING_VARS+=("$var")
    fi
done

if [ ${#MISSING_VARS[@]} -gt 0 ]; then
    echo -e "${RED}❌ Missing required environment variables:${NC}"
    printf '   %s\n' "${MISSING_VARS[@]}"
    echo -e "${YELLOW}Please add them to your .env file${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Environment variables validated${NC}"

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}📦 Installing dependencies...${NC}"
    npm install
fi

# Check if package.json exists and has the right dependencies
if [ ! -f "package.json" ]; then
    echo -e "${YELLOW}📦 Creating minimal package.json...${NC}"
    cat > package.json << EOF
{
  "name": "london-breakout-trading-bot",
  "version": "1.0.0",
  "description": "Automated London session forex trading bot",
  "main": "main.js",
  "type": "module",
  "scripts": {
    "start": "node main.js",
    "test": "node main.js --test",
    "live": "node main.js --live"
  },
  "dependencies": {
    "express": "^4.18.2",
    "dotenv": "^16.3.1",
    "date-fns": "^2.30.0"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF
    npm install
fi

# Set up log rotation (optional)
if command -v logrotate &> /dev/null; then
    echo -e "${GREEN}✅ Setting up log rotation${NC}"
    cat > /tmp/trading-bot-logrotate << EOF
$(pwd)/bot.log {
    daily
    missingok
    rotate 7
    compress
    notifempty
    create 0644 $(whoami) $(whoami)
}
EOF
    sudo cp /tmp/trading-bot-logrotate /etc/logrotate.d/trading-bot 2>/dev/null || echo -e "${YELLOW}⚠️  Could not set up log rotation (no sudo access)${NC}"
fi

# Create systemd service file (optional)
if [ -w "/etc/systemd/system" ] 2>/dev/null; then
    echo -e "${GREEN}✅ Creating systemd service${NC}"
    sudo tee /etc/systemd/system/trading-bot.service > /dev/null << EOF
[Unit]
Description=London Breakout Trading Bot
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$(pwd)
Environment=NODE_ENV=production
ExecStart=/usr/bin/node main.js
Restart=always
RestartSec=5
StandardOutput=append:$(pwd)/bot.log
StandardError=append:$(pwd)/bot.log

[Install]
WantedBy=multi-user.target
EOF
    sudo systemctl daemon-reload
    echo -e "${GREEN}✅ Systemd service created. Use: sudo systemctl start trading-bot${NC}"
fi

# Determine run mode
MODE_FLAG=""
if [ "$1" = "--test" ]; then
    MODE_FLAG="--test"
    echo -e "${YELLOW}🧪 Starting in TEST mode${NC}"
elif [ "$1" = "--live" ]; then
    MODE_FLAG="--live"
    echo -e "${RED}🔴 Starting in LIVE mode${NC}"
else
    echo -e "${GREEN}🔄 Starting in SIMULATION mode${NC}"
fi

# Final checks
echo -e "${GREEN}✅ All checks passed. Starting trading bot...${NC}"
echo -e "${GREEN}✅ Logs will be written to: bot.log${NC}"
echo -e "${GREEN}✅ Trade data will be saved to: trades.csv${NC}"
echo -e "${GREEN}✅ Events will be logged to: events.json${NC}"
echo ""
echo -e "${YELLOW}💡 To stop the bot, press Ctrl+C${NC}"
echo -e "${YELLOW}💡 To run in background: nohup ./start.sh $MODE_FLAG > output.log 2>&1 &${NC}"
echo ""

# Start the bot
node main.js $MODE_FLAG