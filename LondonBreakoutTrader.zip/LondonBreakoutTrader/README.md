# London Breakout Trading Bot

A sophisticated forex trading bot specializing in London session breakout strategies with real-time Telegram alerts and comprehensive risk management.

## 🚀 Features

- **London Session Breakout Detection** - Monitors EUR/USD, GBP/USD, USD/JPY during 7-10 AM UTC
- **Real-time Telegram Alerts** - Instant breakout notifications with confidence scores
- **Smart Risk Management** - Configurable risk percentage, leverage, and daily trade limits
- **OANDA Integration** - Live market data and trading execution (optional)
- **Comprehensive Logging** - File-based logging with trade history and event tracking
- **VPS Optimized** - Designed for headless Linux server deployment
- **Auto-restart** - Built-in error handling and crash recovery

## 📋 Requirements

- **Node.js 18+** - Runtime environment
- **Linux VPS** - Ubuntu/Debian recommended (Hetzner, DigitalOcean, etc.)
- **Telegram Bot** - For receiving alerts
- **OANDA Account** - Optional, for live market data

## 🔧 Quick Setup

### 1. Clone and Setup
```bash
# Download the bot files to your VPS
# Upload main.js, start.sh, .env.example, package.json, README.md

# Make the startup script executable
chmod +x start.sh
```

### 2. Configure Environment
```bash
# Copy the example environment file
cp .env.example .env

# Edit with your credentials
nano .env
```

Required variables in `.env`:
```bash
TELEGRAM_BOT_TOKEN=your_bot_token_from_botfather
TELEGRAM_CHAT_ID=your_chat_id_or_channel_id
```

Optional variables:
```bash
OANDA_API_KEY=your_oanda_api_key
OANDA_ACCOUNT_ID=your_oanda_account_id
OANDA_ENVIRONMENT=demo
PORT=3000
RISK_PERCENTAGE=1.5
```

### 3. Start the Bot
```bash
# Test mode (safer for initial testing)
./start.sh --test

# Live mode (for real trading)
./start.sh --live

# Simulation mode (default - no real trades)
./start.sh
```

## 🔐 Getting Telegram Credentials

### 1. Create Telegram Bot
1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. Send `/newbot` and follow instructions
3. Save the bot token (format: `123456789:ABCdef...`)

### 2. Get Chat ID
**For personal messages:**
1. Message your bot with `/start`
2. Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
3. Find your `chat.id` in the response

**For channels:**
1. Add your bot to the channel as admin
2. Send a message in the channel
3. Visit the same URL above
4. Look for `chat.id` (will be negative for channels)

## 🏦 OANDA Setup (Optional)

### 1. Create OANDA Account
1. Sign up at [OANDA](https://www.oanda.com)
2. Create a demo or live account
3. Go to "Manage API Access"

### 2. Generate API Token
1. Click "Generate" for a new token
2. Save the token securely
3. Note your Account ID (format: `101-001-XXXXXXX-001`)

### 3. Configure Environment
```bash
OANDA_API_KEY=your_generated_token
OANDA_ACCOUNT_ID=your_account_id
OANDA_ENVIRONMENT=demo  # or 'live' for real trading
```

## 🖥️ VPS Deployment

### Method 1: Manual Start
```bash
# Foreground (see all logs)
./start.sh

# Background with logs
nohup ./start.sh > output.log 2>&1 &

# Check if running
ps aux | grep node
```

### Method 2: Systemd Service (Recommended)
```bash
# The start.sh script automatically creates a systemd service
sudo systemctl start trading-bot
sudo systemctl enable trading-bot  # Auto-start on boot
sudo systemctl status trading-bot  # Check status

# View logs
sudo journalctl -u trading-bot -f
```

### Method 3: PM2 Process Manager
```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start main.js --name "trading-bot"
pm2 startup  # Auto-start on boot
pm2 save     # Save current processes
```

## 📊 Monitoring & Logs

### Log Files
- `bot.log` - General application logs
- `trades.csv` - Trade history in CSV format
- `events.json` - Structured event data
- `output.log` - Startup script output

### Web Interface
Visit `http://your-vps-ip:3000` for:
- `/health` - Health check endpoint
- `/api/status` - Current bot status
- `/api/alerts` - Recent alerts
- `/api/trades` - Trade history

### Check Status
```bash
# View recent logs
tail -f bot.log

# Check trade history
head -20 trades.csv

# Monitor resource usage
htop
```

## ⚙️ Configuration

### Trading Parameters
Edit `.env` to customize:
```bash
RISK_PERCENTAGE=1.5        # Risk per trade (%)
LEVERAGE=5                 # Trading leverage
MAX_TRADES_PER_DAY=2      # Daily trade limit
SESSION_START_HOUR=7       # London session start (UTC)
SESSION_END_HOUR=10        # London session end (UTC)
```

### Server Settings
```bash
PORT=3000                  # Web interface port
LOG_LEVEL=info            # Logging verbosity
NODE_ENV=production       # Environment mode
```

## 🔄 Management Commands

### Start/Stop
```bash
# Start
./start.sh
sudo systemctl start trading-bot

# Stop
Ctrl+C  # If running in foreground
sudo systemctl stop trading-bot
pm2 stop trading-bot
```

### Restart
```bash
sudo systemctl restart trading-bot
pm2 restart trading-bot
```

### Update
```bash
# Stop the bot
sudo systemctl stop trading-bot

# Update files (main.js, etc.)
# Restart
sudo systemctl start trading-bot
```

## 🐛 Troubleshooting

### Common Issues

**Bot won't start:**
```bash
# Check Node.js version
node --version  # Should be 18+

# Check environment
cat .env

# Check logs
tail bot.log
```

**No Telegram alerts:**
```bash
# Test bot token
curl "https://api.telegram.org/bot<TOKEN>/getMe"

# Check chat ID format
# Personal: positive number
# Channel: negative number starting with -100
```

**OANDA connection fails:**
```bash
# Check credentials in .env
# Verify account ID format
# Ensure API token has correct permissions
```

### Log Analysis
```bash
# Search for errors
grep -i error bot.log

# View recent breakouts
grep -i breakout bot.log | tail -10

# Check trade activity
cat trades.csv | tail -20
```

## 🔒 Security Best Practices

1. **Environment Variables** - Never commit `.env` files
2. **API Keys** - Rotate keys regularly
3. **VPS Security** - Use SSH keys, disable password auth
4. **Firewall** - Only open necessary ports
5. **Updates** - Keep Node.js and packages updated

## 📈 Performance Tips

1. **VPS Specs** - Minimum 1GB RAM, 1 CPU core
2. **Network** - Stable internet connection crucial
3. **Monitoring** - Set up uptime monitoring
4. **Backups** - Regular backup of logs and configuration

## 🆘 Support

If you encounter issues:

1. Check the logs: `tail -f bot.log`
2. Verify configuration: `cat .env`
3. Test manually: `node main.js --test`
4. Review this README for setup steps

## 📄 License

MIT License - See LICENSE file for details.

---

**⚠️ Risk Warning**: Trading forex involves substantial risk. This bot is for educational purposes. Never risk more than you can afford to lose.