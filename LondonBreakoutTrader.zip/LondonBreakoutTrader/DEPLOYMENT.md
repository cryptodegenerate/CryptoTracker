# VPS Deployment Guide

Quick deployment guide for Linux VPS hosting (Hetzner, DigitalOcean, etc.)

## 📦 Files to Upload

Upload these files to your VPS:
- `main.js` - Main bot application
- `start.sh` - Startup script  
- `.env.example` - Environment template
- `package-vps.json` - Dependencies (rename to `package.json`)
- `README.md` - Full documentation

## 🚀 Quick Deploy

```bash
# 1. Upload files and connect to VPS
ssh root@your-vps-ip

# 2. Create bot directory
mkdir /opt/trading-bot
cd /opt/trading-bot

# 3. Upload files (use scp, rsync, or file manager)
# scp main.js start.sh .env.example package-vps.json README.md root@your-vps:/opt/trading-bot/

# 4. Rename package file
mv package-vps.json package.json

# 5. Setup environment
cp .env.example .env
nano .env  # Add your credentials

# 6. Make startup script executable
chmod +x start.sh

# 7. Start the bot
./start.sh --test
```

## ⚙️ Required .env Configuration

```bash
# Telegram (Required)
TELEGRAM_BOT_TOKEN=123456789:ABCdef_your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_or_channel_id

# OANDA (Optional - will use simulation if not provided)
OANDA_API_KEY=your_oanda_api_key
OANDA_ACCOUNT_ID=101-004-35721525-001
OANDA_ENVIRONMENT=demo

# Server Settings
PORT=3000
LOG_LEVEL=info
```

## 🔄 Running Options

```bash
# Test mode (recommended first)
./start.sh --test

# Simulation mode
./start.sh

# Live trading mode  
./start.sh --live

# Background mode
nohup ./start.sh > output.log 2>&1 &
```

## 📊 Monitor

- Health check: `http://your-vps-ip:3000/health`
- Logs: `tail -f bot.log`
- Trades: `cat trades.csv`
- Stop: `Ctrl+C` or `pkill -f main.js`

## 🔧 Systemd Service

```bash
# Create service file
sudo tee /etc/systemd/system/trading-bot.service > /dev/null << EOF
[Unit]
Description=London Breakout Trading Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/trading-bot
Environment=NODE_ENV=production
ExecStart=/usr/bin/node main.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable trading-bot
sudo systemctl start trading-bot
sudo systemctl status trading-bot
```

## 🛠️ Troubleshooting

**Bot won't start:**
```bash
node --version  # Check Node.js 18+
cat .env        # Verify credentials
./start.sh      # Check error messages
```

**No alerts:**
```bash
# Test Telegram bot
curl "https://api.telegram.org/bot<TOKEN>/getMe"
```

**Port issues:**
```bash
# Check if port 3000 is free
netstat -tlnp | grep 3000

# Use different port
echo "PORT=8080" >> .env
```

Ready to deploy! 🚀