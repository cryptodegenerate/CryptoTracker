import { useQuery } from "@tanstack/react-query";
import type { CurrencyPair, Trade, BotSettings, Alert } from "@shared/schema";

export function useTradingData() {
  const { data: currencyPairs, isLoading: currencyPairsLoading } = useQuery<CurrencyPair[]>({
    queryKey: ['/api/currency-pairs'],
    refetchInterval: 2000, // Refetch every 2 seconds for live prices
  });

  const { data: allTrades, isLoading: tradesLoading } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
  });

  const { data: activeTrades, isLoading: activeTradesLoading } = useQuery<Trade[]>({
    queryKey: ['/api/trades/active'],
    refetchInterval: 1000, // Frequent updates for active positions
  });

  const { data: botSettings, isLoading: settingsLoading } = useQuery<BotSettings>({
    queryKey: ['/api/bot-settings'],
  });

  const { data: alerts, isLoading: alertsLoading } = useQuery<Alert[]>({
    queryKey: ['/api/alerts'],
    refetchInterval: 5000, // Check for new alerts every 5 seconds
  });

  return {
    currencyPairs,
    allTrades,
    activeTrades,
    botSettings,
    alerts,
    isLoading: currencyPairsLoading || tradesLoading || activeTradesLoading || settingsLoading || alertsLoading,
  };
}
