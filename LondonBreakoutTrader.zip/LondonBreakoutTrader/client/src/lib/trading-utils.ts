import type { Trade } from "@shared/schema";

export function calculatePositionSize(
  accountBalance: number,
  riskPercent: number,
  entryPrice: number,
  stopLossPrice: number
): number {
  const riskAmount = accountBalance * (riskPercent / 100);
  const pipValue = Math.abs(entryPrice - stopLossPrice);
  const standardLotValue = 100000; // Standard forex lot
  
  // Calculate position size based on risk
  const positionSize = riskAmount / (pipValue * standardLotValue);
  return Math.min(positionSize, 0.1); // Cap at 0.1 lots for safety
}

export function calculateMarginRequired(
  price: number,
  positionSize: number,
  leverage: number
): number {
  const standardLotValue = 100000;
  const positionValue = price * positionSize * standardLotValue;
  return positionValue / leverage;
}

export function calculatePnL(
  entryPrice: number,
  currentPrice: number,
  positionSize: number,
  tradeType: string
): number {
  const standardLotValue = 100000;
  const priceDiff = tradeType === 'LONG' 
    ? currentPrice - entryPrice 
    : entryPrice - currentPrice;
    
  return priceDiff * positionSize * standardLotValue;
}

export function formatTime(dateInput: string | Date): string {
  const date = new Date(dateInput);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays > 0) return diffDays === 1 ? 'Yesterday' : `${diffDays} days ago`;
  if (diffHours > 0) return `${diffHours}h ago`;
  if (diffMins > 0) return `${diffMins}m ago`;
  return date.toLocaleTimeString('en-GB', { 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit' 
  });
}

export function calculatePerformanceMetrics(trades: Trade[]) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

  const closedTrades = trades.filter(trade => trade.status === 'CLOSED' && trade.pnl);
  
  // Today's metrics
  const todayTrades = closedTrades.filter(trade => 
    new Date(trade.closedAt || trade.openedAt) >= today
  );
  const todayPnL = todayTrades.reduce((sum, trade) => sum + parseFloat(trade.pnl || '0'), 0);
  const todayWins = todayTrades.filter(trade => parseFloat(trade.pnL || '0') > 0).length;
  const todayWinRate = todayTrades.length > 0 ? (todayWins / todayTrades.length) * 100 : 0;

  // Weekly metrics
  const weeklyTrades = closedTrades.filter(trade => 
    new Date(trade.closedAt || trade.openedAt) >= weekAgo
  );
  const weeklyPnL = weeklyTrades.reduce((sum, trade) => sum + parseFloat(trade.pnl || '0'), 0);
  const weeklyWins = weeklyTrades.filter(trade => parseFloat(trade.pnl || '0') > 0).length;
  const weeklyWinRate = weeklyTrades.length > 0 ? (weeklyWins / weeklyTrades.length) * 100 : 0;

  // Calculate max drawdown (simplified)
  let runningBalance = 25000; // Starting balance
  let peak = runningBalance;
  let maxDrawdown = 0;

  closedTrades.forEach(trade => {
    runningBalance += parseFloat(trade.pnl || '0');
    if (runningBalance > peak) {
      peak = runningBalance;
    }
    const drawdown = ((peak - runningBalance) / peak) * 100;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
  });

  // Simplified Sharpe ratio calculation
  const returns = closedTrades.map(trade => parseFloat(trade.pnl || '0'));
  const avgReturn = returns.length > 0 ? returns.reduce((a, b) => a + b, 0) / returns.length : 0;
  const variance = returns.length > 0 
    ? returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / returns.length 
    : 0;
  const stdDev = Math.sqrt(variance);
  const sharpeRatio = stdDev > 0 ? avgReturn / stdDev : 0;

  return {
    todayPnL,
    todayWinRate,
    todayTrades: todayTrades.length,
    weeklyPnL,
    weeklyWinRate,
    maxDrawdown,
    sharpeRatio,
    currentDrawdown: 0, // Simplified - would need more complex calculation
    accountUsage: 1.1, // Mock value - would calculate based on margin usage
  };
}

export function isLondonSession(): boolean {
  const now = new Date();
  const londonTime = new Date(now.toLocaleString("en-US", { timeZone: "Europe/London" }));
  const hour = londonTime.getHours();
  return hour >= 7 && hour < 10; // 7AM-10AM London time
}

export function getLondonTime(): string {
  const now = new Date();
  return now.toLocaleTimeString('en-GB', {
    timeZone: 'Europe/London',
    hour12: false
  });
}
