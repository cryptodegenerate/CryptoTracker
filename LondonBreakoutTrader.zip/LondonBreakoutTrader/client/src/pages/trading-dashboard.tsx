import { useEffect, useState } from "react";
import Header from "@/components/header";
import CurrencyPairCard from "@/components/currency-pair-card";
import AdvancedChart from "@/components/advanced-chart";
import RiskManagement from "@/components/risk-management";
import ActivePositions from "@/components/active-positions";
import TradeHistory from "@/components/trade-history";
import PerformancePanel from "@/components/performance-panel";
import BacktestingPanel from "@/components/backtesting-panel";
import TelegramControls from "@/components/telegram-controls";
import { useTradingData } from "@/hooks/use-trading-data";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function TradingDashboard() {
  const { currencyPairs, botSettings, isLoading } = useTradingData();
  const [selectedPair, setSelectedPair] = useState("EUR/USD");
  const [activeTab, setActiveTab] = useState("overview");

  // Simulate price updates every 2 seconds
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        await apiRequest("POST", "/api/simulate-prices");
      } catch (error) {
        console.error("Failed to simulate prices:", error);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[hsl(240,10%,3.9%)] flex items-center justify-center">
        <div className="text-white">Loading trading dashboard...</div>
      </div>
    );
  }

  const selectedPairData = currencyPairs?.find(p => p.symbol === selectedPair);

  return (
    <div className="min-h-screen bg-[hsl(240,10%,3.9%)] text-white font-inter">
      <Header />
      
      <div className="flex h-screen">
        <main className="flex-1 p-6 overflow-auto">
          {/* Session Status Banner */}
          <div className="bg-gradient-to-r from-[hsl(207,90%,54%)]/20 to-[hsl(142,71%,45%)]/20 border border-[hsl(207,90%,54%)]/30 rounded-xl p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-3 h-3 bg-[hsl(142,71%,45%)] rounded-full animate-pulse"></div>
                <div>
                  <h3 className="font-semibold text-white">London Session Active</h3>
                  <p className="text-sm text-[hsl(0,0%,88%)]">
                    Monitoring breakout opportunities • {botSettings ? 2 - (botSettings.tradesUsedToday || 0) : 2} trades remaining today
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-[hsl(0,0%,62%)]">Session Time Remaining</div>
                <div className="font-mono text-lg font-bold text-[hsl(33,95%,54%)]" id="session-timer">01:15:32</div>
              </div>
            </div>
          </div>

          {/* Main Trading Interface */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-[hsl(240,3.7%,15.9%)] border border-[hsl(240,3.7%,25.9%)]">
              <TabsTrigger value="overview" className="data-[state=active]:bg-[hsl(207,90%,54%)] data-[state=active]:text-white">
                <i className="fas fa-chart-line mr-2"></i>Overview
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:bg-[hsl(207,90%,54%)] data-[state=active]:text-white">
                <i className="fas fa-chart-area mr-2"></i>Analysis
              </TabsTrigger>
              <TabsTrigger value="backtest" className="data-[state=active]:bg-[hsl(207,90%,54%)] data-[state=active]:text-white">
                <i className="fas fa-history mr-2"></i>Backtest
              </TabsTrigger>
              <TabsTrigger value="automation" className="data-[state=active]:bg-[hsl(207,90%,54%)] data-[state=active]:text-white">
                <i className="fas fa-robot mr-2"></i>Automation
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              {/* Currency Pairs Grid */}
              <div className="grid grid-cols-3 gap-6 mb-8">
                {currencyPairs?.map((pair) => (
                  <div key={pair.symbol} onClick={() => setSelectedPair(pair.symbol)} className="cursor-pointer">
                    <CurrencyPairCard pair={pair} />
                  </div>
                ))}
              </div>

              {/* Chart and Risk Management Section */}
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="col-span-2">
                  {selectedPairData && (
                    <AdvancedChart
                      symbol={selectedPairData.symbol}
                      currentPrice={parseFloat(selectedPairData.currentPrice)}
                      upperBreakout={parseFloat(selectedPairData.upperBreakout)}
                      lowerBreakout={parseFloat(selectedPairData.lowerBreakout)}
                    />
                  )}
                </div>
                <div>
                  <RiskManagement />
                </div>
              </div>

              {/* Active Positions & Trade History */}
              <div className="grid grid-cols-2 gap-6">
                <ActivePositions />
                <TradeHistory />
              </div>
            </TabsContent>

            <TabsContent value="analysis" className="mt-6">
              <div className="grid grid-cols-1 gap-6">
                {selectedPairData && (
                  <AdvancedChart
                    symbol={selectedPairData.symbol}
                    currentPrice={parseFloat(selectedPairData.currentPrice)}
                    upperBreakout={parseFloat(selectedPairData.upperBreakout)}
                    lowerBreakout={parseFloat(selectedPairData.lowerBreakout)}
                  />
                )}
                
                <div className="grid grid-cols-3 gap-6">
                  {currencyPairs?.map((pair) => (
                    <div
                      key={pair.symbol}
                      onClick={() => setSelectedPair(pair.symbol)}
                      className={`cursor-pointer transition-all duration-200 ${
                        selectedPair === pair.symbol 
                          ? 'ring-2 ring-[hsl(207,90%,54%)] ring-opacity-50' 
                          : 'hover:ring-1 hover:ring-[hsl(240,3.7%,35.9%)]'
                      }`}
                    >
                      <CurrencyPairCard pair={pair} />
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="backtest" className="mt-6">
              <BacktestingPanel />
            </TabsContent>

            <TabsContent value="automation" className="mt-6">
              <div className="grid grid-cols-2 gap-6">
                <TelegramControls />
                <RiskManagement />
              </div>
            </TabsContent>
          </Tabs>
        </main>

        <PerformancePanel />
      </div>
    </div>
  );
}
