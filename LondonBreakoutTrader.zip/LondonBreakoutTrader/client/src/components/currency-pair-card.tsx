import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { calculatePositionSize } from "@/lib/trading-utils";
import { useTradingData } from "@/hooks/use-trading-data";
import type { CurrencyPair } from "@shared/schema";

interface CurrencyPairCardProps {
  pair: CurrencyPair;
}

export default function CurrencyPairCard({ pair }: CurrencyPairCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { botSettings } = useTradingData();

  const executeTradeMutation = useMutation({
    mutationFn: async (tradeData: any) => {
      const response = await apiRequest("POST", "/api/trades", tradeData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
      toast({
        title: "Trade Executed",
        description: `Position opened for ${pair.symbol}`,
      });
    },
    onError: () => {
      toast({
        title: "Trade Failed",
        description: "Failed to execute trade",
        variant: "destructive",
      });
    },
  });

  const handleTrade = (type: 'BUY' | 'SELL') => {
    if (!botSettings) return;

    if (botSettings.tradesUsedToday >= botSettings.maxTradesPerDay) {
      toast({
        title: "Daily Limit Reached",
        description: "Maximum trades per day exceeded",
        variant: "destructive",
      });
      return;
    }

    const currentPrice = parseFloat(pair.currentPrice);
    const positionSize = calculatePositionSize(
      parseFloat(botSettings.accountBalance),
      parseFloat(botSettings.riskPercentage),
      currentPrice,
      type === 'BUY' ? parseFloat(pair.lowerBreakout) : parseFloat(pair.upperBreakout)
    );

    const tradeData = {
      symbol: pair.symbol,
      type: type === 'BUY' ? 'LONG' : 'SHORT',
      size: positionSize.toString(),
      entryPrice: pair.currentPrice,
      stopLoss: type === 'BUY' ? pair.lowerBreakout : pair.upperBreakout,
      takeProfit: type === 'BUY' ? pair.upperBreakout : pair.lowerBreakout,
      status: 'OPEN',
    };

    executeTradeMutation.mutate(tradeData);
  };

  const getPairIcon = (symbol: string) => {
    switch (symbol) {
      case 'EUR/USD':
        return 'EU';
      case 'GBP/USD':
        return 'GU';
      case 'USD/JPY':
        return 'UJ';
      default:
        return symbol.substring(0, 2);
    }
  };

  const getPairGradient = (symbol: string) => {
    switch (symbol) {
      case 'EUR/USD':
        return 'from-blue-500 to-yellow-500';
      case 'GBP/USD':
        return 'from-red-500 to-blue-500';
      case 'USD/JPY':
        return 'from-blue-500 to-red-500';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const isPositive = parseFloat(pair.change) >= 0;

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-8 h-8 bg-gradient-to-br ${getPairGradient(pair.symbol)} rounded-full flex items-center justify-center text-xs font-bold`}>
            {getPairIcon(pair.symbol)}
          </div>
          <div>
            <h3 className="font-semibold">{pair.symbol}</h3>
            <div className="text-xs text-[hsl(0,0%,62%)]">{pair.name}</div>
          </div>
        </div>
        <div className="w-2 h-2 bg-[hsl(142,71%,45%)] rounded-full"></div>
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-[hsl(0,0%,62%)]">Current Price</span>
          <span className={`font-mono text-lg font-bold ${isPositive ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
            {pair.currentPrice}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm text-[hsl(0,0%,62%)]">Change</span>
          <span className={`font-mono text-sm ${isPositive ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
            {isPositive ? '+' : ''}{pair.change} ({isPositive ? '+' : ''}{pair.changePercent}%)
          </span>
        </div>
        
        <div className="border-t border-[hsl(240,3.7%,25.9%)] pt-3">
          <div className="flex justify-between text-xs text-[hsl(0,0%,62%)] mb-2">
            <span>Overnight Range</span>
            <span>Breakout Zones</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs">{pair.overnightRangeLow} - {pair.overnightRangeHigh}</span>
            <div className="flex space-x-2">
              <span className="px-2 py-1 bg-[hsl(142,71%,45%)]/20 text-[hsl(142,71%,45%)] text-xs rounded font-mono">
                {pair.upperBreakout}↑
              </span>
              <span className="px-2 py-1 bg-[hsl(0,84%,60%)]/20 text-[hsl(0,84%,60%)] text-xs rounded font-mono">
                {pair.lowerBreakout}↓
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex space-x-2 pt-2">
          <Button
            className="flex-1 bg-[hsl(142,71%,45%)]/20 hover:bg-[hsl(142,71%,45%)]/30 text-[hsl(142,71%,45%)] border border-[hsl(142,71%,45%)]/30"
            variant="outline"
            onClick={() => handleTrade('BUY')}
            disabled={executeTradeMutation.isPending}
          >
            <i className="fas fa-arrow-up mr-1"></i>BUY
          </Button>
          <Button
            className="flex-1 bg-[hsl(0,84%,60%)]/20 hover:bg-[hsl(0,84%,60%)]/30 text-[hsl(0,84%,60%)] border border-[hsl(0,84%,60%)]/30"
            variant="outline"
            onClick={() => handleTrade('SELL')}
            disabled={executeTradeMutation.isPending}
          >
            <i className="fas fa-arrow-down mr-1"></i>SELL
          </Button>
        </div>
      </div>
    </div>
  );
}
