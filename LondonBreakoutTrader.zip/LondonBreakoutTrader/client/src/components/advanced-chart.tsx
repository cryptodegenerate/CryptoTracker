import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface TechnicalSignals {
  sma20: number;
  sma50: number;
  ema12: number;
  ema26: number;
  rsi: number;
  macd: {
    MACD: number;
    signal: number;
    histogram: number;
  };
  bollingerBands: {
    upper: number;
    middle: number;
    lower: number;
  };
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  strength: number;
  breakoutProbability: number;
}

interface PriceData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

interface AdvancedChartProps {
  symbol: string;
  currentPrice: number;
  upperBreakout: number;
  lowerBreakout: number;
}

export default function AdvancedChart({ symbol, currentPrice, upperBreakout, lowerBreakout }: AdvancedChartProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState("5M");
  const [showIndicators, setShowIndicators] = useState(true);

  const { data: technicalSignals } = useQuery<TechnicalSignals>({
    queryKey: ['/api/technical-analysis', symbol],
    refetchInterval: 5000,
  });

  const { data: priceHistory } = useQuery<PriceData[]>({
    queryKey: ['/api/price-history', symbol],
    refetchInterval: 10000,
  });

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'BULLISH': return 'text-[hsl(142,71%,45%)] bg-[hsl(142,71%,45%)]/10 border-[hsl(142,71%,45%)]/30';
      case 'BEARISH': return 'text-[hsl(0,84%,60%)] bg-[hsl(0,84%,60%)]/10 border-[hsl(0,84%,60%)]/30';
      default: return 'text-[hsl(0,0%,62%)] bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,25.9%)]';
    }
  };

  const getStrengthColor = (strength: number) => {
    if (strength > 70) return 'text-[hsl(142,71%,45%)]';
    if (strength > 40) return 'text-[hsl(33,95%,54%)]';
    return 'text-[hsl(0,84%,60%)]';
  };

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">{symbol} - Advanced Chart</h3>
        <div className="flex items-center space-x-3">
          <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
            <SelectTrigger className="w-20 bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1M">1M</SelectItem>
              <SelectItem value="5M">5M</SelectItem>
              <SelectItem value="15M">15M</SelectItem>
              <SelectItem value="1H">1H</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            size="sm" 
            variant="outline" 
            className={`${showIndicators ? 'bg-[hsl(207,90%,54%)] text-white' : 'bg-[hsl(240,3.7%,25.9%)]'} border-[hsl(207,90%,54%)]`}
            onClick={() => setShowIndicators(!showIndicators)}
          >
            <i className="fas fa-chart-line mr-1"></i>Indicators
          </Button>
          
          <Button size="sm" variant="outline" className="bg-[hsl(207,90%,54%)] hover:bg-[hsl(207,90%,44%)] border-[hsl(207,90%,54%)]">
            <i className="fas fa-expand-arrows-alt"></i>
          </Button>
        </div>
      </div>

      {/* Technical Signals Overview */}
      {technicalSignals && (
        <div className="grid grid-cols-4 gap-4 mb-6">
          <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <Badge className={getTrendColor(technicalSignals.trend)} variant="outline">
                {technicalSignals.trend}
              </Badge>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Strength</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`font-mono text-lg font-bold ${getStrengthColor(technicalSignals.strength)}`}>
                {technicalSignals.strength.toFixed(1)}%
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-[hsl(0,0%,62%)]">RSI</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`font-mono text-lg font-bold ${technicalSignals.rsi > 70 ? 'text-[hsl(0,84%,60%)]' : technicalSignals.rsi < 30 ? 'text-[hsl(142,71%,45%)]' : 'text-white'}`}>
                {technicalSignals.rsi.toFixed(1)}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Breakout Prob.</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`font-mono text-lg font-bold ${getStrengthColor(technicalSignals.breakoutProbability)}`}>
                {technicalSignals.breakoutProbability.toFixed(1)}%
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Enhanced Chart */}
      <div className="relative h-96 bg-gradient-to-b from-[hsl(240,10%,3.9%)]/50 to-[hsl(240,10%,3.9%)] border border-[hsl(240,3.7%,25.9%)] rounded-lg p-4">
        <div className="absolute inset-4">
          <svg className="w-full h-full" viewBox="0 0 600 300">
            {/* Grid Lines */}
            <defs>
              <pattern id="grid" width="60" height="30" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 30" fill="none" stroke="hsl(240,3.7%,25.9%)" strokeWidth="0.5" opacity="0.3"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            
            {/* Bollinger Bands */}
            {technicalSignals && showIndicators && (
              <g>
                <path 
                  d={`M 0 ${150 - (technicalSignals.bollingerBands.upper - currentPrice) * 5000} L 600 ${150 - (technicalSignals.bollingerBands.upper - currentPrice) * 5000}`}
                  stroke="hsl(207,90%,54%)" 
                  strokeWidth="1" 
                  strokeDasharray="3,3"
                  opacity="0.6"
                />
                <path 
                  d={`M 0 ${150 - (technicalSignals.bollingerBands.lower - currentPrice) * 5000} L 600 ${150 - (technicalSignals.bollingerBands.lower - currentPrice) * 5000}`}
                  stroke="hsl(207,90%,54%)" 
                  strokeWidth="1" 
                  strokeDasharray="3,3"
                  opacity="0.6"
                />
              </g>
            )}
            
            {/* Breakout Zones */}
            <rect x="0" y="40" width="600" height="12" fill="hsl(142,71%,45%)" opacity="0.2"/>
            <rect x="0" y="248" width="600" height="12" fill="hsl(0,84%,60%)" opacity="0.2"/>
            
            {/* Price Candlesticks - Enhanced visualization */}
            {priceHistory && priceHistory.slice(-30).map((candle, index) => {
              const x = (index * 20) + 10;
              const high = 50 + (upperBreakout - candle.high) * 1000;
              const low = 50 + (upperBreakout - candle.low) * 1000;
              const open = 50 + (upperBreakout - candle.open) * 1000;
              const close = 50 + (upperBreakout - candle.close) * 1000;
              const isGreen = candle.close > candle.open;
              
              return (
                <g key={index}>
                  {/* Wick */}
                  <line 
                    x1={x} 
                    y1={Math.max(high, 50)} 
                    x2={x} 
                    y2={Math.min(low, 250)} 
                    stroke={isGreen ? "hsl(142,71%,45%)" : "hsl(0,84%,60%)"} 
                    strokeWidth="1"
                  />
                  {/* Body */}
                  <rect
                    x={x - 6}
                    y={Math.min(open, close)}
                    width="12"
                    height={Math.abs(open - close)}
                    fill={isGreen ? "hsl(142,71%,45%)" : "hsl(0,84%,60%)"}
                    opacity="0.8"
                  />
                </g>
              );
            })}
            
            {/* Moving Averages */}
            {technicalSignals && showIndicators && (
              <g>
                <path 
                  d="M 0 150 Q 150 140 300 145 T 600 150" 
                  fill="none" 
                  stroke="hsl(33,95%,54%)" 
                  strokeWidth="2"
                  opacity="0.8"
                />
                <path 
                  d="M 0 155 Q 150 145 300 150 T 600 155" 
                  fill="none" 
                  stroke="hsl(207,90%,54%)" 
                  strokeWidth="2"
                  opacity="0.8"
                />
              </g>
            )}
            
            {/* Breakout Level Lines */}
            <line 
              x1="0" y1="46" x2="600" y2="46" 
              stroke="hsl(142,71%,45%)" 
              strokeWidth="2" 
              strokeDasharray="8,4"
            />
            <line 
              x1="0" y1="254" x2="600" y2="254" 
              stroke="hsl(0,84%,60%)" 
              strokeWidth="2" 
              strokeDasharray="8,4"
            />
            
            {/* Current Price Line */}
            <line 
              x1="0" y1="150" x2="600" y2="150" 
              stroke="white" 
              strokeWidth="2"
            />
            <circle cx="600" cy="150" r="4" fill="white"/>
            <text x="560" y="145" fill="white" fontSize="12" fontFamily="monospace">
              {currentPrice.toFixed(symbol === 'USD/JPY' ? 2 : 4)}
            </text>
          </svg>
        </div>
        
        {/* Chart Legend */}
        <div className="absolute bottom-2 left-4 flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-1 bg-[hsl(142,71%,45%)]"></div>
            <span className="text-[hsl(0,0%,62%)]">Upper Breakout ({upperBreakout.toFixed(4)})</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-1 bg-[hsl(0,84%,60%)]"></div>
            <span className="text-[hsl(0,0%,62%)]">Lower Breakout ({lowerBreakout.toFixed(4)})</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-1 bg-white"></div>
            <span className="text-[hsl(0,0%,62%)]">Current Price</span>
          </div>
          {showIndicators && technicalSignals && (
            <>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-1 bg-[hsl(33,95%,54%)]"></div>
                <span className="text-[hsl(0,0%,62%)]">SMA 20 ({technicalSignals.sma20.toFixed(4)})</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-1 bg-[hsl(207,90%,54%)]"></div>
                <span className="text-[hsl(0,0%,62%)]">SMA 50 ({technicalSignals.sma50.toFixed(4)})</span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* MACD Indicator */}
      {technicalSignals && showIndicators && (
        <div className="mt-4 p-4 bg-[hsl(240,10%,3.9%)] rounded-lg border border-[hsl(240,3.7%,25.9%)]">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-[hsl(0,0%,88%)]">MACD</h4>
            <div className="flex space-x-4 text-xs">
              <span className="text-[hsl(0,0%,62%)]">
                MACD: <span className="font-mono text-white">{technicalSignals.macd.MACD.toFixed(6)}</span>
              </span>
              <span className="text-[hsl(0,0%,62%)]">
                Signal: <span className="font-mono text-white">{technicalSignals.macd.signal.toFixed(6)}</span>
              </span>
              <span className="text-[hsl(0,0%,62%)]">
                Hist: <span className={`font-mono ${technicalSignals.macd.histogram > 0 ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                  {technicalSignals.macd.histogram.toFixed(6)}
                </span>
              </span>
            </div>
          </div>
          <div className="h-16 relative">
            <svg className="w-full h-full" viewBox="0 0 600 60">
              <line x1="0" y1="30" x2="600" y2="30" stroke="hsl(240,3.7%,25.9%)" strokeWidth="1"/>
              <rect 
                x="290" 
                y={technicalSignals.macd.histogram > 0 ? 30 - Math.abs(technicalSignals.macd.histogram * 500000) : 30}
                width="20" 
                height={Math.abs(technicalSignals.macd.histogram * 500000)}
                fill={technicalSignals.macd.histogram > 0 ? "hsl(142,71%,45%)" : "hsl(0,84%,60%)"}
                opacity="0.7"
              />
            </svg>
          </div>
        </div>
      )}
    </div>
  );
}