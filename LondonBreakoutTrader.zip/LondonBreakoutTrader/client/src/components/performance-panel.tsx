import { useState } from "react";
import { Switch } from "@/components/ui/switch";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useTradingData } from "@/hooks/use-trading-data";
import { calculatePerformanceMetrics } from "@/lib/trading-utils";

export default function PerformancePanel() {
  const queryClient = useQueryClient();
  const { botSettings, allTrades, alerts } = useTradingData();

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PATCH", "/api/bot-settings", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-settings'] });
    },
  });

  const performance = allTrades ? calculatePerformanceMetrics(allTrades) : {
    todayPnL: 0,
    todayWinRate: 0,
    todayTrades: 0,
    weeklyPnL: 0,
    weeklyWinRate: 0,
    maxDrawdown: 0,
    sharpeRatio: 0,
    currentDrawdown: 0,
    accountUsage: 0
  };

  const handleSettingChange = (setting: string, value: boolean) => {
    updateSettingsMutation.mutate({ [setting]: value });
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'BREAKOUT':
        return 'fas fa-exclamation-triangle';
      case 'POSITION_OPENED':
      case 'POSITION_CLOSED':
        return 'fas fa-check-circle';
      case 'SESSION_STARTED':
        return 'fas fa-info-circle';
      default:
        return 'fas fa-bell';
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'BREAKOUT':
        return 'text-[hsl(33,95%,54%)] bg-[hsl(33,95%,54%)]/10 border-[hsl(33,95%,54%)]/30';
      case 'POSITION_OPENED':
      case 'POSITION_CLOSED':
        return 'text-[hsl(142,71%,45%)] bg-[hsl(142,71%,45%)]/10 border-[hsl(142,71%,45%)]/30';
      case 'SESSION_STARTED':
        return 'text-[hsl(207,90%,54%)] bg-[hsl(207,90%,54%)]/10 border-[hsl(207,90%,54%)]/30';
      default:
        return 'text-[hsl(0,0%,62%)] bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,25.9%)]';
    }
  };

  const formatTime = (dateStr: string | Date) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays > 0) return `${diffDays}d ago`;
    if (diffHours > 0) return `${diffHours}h ago`;
    if (diffMins > 0) return `${diffMins}m ago`;
    return 'Just now';
  };

  return (
    <aside className="w-80 bg-[hsl(240,3.7%,15.9%)] border-l border-[hsl(240,3.7%,25.9%)] p-6 overflow-auto">
      {/* Performance Overview */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-6">Performance Overview</h3>
        
        {/* Today's Performance */}
        <div className="bg-[hsl(240,10%,3.9%)] rounded-lg border border-[hsl(240,3.7%,25.9%)] p-4 mb-6">
          <div className="text-sm text-[hsl(0,0%,62%)] mb-3">Today's Performance</div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">P&L</span>
              <span className={`font-mono font-semibold ${performance.todayPnL >= 0 ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                {performance.todayPnL >= 0 ? '+' : ''}${performance.todayPnL.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Win Rate</span>
              <span className="font-mono font-semibold">{performance.todayWinRate.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Trades</span>
              <span className="font-mono font-semibold">{performance.todayTrades}</span>
            </div>
          </div>
        </div>

        {/* Weekly Stats */}
        <div className="bg-[hsl(240,10%,3.9%)] rounded-lg border border-[hsl(240,3.7%,25.9%)] p-4 mb-6">
          <div className="text-sm text-[hsl(0,0%,62%)] mb-3">This Week</div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Total P&L</span>
              <span className={`font-mono font-semibold ${performance.weeklyPnL >= 0 ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                {performance.weeklyPnL >= 0 ? '+' : ''}${performance.weeklyPnL.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Win Rate</span>
              <span className="font-mono font-semibold">{performance.weeklyWinRate.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Max Drawdown</span>
              <span className="font-mono font-semibold text-[hsl(0,84%,60%)]">-{performance.maxDrawdown.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Sharpe Ratio</span>
              <span className="font-mono font-semibold">{performance.sharpeRatio.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Risk Metrics */}
        <div className="bg-[hsl(240,10%,3.9%)] rounded-lg border border-[hsl(240,3.7%,25.9%)] p-4">
          <div className="text-sm text-[hsl(0,0%,62%)] mb-3">Risk Metrics</div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Current Drawdown</span>
              <span className={`font-mono font-semibold ${performance.currentDrawdown === 0 ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                {performance.currentDrawdown.toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Risk per Trade</span>
              <span className="font-mono font-semibold">
                {botSettings ? botSettings.riskPercentage : '1.5'}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Account Usage</span>
              <span className="font-mono font-semibold">{performance.accountUsage.toFixed(1)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Trading Alerts */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Trading Alerts</h3>
        
        <div className="space-y-3">
          {alerts && alerts.length > 0 ? (
            alerts.slice(0, 5).map((alert) => (
              <div key={alert.id} className={`rounded-lg p-3 border ${getAlertColor(alert.type)}`}>
                <div className="flex items-start space-x-2">
                  <i className={`${getAlertIcon(alert.type)} text-sm mt-0.5`}></i>
                  <div>
                    <div className="text-sm font-medium capitalize">
                      {alert.type.replace('_', ' ').toLowerCase()}
                    </div>
                    <div className="text-xs text-[hsl(0,0%,88%)] mt-1">{alert.message}</div>
                    <div className="text-xs text-[hsl(0,0%,62%)] mt-1">{formatTime(alert.createdAt)}</div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-[hsl(0,0%,62%)]">
              <i className="fas fa-bell text-2xl mb-3 opacity-50"></i>
              <p>No alerts</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Settings */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Quick Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm">Auto-Trading</span>
            <Switch
              checked={botSettings?.autoTradingEnabled || false}
              onCheckedChange={(checked) => handleSettingChange('autoTradingEnabled', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm">Sound Alerts</span>
            <Switch
              checked={botSettings?.soundAlertsEnabled || false}
              onCheckedChange={(checked) => handleSettingChange('soundAlertsEnabled', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm">Email Notifications</span>
            <Switch
              checked={botSettings?.emailNotificationsEnabled || false}
              onCheckedChange={(checked) => handleSettingChange('emailNotificationsEnabled', checked)}
            />
          </div>
        </div>
      </div>
    </aside>
  );
}
