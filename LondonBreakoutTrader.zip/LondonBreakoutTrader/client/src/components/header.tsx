import { useEffect, useState } from "react";
import { useTradingData } from "@/hooks/use-trading-data";

export default function Header() {
  const [londonTime, setLondonTime] = useState("");
  const [sessionTimeRemaining, setSessionTimeRemaining] = useState("01:15:32");
  const { botSettings } = useTradingData();

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const londonTimeStr = now.toLocaleTimeString('en-GB', {
        timeZone: 'Europe/London',
        hour12: false
      });
      setLondonTime(londonTimeStr);

      // Mock session time remaining calculation
      const hours = Math.floor(Math.random() * 2) + 1;
      const minutes = Math.floor(Math.random() * 59);
      const seconds = Math.floor(Math.random() * 59);
      setSessionTimeRemaining(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-[hsl(240,3.7%,15.9%)] border-b border-[hsl(240,3.7%,25.9%)] px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <h1 className="text-xl font-bold text-[hsl(207,90%,54%)]">
            <i className="fas fa-chart-line mr-2"></i>
            London Breakout Bot
          </h1>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-[hsl(142,71%,45%)] rounded-full animate-pulse"></div>
              <span className="text-sm text-[hsl(0,0%,88%)]">Live Session</span>
            </div>
            <div className="text-sm text-[hsl(0,0%,62%)]">
              London: <span className="font-mono text-white">{londonTime}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <div className="text-sm text-[hsl(0,0%,62%)]">Account Balance</div>
            <div className="font-mono text-lg font-semibold">
              ${botSettings ? parseFloat(botSettings.accountBalance).toLocaleString('en-US', { minimumFractionDigits: 2 }) : '25,000.00'}
            </div>
          </div>
          <button className="bg-[hsl(207,90%,54%)] hover:bg-[hsl(207,90%,44%)] px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <i className="fas fa-cog mr-2"></i>Settings
          </button>
        </div>
      </div>
    </header>
  );
}
