import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTradingData } from "@/hooks/use-trading-data";
import { formatTime, calculatePnL } from "@/lib/trading-utils";

export default function ActivePositions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { activeTrades, currencyPairs } = useTradingData();

  const closePositionMutation = useMutation({
    mutationFn: async ({ tradeId, exitPrice, pnl }: { tradeId: number, exitPrice: string, pnl: string }) => {
      const response = await apiRequest("POST", `/api/trading/close-position/${tradeId}`, {
        exitPrice,
        pnl
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      toast({
        title: "Position Closed",
        description: "Position has been successfully closed",
      });
    },
  });

  const handleClosePosition = (trade: any) => {
    const pair = currencyPairs?.find(p => p.symbol === trade.symbol);
    if (!pair) return;

    const currentPrice = parseFloat(pair.currentPrice);
    const pnl = calculatePnL(
      parseFloat(trade.entryPrice),
      currentPrice,
      parseFloat(trade.size),
      trade.type
    );

    closePositionMutation.mutate({
      tradeId: trade.id,
      exitPrice: pair.currentPrice,
      pnl: pnl.toFixed(2)
    });
  };

  const getPairIcon = (symbol: string) => {
    switch (symbol) {
      case 'EUR/USD': return 'EU';
      case 'GBP/USD': return 'GU';
      case 'USD/JPY': return 'UJ';
      default: return symbol.substring(0, 2);
    }
  };

  const getPairGradient = (symbol: string) => {
    switch (symbol) {
      case 'EUR/USD': return 'from-blue-500 to-yellow-500';
      case 'GBP/USD': return 'from-red-500 to-blue-500';
      case 'USD/JPY': return 'from-blue-500 to-red-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Active Positions</h3>
        <span className="px-3 py-1 bg-[hsl(207,90%,54%)]/20 text-[hsl(207,90%,54%)] text-sm rounded-full font-medium">
          {activeTrades?.length || 0} Position{activeTrades?.length !== 1 ? 's' : ''}
        </span>
      </div>

      <div className="space-y-4">
        {activeTrades && activeTrades.length > 0 ? (
          activeTrades.map((trade) => {
            const pair = currencyPairs?.find(p => p.symbol === trade.symbol);
            const currentPrice = pair ? parseFloat(pair.currentPrice) : parseFloat(trade.entryPrice);
            const pnl = calculatePnL(
              parseFloat(trade.entryPrice),
              currentPrice,
              parseFloat(trade.size),
              trade.type
            );
            const pnlPercent = (pnl / (parseFloat(trade.entryPrice) * parseFloat(trade.size) * 100000)) * 100;
            const isProfit = pnl >= 0;

            return (
              <div key={trade.id} className="bg-[hsl(240,10%,3.9%)] rounded-lg border border-[hsl(240,3.7%,25.9%)] p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 bg-gradient-to-br ${getPairGradient(trade.symbol)} rounded-full flex items-center justify-center text-xs font-bold`}>
                      {getPairIcon(trade.symbol)}
                    </div>
                    <div>
                      <div className="font-semibold">{trade.symbol}</div>
                      <div className={`text-xs ${trade.type === 'LONG' ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                        {trade.type} • {trade.size} lots
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-mono font-semibold ${isProfit ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                      {isProfit ? '+' : ''}${pnl.toFixed(2)}
                    </div>
                    <div className="text-xs text-[hsl(0,0%,62%)]">
                      {isProfit ? '+' : ''}{pnlPercent.toFixed(2)}%
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-[hsl(0,0%,62%)] block">Entry Price</span>
                    <span className="font-mono font-semibold">{trade.entryPrice}</span>
                  </div>
                  <div>
                    <span className="text-[hsl(0,0%,62%)] block">Current Price</span>
                    <span className="font-mono font-semibold">{currentPrice.toFixed(trade.symbol === 'USD/JPY' ? 2 : 4)}</span>
                  </div>
                  <div>
                    <span className="text-[hsl(0,0%,62%)] block">Stop Loss</span>
                    <span className="font-mono text-[hsl(0,84%,60%)]">{trade.stopLoss}</span>
                  </div>
                  <div>
                    <span className="text-[hsl(0,0%,62%)] block">Take Profit</span>
                    <span className="font-mono text-[hsl(142,71%,45%)]">{trade.takeProfit}</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center mt-4 pt-3 border-t border-[hsl(240,3.7%,25.9%)]">
                  <div className="text-xs text-[hsl(0,0%,62%)]">
                    Opened: <span>{formatTime(trade.openedAt)}</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-[hsl(0,84%,60%)] hover:bg-[hsl(0,84%,50%)] text-white"
                    onClick={() => handleClosePosition(trade)}
                    disabled={closePositionMutation.isPending}
                  >
                    Close Position
                  </Button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8 text-[hsl(0,0%,62%)]">
            <i className="fas fa-chart-line text-2xl mb-3 opacity-50"></i>
            <p>No active positions</p>
            <p className="text-xs mt-1">Waiting for breakout signals...</p>
          </div>
        )}
      </div>
    </div>
  );
}
