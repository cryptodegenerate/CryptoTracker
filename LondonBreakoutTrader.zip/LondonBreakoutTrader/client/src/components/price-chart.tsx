import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

export default function PriceChart() {
  const [selectedTimeframe, setSelectedTimeframe] = useState("5M");

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">EUR/USD - 5M Chart</h3>
        <div className="flex items-center space-x-3">
          <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
            <SelectTrigger className="w-20 bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1M">1M</SelectItem>
              <SelectItem value="5M">5M</SelectItem>
              <SelectItem value="15M">15M</SelectItem>
              <SelectItem value="1H">1H</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" variant="outline" className="bg-[hsl(207,90%,54%)] hover:bg-[hsl(207,90%,44%)] border-[hsl(207,90%,54%)]">
            <i className="fas fa-expand-arrows-alt"></i>
          </Button>
        </div>
      </div>
      
      <div className="relative h-80 bg-gradient-to-b from-[hsl(240,10%,3.9%)]/50 to-[hsl(240,10%,3.9%)] border border-[hsl(240,3.7%,25.9%)] rounded-lg p-4">
        <div className="absolute inset-4">
          <svg className="w-full h-full" viewBox="0 0 400 200">
            {/* Grid Lines */}
            <defs>
              <pattern id="grid" width="40" height="20" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 20" fill="none" stroke="hsl(240,3.7%,25.9%)" strokeWidth="0.5" opacity="0.3"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            
            {/* Breakout Zones */}
            <rect x="0" y="30" width="400" height="8" fill="hsl(142,71%,45%)" opacity="0.2"/>
            <rect x="0" y="162" width="400" height="8" fill="hsl(0,84%,60%)" opacity="0.2"/>
            
            {/* Price Line */}
            <polyline 
              points="0,100 50,98 100,95 150,93 200,96 250,99 300,102 350,104 400,103" 
              fill="none" 
              stroke="hsl(207,90%,54%)" 
              strokeWidth="2"
            />
            
            {/* Breakout Level Lines */}
            <line 
              x1="0" y1="34" x2="400" y2="34" 
              stroke="hsl(142,71%,45%)" 
              strokeWidth="1" 
              strokeDasharray="5,5"
            />
            <line 
              x1="0" y1="166" x2="400" y2="166" 
              stroke="hsl(0,84%,60%)" 
              strokeWidth="1" 
              strokeDasharray="5,5"
            />
            
            {/* Current Price Indicator */}
            <circle cx="400" cy="103" r="3" fill="hsl(207,90%,54%)"/>
            <text x="380" y="98" fill="hsl(207,90%,54%)" fontSize="10" fontFamily="monospace">1.0847</text>
          </svg>
        </div>
        
        {/* Chart Legend */}
        <div className="absolute bottom-2 left-4 flex items-center space-x-4 text-xs">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-1 bg-[hsl(142,71%,45%)]"></div>
            <span className="text-[hsl(0,0%,62%)]">Upper Breakout (1.0865)</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-1 bg-[hsl(0,84%,60%)]"></div>
            <span className="text-[hsl(0,0%,62%)]">Lower Breakout (1.0819)</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-1 bg-[hsl(207,90%,54%)]"></div>
            <span className="text-[hsl(0,0%,62%)]">Current Price</span>
          </div>
        </div>
      </div>
    </div>
  );
}
