import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTradingData } from "@/hooks/use-trading-data";
import { calculatePositionSize, calculateMarginRequired } from "@/lib/trading-utils";

export default function RiskManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { botSettings, activeTrades } = useTradingData();
  
  const [riskPercentage, setRiskPercentage] = useState(
    botSettings ? parseFloat(botSettings.riskPercentage) : 1.5
  );
  const [leverage, setLeverage] = useState(
    botSettings ? botSettings.leverage.toString() : "10"
  );

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PATCH", "/api/bot-settings", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-settings'] });
      toast({
        title: "Settings Updated",
        description: "Risk management settings have been updated",
      });
    },
  });

  const closeAllPositionsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/trading/close-all-positions");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      toast({
        title: "All Positions Closed",
        description: "All open positions have been closed",
      });
    },
  });

  const handleRiskChange = (value: number[]) => {
    const newRisk = value[0];
    setRiskPercentage(newRisk);
    updateSettingsMutation.mutate({ riskPercentage: newRisk.toString() });
  };

  const handleLeverageChange = (value: string) => {
    setLeverage(value);
    updateSettingsMutation.mutate({ leverage: parseInt(value) });
  };

  const accountBalance = botSettings ? parseFloat(botSettings.accountBalance) : 25000;
  const maxRiskAmount = (accountBalance * riskPercentage) / 100;
  const positionSize = calculatePositionSize(accountBalance, riskPercentage, 1.0847, 1.0814);
  const marginRequired = calculateMarginRequired(1.0847, positionSize, parseInt(leverage));
  const tradesUsed = botSettings ? botSettings.tradesUsedToday : 0;
  const maxTrades = botSettings ? botSettings.maxTradesPerDay : 2;

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <h3 className="text-lg font-semibold mb-6">Risk Management</h3>
      
      <div className="space-y-6">
        {/* Position Size Calculator */}
        <div>
          <label className="block text-sm text-[hsl(0,0%,62%)] mb-2">Risk per Trade</label>
          <div className="flex items-center space-x-2">
            <Slider
              value={[riskPercentage]}
              onValueChange={handleRiskChange}
              min={0.5}
              max={2.0}
              step={0.1}
              className="flex-1"
            />
            <span className="font-mono text-sm font-semibold text-[hsl(33,95%,54%)] min-w-[3rem]">
              {riskPercentage.toFixed(1)}%
            </span>
          </div>
          <div className="text-xs text-[hsl(0,0%,62%)] mt-1">
            Max Risk: <span className="font-mono">${maxRiskAmount.toFixed(2)}</span>
          </div>
        </div>

        {/* Leverage Control */}
        <div>
          <label className="block text-sm text-[hsl(0,0%,62%)] mb-2">Leverage</label>
          <Select value={leverage} onValueChange={handleLeverageChange}>
            <SelectTrigger className="w-full bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">5:1</SelectItem>
              <SelectItem value="10">10:1</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Position Size Display */}
        <div className="bg-[hsl(240,10%,3.9%)] rounded-lg p-4 border border-[hsl(240,3.7%,25.9%)]">
          <div className="text-sm text-[hsl(0,0%,62%)] mb-2">Calculated Position Size</div>
          <div className="font-mono text-lg font-bold text-white">{positionSize.toFixed(3)} lots</div>
          <div className="text-xs text-[hsl(0,0%,62%)] mt-1">
            Margin Required: <span className="font-mono">${marginRequired.toFixed(2)}</span>
          </div>
        </div>

        {/* Daily Limits */}
        <div className="border-t border-[hsl(240,3.7%,25.9%)] pt-4">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm text-[hsl(0,0%,62%)]">Daily Trade Limit</span>
            <span className="font-mono text-sm font-semibold">
              <span className="text-white">{tradesUsed}</span>
              <span className="text-[hsl(0,0%,62%)]">/{maxTrades}</span>
            </span>
          </div>
          <div className="w-full bg-[hsl(240,3.7%,25.9%)] rounded-full h-2">
            <div 
              className="bg-[hsl(207,90%,54%)] h-2 rounded-full transition-all duration-300"
              style={{ width: `${(tradesUsed / maxTrades) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-2">
          <Button
            className="w-full bg-[hsl(33,95%,54%)] hover:bg-[hsl(33,95%,44%)] text-white"
            onClick={() => closeAllPositionsMutation.mutate()}
            disabled={closeAllPositionsMutation.isPending || !activeTrades?.length}
          >
            <i className="fas fa-times-circle mr-2"></i>Close All Positions
          </Button>
          <Button
            className="w-full bg-[hsl(240,3.7%,25.9%)] hover:bg-[hsl(240,3.7%,35.9%)] text-white"
            onClick={() => {
              updateSettingsMutation.mutate({ autoTradingEnabled: false });
              toast({
                title: "Bot Paused",
                description: "Auto-trading has been disabled",
              });
            }}
          >
            <i className="fas fa-pause mr-2"></i>Pause Bot
          </Button>
        </div>
      </div>
    </div>
  );
}
