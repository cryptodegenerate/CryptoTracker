import { Button } from "@/components/ui/button";
import { useTradingData } from "@/hooks/use-trading-data";
import { formatTime } from "@/lib/trading-utils";

export default function TradeHistory() {
  const { allTrades } = useTradingData();

  const recentTrades = allTrades?.filter(trade => trade.status === 'CLOSED').slice(0, 5);

  const getPairIcon = (symbol: string) => {
    switch (symbol) {
      case 'EUR/USD': return 'EU';
      case 'GBP/USD': return 'GU';
      case 'USD/JPY': return 'UJ';
      default: return symbol.substring(0, 2);
    }
  };

  const getPairGradient = (symbol: string) => {
    switch (symbol) {
      case 'EUR/USD': return 'from-blue-500 to-yellow-500';
      case 'GBP/USD': return 'from-red-500 to-blue-500';
      case 'USD/JPY': return 'from-blue-500 to-red-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Recent Trades</h3>
        <Button variant="ghost" className="text-[hsl(207,90%,54%)] hover:text-[hsl(207,90%,44%)] text-sm font-medium">
          View All <i className="fas fa-arrow-right ml-1"></i>
        </Button>
      </div>

      <div className="space-y-3">
        {recentTrades && recentTrades.length > 0 ? (
          recentTrades.map((trade) => {
            const pnl = trade.pnl ? parseFloat(trade.pnl) : 0;
            const isProfit = pnl >= 0;

            return (
              <div key={trade.id} className="flex items-center justify-between py-2 border-b border-[hsl(240,3.7%,25.9%)] last:border-b-0">
                <div className="flex items-center space-x-3">
                  <div className={`w-6 h-6 bg-gradient-to-br ${getPairGradient(trade.symbol)} rounded-full flex items-center justify-center text-xs font-bold`}>
                    {getPairIcon(trade.symbol)}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{trade.symbol}</div>
                    <div className="text-xs text-[hsl(0,0%,62%)]">{trade.type} • {trade.size} lots</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`font-mono font-semibold text-sm ${isProfit ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                    {isProfit ? '+' : ''}${Math.abs(pnl).toFixed(2)}
                  </div>
                  <div className="text-xs text-[hsl(0,0%,62%)]">
                    {trade.closedAt ? formatTime(trade.closedAt) : 'Open'}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8 text-[hsl(0,0%,62%)]">
            <i className="fas fa-history text-2xl mb-3 opacity-50"></i>
            <p>No trade history</p>
            <p className="text-xs mt-1">Recent trades will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
}
