import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BacktestResult {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalPnL: number;
  averageWin: number;
  averageLoss: number;
  maxDrawdown: number;
  sharpeRatio: number;
  profitFactor: number;
  trades: any[];
}

export default function BacktestingPanel() {
  const { toast } = useToast();
  const [selectedSymbol, setSelectedSymbol] = useState("EUR/USD");
  const [riskPercentage, setRiskPercentage] = useState(1.5);
  const [leverage, setLeverage] = useState(10);
  const [maxTradesPerDay, setMaxTradesPerDay] = useState(2);
  const [results, setResults] = useState<BacktestResult | null>(null);

  const backtestMutation = useMutation({
    mutationFn: async (settings: any) => {
      const response = await apiRequest("POST", `/api/backtest/${selectedSymbol}`, settings);
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      toast({
        title: "Backtest Complete",
        description: `Analyzed ${data.totalTrades} trades with ${data.winRate.toFixed(1)}% win rate`,
      });
    },
    onError: () => {
      toast({
        title: "Backtest Failed",
        description: "Failed to run backtest analysis",
        variant: "destructive",
      });
    },
  });

  const handleRunBacktest = () => {
    const settings = {
      riskPercentage,
      leverage,
      maxTradesPerDay,
      stopLossPoints: 15,
      takeProfitPoints: 30,
      sessionStartHour: 7,
      sessionEndHour: 10,
      timeframe: 5
    };

    backtestMutation.mutate(settings);
  };

  const getPerformanceColor = (value: number, isPositive: boolean = true) => {
    if (isPositive) {
      return value > 0 ? 'text-[hsl(142,71%,45%)]' : 'text-[hsl(0,84%,60%)]';
    } else {
      return value < 20 ? 'text-[hsl(142,71%,45%)]' : value < 50 ? 'text-[hsl(33,95%,54%)]' : 'text-[hsl(0,84%,60%)]';
    }
  };

  return (
    <div className="bg-[hsl(240,3.7%,15.9%)] rounded-xl border border-[hsl(240,3.7%,25.9%)] p-6">
      <h3 className="text-lg font-semibold mb-6">Strategy Backtesting</h3>
      
      {/* Backtest Settings */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-[hsl(0,0%,62%)] mb-2">Currency Pair</label>
            <Select value={selectedSymbol} onValueChange={setSelectedSymbol}>
              <SelectTrigger className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="EUR/USD">EUR/USD</SelectItem>
                <SelectItem value="GBP/USD">GBP/USD</SelectItem>
                <SelectItem value="USD/JPY">USD/JPY</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm text-[hsl(0,0%,62%)] mb-2">Risk per Trade: {riskPercentage.toFixed(1)}%</label>
            <Slider
              value={[riskPercentage]}
              onValueChange={(value) => setRiskPercentage(value[0])}
              min={0.5}
              max={3.0}
              step={0.1}
              className="w-full"
            />
          </div>

          <div>
            <label className="block text-sm text-[hsl(0,0%,62%)] mb-2">Leverage</label>
            <Select value={leverage.toString()} onValueChange={(value) => setLeverage(parseInt(value))}>
              <SelectTrigger className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5:1</SelectItem>
                <SelectItem value="10">10:1</SelectItem>
                <SelectItem value="20">20:1</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm text-[hsl(0,0%,62%)] mb-2">Max Trades/Day: {maxTradesPerDay}</label>
            <Slider
              value={[maxTradesPerDay]}
              onValueChange={(value) => setMaxTradesPerDay(value[0])}
              min={1}
              max={5}
              step={1}
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <div className="text-sm text-[hsl(0,0%,62%)]">Period: Last 30 days</div>
            <div className="text-sm text-[hsl(0,0%,62%)]">Stop Loss: 15 pips</div>
            <div className="text-sm text-[hsl(0,0%,62%)]">Take Profit: 30 pips</div>
            <div className="text-sm text-[hsl(0,0%,62%)]">Session: 7AM-10AM London</div>
          </div>

          <Button 
            className="w-full bg-[hsl(207,90%,54%)] hover:bg-[hsl(207,90%,44%)] text-white"
            onClick={handleRunBacktest}
            disabled={backtestMutation.isPending}
          >
            {backtestMutation.isPending ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>Running...
              </>
            ) : (
              <>
                <i className="fas fa-chart-area mr-2"></i>Run Backtest
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Backtest Results */}
      {results && (
        <div className="space-y-6">
          <div className="border-t border-[hsl(240,3.7%,25.9%)] pt-6">
            <h4 className="text-md font-semibold mb-4 text-[hsl(0,0%,88%)]">Backtest Results</h4>
            
            {/* Performance Overview */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Total P&L</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`font-mono text-xl font-bold ${getPerformanceColor(results.totalPnL)}`}>
                    {results.totalPnL >= 0 ? '+' : ''}${results.totalPnL.toFixed(2)}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Win Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`font-mono text-xl font-bold ${results.winRate > 60 ? 'text-[hsl(142,71%,45%)]' : results.winRate > 40 ? 'text-[hsl(33,95%,54%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                    {results.winRate.toFixed(1)}%
                  </div>
                  <div className="text-xs text-[hsl(0,0%,62%)]">
                    {results.winningTrades}W / {results.losingTrades}L
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Max Drawdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`font-mono text-xl font-bold ${getPerformanceColor(results.maxDrawdown, false)}`}>
                    {results.maxDrawdown.toFixed(1)}%
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Profit Factor</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`font-mono text-xl font-bold ${results.profitFactor > 1.5 ? 'text-[hsl(142,71%,45%)]' : results.profitFactor > 1.0 ? 'text-[hsl(33,95%,54%)]' : 'text-[hsl(0,84%,60%)]'}`}>
                    {results.profitFactor.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Statistics */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Trade Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Total Trades:</span>
                    <span className="font-mono">{results.totalTrades}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Avg Win:</span>
                    <span className="font-mono text-[hsl(142,71%,45%)]">+${results.averageWin.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Avg Loss:</span>
                    <span className="font-mono text-[hsl(0,84%,60%)]">-${results.averageLoss.toFixed(2)}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Risk Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Sharpe Ratio:</span>
                    <span className="font-mono">{results.sharpeRatio.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Risk/Trade:</span>
                    <span className="font-mono">{riskPercentage.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Leverage:</span>
                    <span className="font-mono">{leverage}:1</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,25.9%)]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[hsl(0,0%,62%)]">Strategy Rating</CardTitle>
                </CardHeader>
                <CardContent className="flex items-center justify-center">
                  <div className="text-center">
                    {(() => {
                      let rating = '';
                      let color = '';
                      if (results.totalPnL > 0 && results.winRate > 55 && results.maxDrawdown < 20) {
                        rating = 'Excellent';
                        color = 'text-[hsl(142,71%,45%)]';
                      } else if (results.totalPnL > 0 && results.winRate > 45) {
                        rating = 'Good';
                        color = 'text-[hsl(33,95%,54%)]';
                      } else if (results.totalPnL > 0) {
                        rating = 'Fair';
                        color = 'text-[hsl(33,95%,54%)]';
                      } else {
                        rating = 'Poor';
                        color = 'text-[hsl(0,84%,60%)]';
                      }
                      return (
                        <div className={`font-bold text-lg ${color}`}>
                          {rating}
                        </div>
                      );
                    })()}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Trades Sample */}
            <div className="bg-[hsl(240,10%,3.9%)] rounded-lg p-4 border border-[hsl(240,3.7%,25.9%)]">
              <h5 className="text-sm font-semibold mb-3 text-[hsl(0,0%,88%)]">Recent Trades Sample</h5>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {results.trades.slice(-10).map((trade, index) => (
                  <div key={index} className="flex items-center justify-between py-1 text-sm">
                    <div className="flex items-center space-x-3">
                      <span className={`px-2 py-1 rounded text-xs ${trade.type === 'LONG' ? 'bg-[hsl(142,71%,45%)]/20 text-[hsl(142,71%,45%)]' : 'bg-[hsl(0,84%,60%)]/20 text-[hsl(0,84%,60%)]'}`}>
                        {trade.type}
                      </span>
                      <span className="font-mono text-xs">{trade.entryPrice.toFixed(4)} → {trade.exitPrice.toFixed(4)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-[hsl(0,0%,62%)]">{Math.round(trade.duration)}m</span>
                      <span className={`font-mono text-sm ${getPerformanceColor(trade.pnl)}`}>
                        {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}