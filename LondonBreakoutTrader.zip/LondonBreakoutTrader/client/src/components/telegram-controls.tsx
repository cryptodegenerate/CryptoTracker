import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function TelegramControls() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [lastTestTime, setLastTestTime] = useState<Date | null>(null);

  const testTelegramMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/test-telegram");
      return response.json();
    },
    onSuccess: () => {
      setLastTestTime(new Date());
      toast({
        title: "Test Sent",
        description: "Check your Telegram channel for the test message",
      });
    },
    onError: () => {
      toast({
        title: "Test Failed",
        description: "Failed to send test notification. Check your Telegram settings.",
        variant: "destructive",
      });
    },
  });

  const sendDailyReportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/daily-report");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Daily Report Sent",
        description: "Performance report sent to Telegram channel",
      });
    },
    onError: () => {
      toast({
        title: "Report Failed",
        description: "Failed to send daily report",
        variant: "destructive",
      });
    },
  });

  const startAutoTradeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auto-trade/start");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-settings'] });
      toast({
        title: "Auto-Trading Started",
        description: "Bot will now automatically execute trades on confirmed breakouts",
      });
    },
    onError: () => {
      toast({
        title: "Failed to Start",
        description: "Could not enable auto-trading",
        variant: "destructive",
      });
    },
  });

  const stopAutoTradeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auto-trade/stop");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-settings'] });
      toast({
        title: "Auto-Trading Stopped",
        description: "Bot is now in manual mode",
      });
    },
    onError: () => {
      toast({
        title: "Failed to Stop",
        description: "Could not disable auto-trading",
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,25.9%)]">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fab fa-telegram text-[hsl(207,90%,54%)]"></i>
          <span>Telegram Controls</span>
          <Badge variant="outline" className="bg-[hsl(142,71%,45%)]/20 text-[hsl(142,71%,45%)] border-[hsl(142,71%,45%)]/30">
            Connected
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Connection Status */}
        <div className="bg-[hsl(240,10%,3.9%)] rounded-lg p-3 border border-[hsl(240,3.7%,25.9%)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-[hsl(142,71%,45%)] rounded-full animate-pulse"></div>
              <span className="text-sm text-[hsl(0,0%,88%)]">Telegram Bot Active</span>
            </div>
            <span className="text-xs text-[hsl(0,0%,62%)]">Ready to send alerts</span>
          </div>
        </div>

        {/* Test Notification */}
        <div className="space-y-2">
          <Button
            className="w-full bg-[hsl(207,90%,54%)] hover:bg-[hsl(207,90%,44%)] text-white"
            onClick={() => testTelegramMutation.mutate()}
            disabled={testTelegramMutation.isPending}
          >
            {testTelegramMutation.isPending ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>Sending...
              </>
            ) : (
              <>
                <i className="fas fa-paper-plane mr-2"></i>Send Test Message
              </>
            )}
          </Button>
          {lastTestTime && (
            <div className="text-xs text-[hsl(0,0%,62%)] text-center">
              Last test: {lastTestTime.toLocaleTimeString()}
            </div>
          )}
        </div>

        {/* Daily Report */}
        <Button
          variant="outline"
          className="w-full bg-[hsl(240,3.7%,25.9%)] hover:bg-[hsl(240,3.7%,35.9%)] text-white border-[hsl(240,3.7%,35.9%)]"
          onClick={() => sendDailyReportMutation.mutate()}
          disabled={sendDailyReportMutation.isPending}
        >
          {sendDailyReportMutation.isPending ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>Generating...
            </>
          ) : (
            <>
              <i className="fas fa-chart-line mr-2"></i>Send Daily Report
            </>
          )}
        </Button>

        {/* Auto-Trading Controls */}
        <div className="border-t border-[hsl(240,3.7%,25.9%)] pt-4">
          <h4 className="text-sm font-semibold mb-3 text-[hsl(0,0%,88%)]">Auto-Trading Controls</h4>
          <div className="grid grid-cols-2 gap-2">
            <Button
              className="bg-[hsl(142,71%,45%)] hover:bg-[hsl(142,71%,35%)] text-white"
              onClick={() => startAutoTradeMutation.mutate()}
              disabled={startAutoTradeMutation.isPending}
            >
              {startAutoTradeMutation.isPending ? (
                <i className="fas fa-spinner fa-spin"></i>
              ) : (
                <>
                  <i className="fas fa-play mr-1"></i>Start
                </>
              )}
            </Button>
            <Button
              variant="outline"
              className="bg-[hsl(0,84%,60%)] hover:bg-[hsl(0,84%,50%)] text-white border-[hsl(0,84%,60%)]"
              onClick={() => stopAutoTradeMutation.mutate()}
              disabled={stopAutoTradeMutation.isPending}
            >
              {stopAutoTradeMutation.isPending ? (
                <i className="fas fa-spinner fa-spin"></i>
              ) : (
                <>
                  <i className="fas fa-stop mr-1"></i>Stop
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Alert Types */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-[hsl(0,0%,88%)]">Alert Types</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center space-x-2">
              <i className="fas fa-exclamation-triangle text-[hsl(33,95%,54%)]"></i>
              <span className="text-[hsl(0,0%,62%)]">Breakouts</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="fas fa-chart-line text-[hsl(142,71%,45%)]"></i>
              <span className="text-[hsl(0,0%,62%)]">Positions</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="fas fa-clock text-[hsl(207,90%,54%)]"></i>
              <span className="text-[hsl(0,0%,62%)]">Session Events</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="fas fa-chart-bar text-[hsl(33,95%,54%)]"></i>
              <span className="text-[hsl(0,0%,62%)]">Daily Reports</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}