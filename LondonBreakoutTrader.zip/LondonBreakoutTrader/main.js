#!/usr/bin/env node

/**
 * London Breakout Trading Bot
 * Optimized for Linux VPS deployment
 */

import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs/promises';
import dotenv from 'dotenv';
import { createWriteStream } from 'fs';
import { format } from 'date-fns';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configuration
const CONFIG = {
  port: process.env.PORT || 3000,
  isTestMode: process.argv.includes('--test'),
  isLiveMode: process.argv.includes('--live'),
  logLevel: process.env.LOG_LEVEL || 'info',
  
  // London Breakout Strategy Settings
  strategy: {
    // Time windows (UK time - UTC+1 in summer, UTC+0 in winter)
    rangeStartHour: 5,    // 5:00 AM UK time - range setup start
    rangeEndHour: 7,      // 7:00 AM UK time - range setup end
    tradeStartHour: 7,    // 7:00 AM UK time - trading window start
    tradeEndHour: 10,     // 10:00 AM UK time - trading window end
    exitHour: 11,         // 11:00 AM UK time - force close trades
    
    // Range filters
    minRangeSize: 15,     // Minimum range size in pips
    maxRangeSize: 50,     // Maximum range size in pips (optional filter)
    
    // Risk management
    maxTradesPerDay: 2,   // Maximum 2 trades per day
    riskPercentage: 1.5,  // Risk per trade as % of capital
    leverage: 5,          // Trading leverage
    
    // Take profit multiplier (1.5x to 2x range size)
    tpMultiplier: 1.5,
    
    // RSI filter for confirmation (optional)
    rsiMin: 40,
    rsiMax: 60,
    
    // Breakout confirmation
    minCandleBodyPercent: 50,  // Body must be >50% of total candle
    
    // Instruments
    instruments: ['EUR/USD', 'GBP/USD', 'USD/JPY']
  }
};

// Logging setup
class Logger {
  constructor() {
    this.logFile = join(__dirname, 'bot.log');
    this.tradeFile = join(__dirname, 'trades.csv');
    this.eventFile = join(__dirname, 'events.json');
    this.initializeFiles();
  }

  async initializeFiles() {
    try {
      // Create log file if it doesn't exist
      await fs.access(this.logFile).catch(() => 
        fs.writeFile(this.logFile, `Trading Bot Started - ${new Date().toISOString()}\n`)
      );

      // Create trades CSV with headers if it doesn't exist
      await fs.access(this.tradeFile).catch(() => 
        fs.writeFile(this.tradeFile, 'timestamp,symbol,type,price,size,pnl,reason\n')
      );

      // Create events JSON file if it doesn't exist
      await fs.access(this.eventFile).catch(() => 
        fs.writeFile(this.eventFile, '[]')
      );
    } catch (error) {
      console.error('Failed to initialize log files:', error);
    }
  }

  log(level, message, data = {}) {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ${level.toUpperCase()}: ${message}`;
    
    // Console output
    console.log(logEntry);
    
    // File logging
    this.writeToFile(this.logFile, `${logEntry}\n`);
    
    // Additional data logging for important events
    if (level === 'trade' || level === 'alert') {
      this.logEvent({ timestamp, level, message, ...data });
    }
  }

  async writeToFile(filename, content) {
    try {
      await fs.appendFile(filename, content);
    } catch (error) {
      console.error(`Failed to write to ${filename}:`, error);
    }
  }

  async logTrade(trade) {
    const csvLine = `${new Date().toISOString()},${trade.symbol},${trade.type},${trade.price},${trade.size},${trade.pnl || 0},${trade.reason || 'manual'}\n`;
    await this.writeToFile(this.tradeFile, csvLine);
  }

  async logEvent(event) {
    try {
      const existingEvents = JSON.parse(await fs.readFile(this.eventFile, 'utf8'));
      existingEvents.push(event);
      
      // Keep only last 1000 events
      if (existingEvents.length > 1000) {
        existingEvents.splice(0, existingEvents.length - 1000);
      }
      
      await fs.writeFile(this.eventFile, JSON.stringify(existingEvents, null, 2));
    } catch (error) {
      console.error('Failed to log event:', error);
    }
  }
}

// London Breakout Strategy Engine
class LondonBreakoutStrategy {
  constructor(logger) {
    this.logger = logger;
    this.ranges = new Map(); // Store daily ranges for each pair
    this.tradesCount = new Map(); // Track daily trade count per pair
    this.lastRangeCalculation = null;
    this.dailyResetTime = null;
  }

  // Convert to UK time (handles DST automatically)
  getUKTime() {
    const now = new Date();
    // London timezone handling (UTC+0 in winter, UTC+1 in summer)
    const ukTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/London"}));
    return ukTime;
  }

  // Check if we're in the range setup period (5-7 AM UK time)
  isRangeSetupTime() {
    const ukTime = this.getUKTime();
    const hour = ukTime.getHours();
    return hour >= CONFIG.strategy.rangeStartHour && hour < CONFIG.strategy.rangeEndHour;
  }

  // Check if we're in the trading window (7-10 AM UK time)
  isTradingTime() {
    const ukTime = this.getUKTime();
    const hour = ukTime.getHours();
    return hour >= CONFIG.strategy.tradeStartHour && hour < CONFIG.strategy.tradeEndHour;
  }

  // Check if we should force close trades (after 11 AM UK time)
  isForceExitTime() {
    const ukTime = this.getUKTime();
    const hour = ukTime.getHours();
    return hour >= CONFIG.strategy.exitHour;
  }

  // Calculate range for a currency pair during 5-7 AM period
  calculateRange(symbol, priceHistory) {
    const ukTime = this.getUKTime();
    const today = ukTime.toDateString();
    
    // Filter price history for 5-7 AM UK time period
    const rangeCandles = priceHistory.filter(candle => {
      const candleTime = new Date(candle.time * 1000);
      const candleUK = new Date(candleTime.toLocaleString("en-US", {timeZone: "Europe/London"}));
      const hour = candleUK.getHours();
      const candleDate = candleUK.toDateString();
      
      return candleDate === today && 
             hour >= CONFIG.strategy.rangeStartHour && 
             hour < CONFIG.strategy.rangeEndHour;
    });

    if (rangeCandles.length === 0) {
      return null; // No data for range calculation
    }

    const highs = rangeCandles.map(c => c.high);
    const lows = rangeCandles.map(c => c.low);
    
    const rangeHigh = Math.max(...highs);
    const rangeLow = Math.min(...lows);
    const rangeSize = rangeHigh - rangeLow;
    
    // Convert range size to pips
    const pipValue = symbol.includes('JPY') ? 0.01 : 0.0001;
    const rangeSizeInPips = rangeSize / pipValue;

    const range = {
      symbol,
      date: today,
      high: rangeHigh,
      low: rangeLow,
      size: rangeSize,
      sizeInPips: rangeSizeInPips,
      isValid: this.validateRange(rangeSizeInPips),
      calculatedAt: new Date().toISOString()
    };

    this.ranges.set(symbol, range);
    
    this.logger.log('info', `Range calculated for ${symbol}`, {
      high: rangeHigh,
      low: rangeLow,
      sizeInPips: rangeSizeInPips.toFixed(1),
      isValid: range.isValid
    });

    return range;
  }

  // Validate if range meets trading criteria
  validateRange(rangeSizeInPips) {
    if (rangeSizeInPips < CONFIG.strategy.minRangeSize) {
      return false; // Range too small
    }
    
    if (CONFIG.strategy.maxRangeSize && rangeSizeInPips > CONFIG.strategy.maxRangeSize) {
      return false; // Range too large (overextended)
    }
    
    return true;
  }

  // Check for breakout and validate entry conditions
  checkBreakout(symbol, currentPrice, currentCandle, rsi = null) {
    const range = this.ranges.get(symbol);
    if (!range || !range.isValid) {
      return null; // No valid range available
    }

    // Check daily trade limit
    const todayTrades = this.tradesCount.get(symbol) || 0;
    if (todayTrades >= CONFIG.strategy.maxTradesPerDay) {
      return null; // Max trades reached for today
    }

    let breakoutType = null;
    let stopLoss = null;
    let takeProfit = null;

    // Check for upward breakout
    if (currentPrice > range.high && currentCandle.close > range.high) {
      // Validate candle body percentage
      const candleSize = currentCandle.high - currentCandle.low;
      const bodySize = Math.abs(currentCandle.close - currentCandle.open);
      const bodyPercent = (bodySize / candleSize) * 100;

      if (bodyPercent >= CONFIG.strategy.minCandleBodyPercent) {
        // RSI filter (optional)
        if (rsi && (rsi < CONFIG.strategy.rsiMin || rsi > CONFIG.strategy.rsiMax)) {
          this.logger.log('info', `RSI filter blocked ${symbol} BUY signal`, { rsi });
          return null;
        }

        breakoutType = 'BUY';
        stopLoss = range.low; // SL at opposite end of range
        takeProfit = currentPrice + (range.size * CONFIG.strategy.tpMultiplier);
      }
    }
    // Check for downward breakout
    else if (currentPrice < range.low && currentCandle.close < range.low) {
      // Validate candle body percentage
      const candleSize = currentCandle.high - currentCandle.low;
      const bodySize = Math.abs(currentCandle.close - currentCandle.open);
      const bodyPercent = (bodySize / candleSize) * 100;

      if (bodyPercent >= CONFIG.strategy.minCandleBodyPercent) {
        // RSI filter (optional)
        if (rsi && (rsi < CONFIG.strategy.rsiMin || rsi > CONFIG.strategy.rsiMax)) {
          this.logger.log('info', `RSI filter blocked ${symbol} SELL signal`, { rsi });
          return null;
        }

        breakoutType = 'SELL';
        stopLoss = range.high; // SL at opposite end of range
        takeProfit = currentPrice - (range.size * CONFIG.strategy.tpMultiplier);
      }
    }

    if (breakoutType) {
      return {
        symbol,
        type: breakoutType,
        entryPrice: currentPrice,
        stopLoss,
        takeProfit,
        range,
        confidence: this.calculateConfidence(range, currentCandle, rsi),
        timestamp: new Date().toISOString()
      };
    }

    return null;
  }

  // Calculate breakout confidence score
  calculateConfidence(range, candle, rsi) {
    let confidence = 70; // Base confidence

    // Range size factor
    if (range.sizeInPips >= 20 && range.sizeInPips <= 35) {
      confidence += 15; // Optimal range size
    }

    // Candle strength factor
    const candleSize = candle.high - candle.low;
    const bodySize = Math.abs(candle.close - candle.open);
    const bodyPercent = (bodySize / candleSize) * 100;
    
    if (bodyPercent >= 70) {
      confidence += 15; // Strong breakout candle
    } else if (bodyPercent >= 60) {
      confidence += 10;
    }

    // RSI factor (if available)
    if (rsi && rsi >= 45 && rsi <= 55) {
      confidence += 10; // Neutral RSI
    }

    return Math.min(confidence, 100);
  }

  // Reset daily counters
  resetDailyCounters() {
    const ukTime = this.getUKTime();
    const today = ukTime.toDateString();
    
    if (this.dailyResetTime !== today) {
      this.tradesCount.clear();
      this.ranges.clear();
      this.dailyResetTime = today;
      this.logger.log('info', 'Daily counters reset for new trading day');
    }
  }

  // Increment trade count for symbol
  incrementTradeCount(symbol) {
    const current = this.tradesCount.get(symbol) || 0;
    this.tradesCount.set(symbol, current + 1);
  }
}

// Trading Bot Core
class TradingBot {
  constructor(logger) {
    this.logger = logger;
    this.isRunning = false;
    this.priceUpdateInterval = null;
    this.strategy = new LondonBreakoutStrategy(logger);
    this.setupGracefulShutdown();
  }

  async start() {
    this.logger.log('info', 'Starting London Breakout Trading Bot', {
      mode: CONFIG.isTestMode ? 'TEST' : CONFIG.isLiveMode ? 'LIVE' : 'SIMULATION',
      port: CONFIG.port
    });

    try {
      // Initialize services
      await this.initializeServices();
      
      // Start price monitoring
      this.startPriceMonitoring();
      
      // Start web server
      await this.startWebServer();
      
      this.isRunning = true;
      this.logger.log('info', 'Trading bot started successfully');
      
    } catch (error) {
      this.logger.log('error', 'Failed to start trading bot', { error: error.message });
      throw error;
    }
  }

  async initializeServices() {
    // Validate required environment variables
    const required = ['TELEGRAM_BOT_TOKEN', 'TELEGRAM_CHAT_ID'];
    const missing = required.filter(key => !process.env[key]);
    
    if (missing.length > 0) {
      throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
    }

    this.logger.log('info', 'Environment variables validated');
    
    // Initialize currency pairs with historical data structure
    this.currencyPairs = CONFIG.strategy.instruments.map(symbol => ({
      symbol,
      currentPrice: this.getInitialPrice(symbol),
      priceHistory: this.generateInitialHistory(symbol),
      range: null,
      lastCandle: null
    }));
    
    this.trades = [];
    this.alerts = [];
    this.sessionInfo = this.getSessionInfo();
    
    this.logger.log('info', `Initialized ${this.currencyPairs.length} currency pairs for London Breakout strategy`);
  }

  getInitialPrice(symbol) {
    const prices = {
      'EUR/USD': 1.0850,
      'GBP/USD': 1.2650,
      'USD/JPY': 149.50
    };
    return prices[symbol] || 1.0000;
  }

  generateInitialHistory(symbol) {
    const history = [];
    const basePrice = this.getInitialPrice(symbol);
    const now = Date.now();
    
    // Generate 24 hours of 5-minute candles
    for (let i = 288; i >= 0; i--) {
      const time = Math.floor((now - (i * 5 * 60 * 1000)) / 1000);
      const volatility = symbol.includes('JPY') ? 0.5 : 0.0005;
      const change = (Math.random() - 0.5) * volatility;
      
      const open = basePrice + change;
      const close = open + (Math.random() - 0.5) * volatility;
      const high = Math.max(open, close) + Math.random() * volatility * 0.5;
      const low = Math.min(open, close) - Math.random() * volatility * 0.5;
      
      history.push({ time, open, high, low, close, volume: Math.floor(Math.random() * 1000) + 100 });
    }
    
    return history;
  }

  getSessionInfo() {
    const ukTime = this.strategy.getUKTime();
    return {
      currentUKTime: ukTime.toISOString(),
      isRangeSetup: this.strategy.isRangeSetupTime(),
      isTrading: this.strategy.isTradingTime(),
      isForceExit: this.strategy.isForceExitTime(),
      hour: ukTime.getHours()
    };
  }

  startPriceMonitoring() {
    this.priceUpdateInterval = setInterval(async () => {
      try {
        await this.updatePricesAndCheckBreakouts();
      } catch (error) {
        this.logger.log('error', 'Price update failed', { error: error.message });
      }
    }, 2000); // Update every 2 seconds

    this.logger.log('info', 'Price monitoring started');
  }

  async updatePricesAndCheckBreakouts() {
    // Reset daily counters if needed
    this.strategy.resetDailyCounters();
    this.sessionInfo = this.getSessionInfo();

    for (const pair of this.currencyPairs) {
      // Update price and create new candle
      await this.updatePairPrice(pair);
      
      // Calculate range during setup period (5-7 AM UK)
      if (this.strategy.isRangeSetupTime()) {
        const range = this.strategy.calculateRange(pair.symbol, pair.priceHistory);
        if (range) {
          pair.range = range;
        }
      }
      
      // Check for breakouts during trading window (7-10 AM UK)
      if (this.strategy.isTradingTime() && pair.range && pair.lastCandle) {
        const breakout = this.strategy.checkBreakout(
          pair.symbol, 
          pair.currentPrice, 
          pair.lastCandle,
          this.calculateRSI(pair.priceHistory) // Simple RSI calculation
        );
        
        if (breakout) {
          await this.handleLondonBreakout(breakout);
        }
      }

      // Force close trades if past exit time (11 AM UK)
      if (this.strategy.isForceExitTime()) {
        await this.forceCloseTrades(pair.symbol);
      }
    }
  }

  async updatePairPrice(pair) {
    // Simulate realistic price movement with candle structure
    const volatility = pair.symbol.includes('JPY') ? 0.5 : 0.0005;
    const change = (Math.random() - 0.5) * 2 * volatility;
    
    const newPrice = pair.currentPrice + change;
    pair.currentPrice = newPrice;
    
    // Create new 5-minute candle
    const now = Math.floor(Date.now() / 1000);
    const lastCandle = pair.priceHistory[pair.priceHistory.length - 1];
    
    // Check if we need a new candle (every 5 minutes)
    if (!lastCandle || now - lastCandle.time >= 300) {
      const open = lastCandle ? lastCandle.close : newPrice;
      const close = newPrice;
      const high = Math.max(open, close) + Math.random() * volatility * 0.3;
      const low = Math.min(open, close) - Math.random() * volatility * 0.3;
      
      const newCandle = { time: now, open, high, low, close, volume: Math.floor(Math.random() * 1000) + 100 };
      
      pair.priceHistory.push(newCandle);
      pair.lastCandle = newCandle;
      
      // Keep only last 24 hours of data (288 candles)
      if (pair.priceHistory.length > 288) {
        pair.priceHistory = pair.priceHistory.slice(-288);
      }
    } else {
      // Update current candle
      pair.priceHistory[pair.priceHistory.length - 1].close = newPrice;
      pair.priceHistory[pair.priceHistory.length - 1].high = Math.max(
        pair.priceHistory[pair.priceHistory.length - 1].high, 
        newPrice
      );
      pair.priceHistory[pair.priceHistory.length - 1].low = Math.min(
        pair.priceHistory[pair.priceHistory.length - 1].low, 
        newPrice
      );
      pair.lastCandle = pair.priceHistory[pair.priceHistory.length - 1];
    }
  }

  calculateRSI(priceHistory, period = 14) {
    if (priceHistory.length < period + 1) return 50; // Neutral RSI if not enough data
    
    const prices = priceHistory.slice(-period - 1).map(c => c.close);
    let gains = 0, losses = 0;
    
    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      if (change > 0) gains += change;
      else losses += Math.abs(change);
    }
    
    const avgGain = gains / period;
    const avgLoss = losses / period;
    
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  async handleLondonBreakout(breakout) {
    // Create trade entry
    const trade = {
      id: Date.now(),
      symbol: breakout.symbol,
      type: breakout.type,
      entryPrice: breakout.entryPrice,
      stopLoss: breakout.stopLoss,
      takeProfit: breakout.takeProfit,
      size: this.calculatePositionSize(breakout),
      confidence: breakout.confidence,
      timestamp: breakout.timestamp,
      status: 'OPEN',
      pnl: 0,
      range: breakout.range
    };

    // Add to trades
    this.trades.unshift(trade);
    
    // Increment trade count
    this.strategy.incrementTradeCount(breakout.symbol);
    
    // Log trade
    await this.logger.logTrade(trade);

    const message = `🚀 LONDON BREAKOUT - ${breakout.symbol} ${breakout.type}!\n` +
                   `Entry: ${breakout.entryPrice.toFixed(4)}\n` +
                   `Stop Loss: ${breakout.stopLoss.toFixed(4)}\n` +
                   `Take Profit: ${breakout.takeProfit.toFixed(4)}\n` +
                   `Range: ${breakout.range.sizeInPips.toFixed(1)} pips\n` +
                   `Confidence: ${breakout.confidence}%`;

    this.logger.log('trade', `London Breakout trade executed: ${breakout.symbol} ${breakout.type}`, trade);

    // Send Telegram alert
    await this.sendTelegramAlert(message);
    
    // Add alert
    this.alerts.unshift({
      id: Date.now(),
      type: 'TRADE_OPEN',
      message: `${breakout.symbol} ${breakout.type} trade opened at ${breakout.entryPrice.toFixed(4)}`,
      timestamp: new Date(),
      symbol: breakout.symbol,
      confidence: breakout.confidence
    });

    // Keep only last 100 alerts
    if (this.alerts.length > 100) {
      this.alerts = this.alerts.slice(0, 100);
    }
  }

  calculatePositionSize(breakout) {
    // Calculate position size based on risk percentage
    const accountBalance = 10000; // Simulated account balance
    const riskAmount = accountBalance * (CONFIG.strategy.riskPercentage / 100);
    const stopLossDistance = Math.abs(breakout.entryPrice - breakout.stopLoss);
    const pipValue = breakout.symbol.includes('JPY') ? 0.01 : 0.0001;
    const stopLossInPips = stopLossDistance / pipValue;
    
    // Position size calculation: Risk Amount / (Stop Loss in Pips * Pip Value)
    const positionSize = riskAmount / (stopLossInPips * pipValue * 10); // 10 = lot size multiplier
    
    return Math.max(0.01, Math.round(positionSize * 100) / 100); // Minimum 0.01 lots
  }

  async forceCloseTrades(symbol) {
    const openTrades = this.trades.filter(t => t.symbol === symbol && t.status === 'OPEN');
    
    for (const trade of openTrades) {
      const pair = this.currencyPairs.find(p => p.symbol === symbol);
      const exitPrice = pair.currentPrice;
      
      // Calculate P&L
      const pnl = this.calculateTradePnL(trade, exitPrice);
      trade.pnl = pnl;
      trade.status = 'CLOSED';
      trade.exitPrice = exitPrice;
      trade.exitReason = 'TIME_EXIT';
      trade.exitTime = new Date().toISOString();

      await this.logger.logTrade({
        ...trade,
        reason: 'time_exit'
      });

      const message = `⏰ TRADE CLOSED (Time Exit) - ${symbol}\n` +
                     `Exit: ${exitPrice.toFixed(4)}\n` +
                     `P&L: ${pnl > 0 ? '+' : ''}${pnl.toFixed(2)} USD`;

      this.logger.log('trade', `Trade force closed due to time: ${symbol}`, { pnl, exitPrice });
      await this.sendTelegramAlert(message);
    }
  }

  calculateTradePnL(trade, exitPrice) {
    const direction = trade.type === 'BUY' ? 1 : -1;
    const priceChange = (exitPrice - trade.entryPrice) * direction;
    const pipValue = trade.symbol.includes('JPY') ? 0.01 : 0.0001;
    const pipsGained = priceChange / pipValue;
    
    // P&L = Pips Gained * Position Size * Pip Worth (simplified)
    return pipsGained * trade.size * 10; // $10 per pip per lot (simplified)
  }

  async handleBreakout(pair, direction) {
    // Legacy handler - keeping for compatibility
    const confidence = Math.random() * 40 + 60;
    const message = `${pair.symbol} ${direction} breakout detected! Price: ${pair.currentPrice.toFixed(4)} (Confidence: ${confidence.toFixed(1)}%)`;
    
    this.logger.log('alert', message, {
      symbol: pair.symbol,
      direction,
      price: pair.currentPrice,
      confidence
    });

    await this.sendTelegramAlert(message);
    
    this.alerts.unshift({
      id: Date.now(),
      type: 'BREAKOUT',
      message,
      timestamp: new Date(),
      symbol: pair.symbol
    });

    if (this.alerts.length > 100) {
      this.alerts = this.alerts.slice(0, 100);
    }
  }

  async sendTelegramAlert(message) {
    try {
      const response = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: process.env.TELEGRAM_CHAT_ID,
          text: `🤖 BREAKOUT ALERT\n\n${message}`,
          parse_mode: 'Markdown'
        })
      });

      if (response.ok) {
        this.logger.log('info', 'Telegram alert sent successfully');
      } else {
        this.logger.log('error', 'Failed to send Telegram alert', { status: response.status });
      }
    } catch (error) {
      this.logger.log('error', 'Telegram alert error', { error: error.message });
    }
  }

  async startWebServer() {
    const app = express();
    
    app.use(express.json());
    
    // Health check endpoint
    app.get('/health', (req, res) => {
      res.json({
        status: 'running',
        uptime: process.uptime(),
        mode: CONFIG.isTestMode ? 'TEST' : CONFIG.isLiveMode ? 'LIVE' : 'SIMULATION',
        timestamp: new Date().toISOString()
      });
    });

    // API endpoints
    app.get('/api/status', (req, res) => {
      res.json({
        isRunning: this.isRunning,
        currencyPairs: this.currencyPairs,
        tradesCount: this.trades.length,
        alertsCount: this.alerts.length
      });
    });

    app.get('/api/alerts', (req, res) => {
      res.json(this.alerts.slice(0, 10)); // Last 10 alerts
    });

    app.get('/api/trades', (req, res) => {
      res.json(this.trades.slice(0, 10)); // Last 10 trades
    });

    // Start server
    return new Promise((resolve, reject) => {
      const server = app.listen(CONFIG.port, '0.0.0.0', (error) => {
        if (error) {
          reject(error);
        } else {
          this.logger.log('info', `Web server listening on port ${CONFIG.port}`);
          resolve(server);
        }
      });
    });
  }

  setupGracefulShutdown() {
    const shutdown = async (signal) => {
      this.logger.log('info', `Received ${signal}, shutting down gracefully`);
      
      if (this.priceUpdateInterval) {
        clearInterval(this.priceUpdateInterval);
      }
      
      this.isRunning = false;
      this.logger.log('info', 'Trading bot stopped');
      process.exit(0);
    };

    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
  }
}

// Main execution with error handling and restart logic
async function main() {
  const logger = new Logger();
  
  const startBot = async () => {
    try {
      const bot = new TradingBot(logger);
      await bot.start();
    } catch (error) {
      logger.log('error', 'Bot crashed, restarting in 5 seconds', { error: error.message });
      
      // Restart after 5 seconds
      setTimeout(startBot, 5000);
    }
  };

  logger.log('info', 'Initializing trading bot');
  await startBot();
}

// Start the application
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export default main;