# Trading Bot Dashboard Application

## Overview

This is a comprehensive forex trading bot dashboard application built with a modern full-stack architecture. The application provides real-time monitoring of currency pairs, automated trading capabilities, risk management tools, and performance analytics for the London Breakout trading strategy.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom trading-specific color scheme
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: NeonDB serverless PostgreSQL
- **Session Management**: express-session with PostgreSQL store
- **Development**: Hot module replacement via Vite integration

### Database Architecture
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Migration**: Drizzle Kit for schema management
- **Connection**: NeonDB serverless with connection pooling

## Key Components

### Data Models
- **Currency Pairs**: EUR/USD, GBP/USD, USD/JPY with real-time pricing and breakout levels
- **Trades**: Position tracking with entry/exit prices, P&L calculation, and status management
- **Bot Settings**: Risk management parameters, leverage, daily trade limits, and notification preferences
- **Alerts**: System notifications for breakouts, position changes, and session events

### Trading Engine
- **Strategy**: London Breakout pattern recognition
- **Risk Management**: Configurable risk percentage per trade (default 1.5%)
- **Position Sizing**: Automatic calculation based on account balance and risk parameters
- **Stop Loss/Take Profit**: Automated risk controls for each position

### Real-time Features
- **Price Simulation**: Mock price updates every 2 seconds for development
- **Live Data Polling**: TanStack Query with configurable refresh intervals
- **Session Monitoring**: London trading session status and time remaining
- **Alert System**: Real-time notifications for trading events

## Data Flow

1. **Price Data**: Simulated price updates flow from backend storage to frontend via REST API
2. **Trade Execution**: Frontend initiates trades → Backend validates → Database persistence → Real-time UI updates
3. **Risk Calculations**: Position sizing and P&L calculations performed server-side with client-side display
4. **Settings Management**: Bot configuration changes persist to database with immediate UI reflection

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **typescript**: Static type checking
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for server development
- **esbuild**: Production bundling for server code

## Deployment Strategy

### Development Mode
- Vite dev server for frontend with HMR
- tsx for server execution with automatic restarts
- In-memory storage fallback for development without database

### Production Build
- Frontend: Vite production build to `dist/public`
- Backend: esbuild bundle to `dist/index.js`
- Database: Drizzle migrations applied via `db:push`

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment flag for development/production behavior
- Replit-specific configurations for cloud deployment

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- July 02, 2025: Complete VPS Deployment Package Created
  - Production-ready `main.js` with headless operation capabilities
  - Automated `start.sh` script with dependency installation and environment validation
  - Complete documentation suite (README.md, DEPLOYMENT.md, VPS-PACKAGE.md)
  - Environment-based configuration system with `.env.example` template
  - File-based logging system (bot.log, trades.csv, events.json)
  - Auto-restart functionality and graceful shutdown handling
  - Web API endpoints for monitoring (/health, /api/status, /api/alerts)
  - Systemd service integration for production deployment
  - Support for --test, --live, and simulation modes
  - Minimal dependencies (express, dotenv, date-fns) for lightweight deployment

- July 02, 2025: Enhanced trading bot with advanced features
  - Advanced charting with technical indicators (RSI, MACD, Bollinger Bands, moving averages)
  - Real-time breakout detection with confidence scoring and technical analysis
  - Complete backtesting system for strategy performance analysis
  - Telegram integration fully configured with bot "BreakoutCheif" (token: 7871890240:AAENcoHCVanUMANwOjfJCCnNtBDA-QGREp8)
  - Automated trading controls with start/stop functionality
  - Enhanced risk management with technical analysis integration
  - Tabbed dashboard interface (Overview, Analysis, Backtest, Automation)
  - Real-time price simulation with breakout alerts being sent to Telegram

- July 01, 2025: Complete London Breakout trading bot dashboard implemented
  - Real-time currency pair monitoring (EUR/USD, GBP/USD, USD/JPY)
  - Interactive price charts with breakout zones visualization
  - Risk management system with position sizing calculations
  - Active positions tracking with live P&L updates
  - Performance analytics and trading alerts system
  - Price simulation engine running every 2 seconds
  - Professional dark trading interface with live session monitoring

## Changelog

- July 01, 2025: Initial setup and complete trading dashboard implementation