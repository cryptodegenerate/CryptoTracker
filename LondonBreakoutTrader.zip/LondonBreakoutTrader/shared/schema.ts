import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const currencyPairs = pgTable("currency_pairs", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(), // EUR/USD, GBP/USD, USD/JPY
  name: text("name").notNull(),
  currentPrice: decimal("current_price", { precision: 10, scale: 5 }).notNull(),
  change: decimal("change", { precision: 10, scale: 5 }).notNull(),
  changePercent: decimal("change_percent", { precision: 5, scale: 2 }).notNull(),
  overnightRangeLow: decimal("overnight_range_low", { precision: 10, scale: 5 }).notNull(),
  overnightRangeHigh: decimal("overnight_range_high", { precision: 10, scale: 5 }).notNull(),
  upperBreakout: decimal("upper_breakout", { precision: 10, scale: 5 }).notNull(),
  lowerBreakout: decimal("lower_breakout", { precision: 10, scale: 5 }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  type: text("type").notNull(), // LONG, SHORT
  size: decimal("size", { precision: 10, scale: 3 }).notNull(), // lot size
  entryPrice: decimal("entry_price", { precision: 10, scale: 5 }).notNull(),
  exitPrice: decimal("exit_price", { precision: 10, scale: 5 }),
  stopLoss: decimal("stop_loss", { precision: 10, scale: 5 }).notNull(),
  takeProfit: decimal("take_profit", { precision: 10, scale: 5 }).notNull(),
  pnl: decimal("pnl", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("OPEN"), // OPEN, CLOSED
  openedAt: timestamp("opened_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
});

export const botSettings = pgTable("bot_settings", {
  id: serial("id").primaryKey(),
  riskPercentage: decimal("risk_percentage", { precision: 3, scale: 1 }).notNull().default("1.5"),
  leverage: integer("leverage").notNull().default(10),
  maxTradesPerDay: integer("max_trades_per_day").notNull().default(2),
  tradesUsedToday: integer("trades_used_today").notNull().default(0),
  autoTradingEnabled: boolean("auto_trading_enabled").notNull().default(true),
  soundAlertsEnabled: boolean("sound_alerts_enabled").notNull().default(true),
  emailNotificationsEnabled: boolean("email_notifications_enabled").notNull().default(false),
  accountBalance: decimal("account_balance", { precision: 12, scale: 2 }).notNull().default("25000.00"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // BREAKOUT, POSITION_OPENED, POSITION_CLOSED, SESSION_STARTED
  message: text("message").notNull(),
  symbol: text("symbol"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCurrencyPairSchema = createInsertSchema(currencyPairs);
export const insertTradeSchema = createInsertSchema(trades);
export const insertBotSettingsSchema = createInsertSchema(botSettings);
export const insertAlertSchema = createInsertSchema(alerts);

export type CurrencyPair = typeof currencyPairs.$inferSelect;
export type Trade = typeof trades.$inferSelect;
export type BotSettings = typeof botSettings.$inferSelect;
export type Alert = typeof alerts.$inferSelect;

export type InsertCurrencyPair = z.infer<typeof insertCurrencyPairSchema>;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type InsertBotSettings = z.infer<typeof insertBotSettingsSchema>;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
