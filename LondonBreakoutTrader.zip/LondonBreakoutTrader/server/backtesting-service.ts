import { technicalAnalysis, PriceData } from './technical-indicators';

export interface BacktestResult {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalPnL: number;
  averageWin: number;
  averageLoss: number;
  maxDrawdown: number;
  sharpeRatio: number;
  profitFactor: number;
  trades: BacktestTrade[];
}

export interface BacktestTrade {
  symbol: string;
  entryTime: number;
  exitTime: number;
  entryPrice: number;
  exitPrice: number;
  type: 'LONG' | 'SHORT';
  pnl: number;
  duration: number; // in minutes
  exitReason: 'STOP_LOSS' | 'TAKE_PROFIT' | 'TIME_EXIT';
}

export interface BacktestSettings {
  riskPercentage: number;
  leverage: number;
  maxTradesPerDay: number;
  stopLossPoints: number;
  takeProfitPoints: number;
  sessionStartHour: number; // London time
  sessionEndHour: number;
  timeframe: number; // minutes
}

export class BacktestingService {
  private defaultSettings: BacktestSettings = {
    riskPercentage: 1.5,
    leverage: 10,
    maxTradesPerDay: 2,
    stopLossPoints: 15, // pips
    takeProfitPoints: 30, // pips
    sessionStartHour: 7,
    sessionEndHour: 10,
    timeframe: 5
  };

  generateHistoricalData(symbol: string, days: number = 30): PriceData[] {
    const data: PriceData[] = [];
    const now = Date.now();
    const intervals = days * 24 * 12; // 5-minute intervals
    
    let basePrice = symbol === 'USD/JPY' ? 149.50 : symbol === 'GBP/USD' ? 1.2620 : 1.0835;
    
    for (let i = intervals; i >= 0; i--) {
      const time = now - (i * 5 * 60 * 1000);
      const date = new Date(time);
      const hour = date.getUTCHours();
      
      // Simulate higher volatility during London session
      const isLondonSession = hour >= 7 && hour < 10;
      const volatilityMultiplier = isLondonSession ? 2 : 1;
      
      const variation = (Math.random() - 0.5) * 0.002 * volatilityMultiplier;
      const open = basePrice;
      const close = basePrice + variation;
      const spread = symbol === 'USD/JPY' ? 0.02 : 0.0002;
      const high = Math.max(open, close) + Math.random() * 0.001 * volatilityMultiplier;
      const low = Math.min(open, close) - Math.random() * 0.001 * volatilityMultiplier;

      data.push({
        time,
        open,
        high,
        low,
        close,
        volume: Math.floor(Math.random() * 1000) + 100
      });

      basePrice = close;
    }

    return data;
  }

  async runBacktest(symbol: string, settings: Partial<BacktestSettings> = {}): Promise<BacktestResult> {
    const config = { ...this.defaultSettings, ...settings };
    const historicalData = this.generateHistoricalData(symbol, 30);
    const trades: BacktestTrade[] = [];
    
    let accountBalance = 25000;
    let dailyTrades = 0;
    let currentDay = -1;
    let openPosition: any = null;
    
    for (let i = 50; i < historicalData.length; i++) {
      const candle = historicalData[i];
      const date = new Date(candle.time);
      const day = date.getUTCDate();
      const hour = date.getUTCHours();
      
      // Reset daily trade count
      if (day !== currentDay) {
        currentDay = day;
        dailyTrades = 0;
      }
      
      // Only trade during London session
      if (hour < config.sessionStartHour || hour >= config.sessionEndHour) {
        continue;
      }
      
      // Update technical analysis with current price
      technicalAnalysis.addPriceData(symbol, candle.close);
      
      // Check for breakout signals if no open position
      if (!openPosition && dailyTrades < config.maxTradesPerDay) {
        const recentCandles = historicalData.slice(Math.max(0, i - 24), i); // Last 2 hours
        const overnightLow = Math.min(...recentCandles.map(c => c.low));
        const overnightHigh = Math.max(...recentCandles.map(c => c.high));
        const range = overnightHigh - overnightLow;
        
        const upperBreakout = overnightHigh + range * 0.1;
        const lowerBreakout = overnightLow - range * 0.1;
        
        const breakoutSignal = technicalAnalysis.detectBreakoutSignal(
          symbol, 
          candle.close, 
          upperBreakout, 
          lowerBreakout
        );
        
        if (breakoutSignal.isBreakout && breakoutSignal.confidence > 70) {
          const pipSize = symbol === 'USD/JPY' ? 0.01 : 0.0001;
          const entryPrice = candle.close;
          
          let stopLoss: number;
          let takeProfit: number;
          let type: 'LONG' | 'SHORT';
          
          if (breakoutSignal.direction === 'UP') {
            type = 'LONG';
            stopLoss = entryPrice - (config.stopLossPoints * pipSize);
            takeProfit = entryPrice + (config.takeProfitPoints * pipSize);
          } else {
            type = 'SHORT';
            stopLoss = entryPrice + (config.stopLossPoints * pipSize);
            takeProfit = entryPrice - (config.takeProfitPoints * pipSize);
          }
          
          openPosition = {
            symbol,
            entryTime: candle.time,
            entryPrice,
            stopLoss,
            takeProfit,
            type,
            size: this.calculatePositionSize(accountBalance, config.riskPercentage, entryPrice, stopLoss)
          };
          
          dailyTrades++;
        }
      }
      
      // Check for position exit
      if (openPosition) {
        let shouldClose = false;
        let exitPrice = candle.close;
        let exitReason: BacktestTrade['exitReason'] = 'TIME_EXIT';
        
        // Check stop loss
        if (openPosition.type === 'LONG' && candle.low <= openPosition.stopLoss) {
          shouldClose = true;
          exitPrice = openPosition.stopLoss;
          exitReason = 'STOP_LOSS';
        } else if (openPosition.type === 'SHORT' && candle.high >= openPosition.stopLoss) {
          shouldClose = true;
          exitPrice = openPosition.stopLoss;
          exitReason = 'STOP_LOSS';
        }
        
        // Check take profit
        if (openPosition.type === 'LONG' && candle.high >= openPosition.takeProfit) {
          shouldClose = true;
          exitPrice = openPosition.takeProfit;
          exitReason = 'TAKE_PROFIT';
        } else if (openPosition.type === 'SHORT' && candle.low <= openPosition.takeProfit) {
          shouldClose = true;
          exitPrice = openPosition.takeProfit;
          exitReason = 'TAKE_PROFIT';
        }
        
        // Force close at session end
        if (hour >= config.sessionEndHour - 0.5) { // 30 minutes before session end
          shouldClose = true;
          exitReason = 'TIME_EXIT';
        }
        
        if (shouldClose) {
          const pnl = this.calculatePnL(
            openPosition.entryPrice,
            exitPrice,
            openPosition.size,
            openPosition.type
          );
          
          accountBalance += pnl;
          
          trades.push({
            symbol: openPosition.symbol,
            entryTime: openPosition.entryTime,
            exitTime: candle.time,
            entryPrice: openPosition.entryPrice,
            exitPrice,
            type: openPosition.type,
            pnl,
            duration: (candle.time - openPosition.entryTime) / (60 * 1000),
            exitReason
          });
          
          openPosition = null;
        }
      }
    }
    
    // Calculate performance metrics
    return this.calculateBacktestMetrics(trades);
  }
  
  private calculatePositionSize(balance: number, riskPercent: number, entryPrice: number, stopLoss: number): number {
    const riskAmount = balance * (riskPercent / 100);
    const pipValue = Math.abs(entryPrice - stopLoss);
    const standardLotValue = 100000;
    
    const positionSize = riskAmount / (pipValue * standardLotValue);
    return Math.min(positionSize, 0.1); // Cap at 0.1 lots
  }
  
  private calculatePnL(entryPrice: number, exitPrice: number, size: number, type: string): number {
    const standardLotValue = 100000;
    const priceDiff = type === 'LONG' ? exitPrice - entryPrice : entryPrice - exitPrice;
    return priceDiff * size * standardLotValue;
  }
  
  private calculateBacktestMetrics(trades: BacktestTrade[]): BacktestResult {
    if (trades.length === 0) {
      return {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        winRate: 0,
        totalPnL: 0,
        averageWin: 0,
        averageLoss: 0,
        maxDrawdown: 0,
        sharpeRatio: 0,
        profitFactor: 0,
        trades: []
      };
    }
    
    const winningTrades = trades.filter(t => t.pnl > 0);
    const losingTrades = trades.filter(t => t.pnl < 0);
    const totalPnL = trades.reduce((sum, t) => sum + t.pnl, 0);
    
    const averageWin = winningTrades.length > 0 
      ? winningTrades.reduce((sum, t) => sum + t.pnl, 0) / winningTrades.length 
      : 0;
    
    const averageLoss = losingTrades.length > 0 
      ? Math.abs(losingTrades.reduce((sum, t) => sum + t.pnl, 0) / losingTrades.length)
      : 0;
    
    // Calculate max drawdown
    let runningBalance = 25000;
    let peak = runningBalance;
    let maxDrawdown = 0;
    
    trades.forEach(trade => {
      runningBalance += trade.pnl;
      if (runningBalance > peak) {
        peak = runningBalance;
      }
      const drawdown = ((peak - runningBalance) / peak) * 100;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
    });
    
    // Calculate Sharpe ratio (simplified)
    const returns = trades.map(t => t.pnl);
    const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / returns.length;
    const stdDev = Math.sqrt(variance);
    const sharpeRatio = stdDev > 0 ? avgReturn / stdDev : 0;
    
    // Calculate profit factor
    const grossProfit = winningTrades.reduce((sum, t) => sum + t.pnl, 0);
    const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + t.pnl, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;
    
    return {
      totalTrades: trades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: (winningTrades.length / trades.length) * 100,
      totalPnL,
      averageWin,
      averageLoss,
      maxDrawdown,
      sharpeRatio,
      profitFactor,
      trades
    };
  }
}

export const backtestingService = new BacktestingService();