export interface OandaPrice {
  instrument: string;
  time: string;
  closeoutBid: string;
  closeoutAsk: string;
}

export interface OandaCandle {
  time: string;
  bid: {
    o: string;
    h: string;
    l: string;
    c: string;
  };
  ask: {
    o: string;
    h: string;
    l: string;
    c: string;
  };
  mid: {
    o: string;
    h: string;
    l: string;
    c: string;
  };
  volume: number;
}

export class OandaService {
  private apiKey: string;
  private accountId: string;
  private baseUrl: string;
  private isDemo: boolean;

  constructor() {
    this.apiKey = process.env.OANDA_API_KEY || '';
    this.accountId = process.env.OANDA_ACCOUNT_ID || '';
    this.isDemo = process.env.OANDA_ENVIRONMENT !== 'live';
    this.baseUrl = this.isDemo 
      ? 'https://api-fxpractice.oanda.com'
      : 'https://api-fxtrade.oanda.com';

    if (this.apiKey && this.accountId) {
      console.log(`OANDA service initialized - ${this.isDemo ? 'Demo' : 'Live'} environment`);
    } else {
      console.log('OANDA credentials not found - using simulation mode');
    }
  }

  async getCurrentPrices(instruments: string[] = ['EUR_USD', 'GBP_USD', 'USD_JPY']): Promise<OandaPrice[]> {
    if (!this.apiKey) {
      throw new Error('OANDA API key not configured');
    }

    try {
      const instrumentsStr = instruments.join(',');
      const url = `${this.baseUrl}/v3/accounts/${this.accountId}/pricing?instruments=${instrumentsStr}`;
      console.log(`Making OANDA API call to: ${url}`);
      console.log(`Account ID: ${this.accountId}, Environment: ${this.isDemo ? 'demo' : 'live'}`);
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`OANDA API Error Details:`, {
          status: response.status,
          statusText: response.statusText,
          url: url,
          errorBody: errorText
        });
        throw new Error(`OANDA API error: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      return data.prices || [];
    } catch (error) {
      // Silently throw error to trigger fallback to simulation
      throw error;
    }
  }

  async getHistoricalCandles(
    instrument: string = 'EUR_USD',
    granularity: string = 'M1',
    count: number = 100
  ): Promise<OandaCandle[]> {
    if (!this.apiKey) {
      throw new Error('OANDA API key not configured');
    }

    try {
      const response = await fetch(
        `${this.baseUrl}/v3/instruments/${instrument}/candles?granularity=${granularity}&count=${count}`,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!response.ok) {
        throw new Error(`OANDA API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      return data.candles || [];
    } catch (error) {
      console.error('Failed to fetch OANDA candles:', error);
      throw error;
    }
  }

  async createMarketOrder(
    instrument: string,
    units: number,
    stopLoss?: number,
    takeProfit?: number
  ) {
    if (!this.apiKey) {
      throw new Error('OANDA API key not configured');
    }

    const orderSpec = {
      order: {
        type: 'MARKET',
        instrument,
        units: units.toString(),
        timeInForce: 'FOK',
        positionFill: 'DEFAULT',
        ...(stopLoss && {
          stopLossOnFill: {
            price: stopLoss.toString()
          }
        }),
        ...(takeProfit && {
          takeProfitOnFill: {
            price: takeProfit.toString()
          }
        })
      }
    };

    try {
      const response = await fetch(
        `${this.baseUrl}/v3/accounts/${this.accountId}/orders`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(orderSpec)
        }
      );

      if (!response.ok) {
        throw new Error(`OANDA order error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Failed to create OANDA order:', error);
      throw error;
    }
  }

  convertOandaPriceToInternal(oandaPrice: OandaPrice) {
    const symbol = oandaPrice.instrument.replace('_', '/');
    const bid = parseFloat(oandaPrice.closeoutBid);
    const ask = parseFloat(oandaPrice.closeoutAsk);
    const price = (bid + ask) / 2;

    return {
      symbol,
      price,
      bid,
      ask,
      time: new Date(oandaPrice.time).getTime(),
      spread: ask - bid
    };
  }

  convertOandaCandleToInternal(oandaCandle: OandaCandle) {
    return {
      time: new Date(oandaCandle.time).getTime(),
      open: parseFloat(oandaCandle.mid.o),
      high: parseFloat(oandaCandle.mid.h),
      low: parseFloat(oandaCandle.mid.l),
      close: parseFloat(oandaCandle.mid.c),
      volume: oandaCandle.volume
    };
  }

  isConfigured(): boolean {
    return !!(this.apiKey && this.accountId);
  }
}

export const oandaService = new OandaService();