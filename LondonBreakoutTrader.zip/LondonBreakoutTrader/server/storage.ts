import { 
  currencyPairs, 
  trades, 
  botSettings, 
  alerts,
  type CurrencyPair, 
  type Trade, 
  type BotSettings, 
  type Alert,
  type InsertCurrencyPair,
  type InsertTrade,
  type InsertBotSettings,
  type InsertAlert
} from "@shared/schema";

export interface IStorage {
  // Currency Pairs
  getCurrencyPairs(): Promise<CurrencyPair[]>;
  getCurrencyPair(symbol: string): Promise<CurrencyPair | undefined>;
  updateCurrencyPair(symbol: string, data: Partial<InsertCurrencyPair>): Promise<CurrencyPair>;
  
  // Trades
  getTrades(): Promise<Trade[]>;
  getActiveTrades(): Promise<Trade[]>;
  getTradesBySymbol(symbol: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: number, data: Partial<InsertTrade>): Promise<Trade>;
  
  // Bot Settings
  getBotSettings(): Promise<BotSettings>;
  updateBotSettings(data: Partial<InsertBotSettings>): Promise<BotSettings>;
  
  // Alerts
  getAlerts(): Promise<Alert[]>;
  getUnreadAlerts(): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: number): Promise<Alert>;
}

export class MemStorage implements IStorage {
  private currencyPairsMap: Map<string, CurrencyPair>;
  private tradesMap: Map<number, Trade>;
  private botSettingsData: BotSettings;
  private alertsMap: Map<number, Alert>;
  private currentId: number;

  constructor() {
    this.currencyPairsMap = new Map();
    this.tradesMap = new Map();
    this.alertsMap = new Map();
    this.currentId = 1;

    // Initialize with default currency pairs
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    const defaultPairs: CurrencyPair[] = [
      {
        id: 1,
        symbol: "EUR/USD",
        name: "European Union / United States",
        currentPrice: "1.0847",
        change: "0.0012",
        changePercent: "0.11",
        overnightRangeLow: "1.0821",
        overnightRangeHigh: "1.0863",
        upperBreakout: "1.0865",
        lowerBreakout: "1.0819",
        isActive: true,
        updatedAt: new Date(),
      },
      {
        id: 2,
        symbol: "GBP/USD",
        name: "Great Britain / United States",
        currentPrice: "1.2634",
        change: "-0.0008",
        changePercent: "-0.06",
        overnightRangeLow: "1.2611",
        overnightRangeHigh: "1.2651",
        upperBreakout: "1.2653",
        lowerBreakout: "1.2609",
        isActive: true,
        updatedAt: new Date(),
      },
      {
        id: 3,
        symbol: "USD/JPY",
        name: "United States / Japan",
        currentPrice: "149.87",
        change: "0.23",
        changePercent: "0.15",
        overnightRangeLow: "149.45",
        overnightRangeHigh: "149.92",
        upperBreakout: "149.95",
        lowerBreakout: "149.42",
        isActive: true,
        updatedAt: new Date(),
      },
    ];

    defaultPairs.forEach(pair => {
      this.currencyPairsMap.set(pair.symbol, pair);
    });

    // Initialize bot settings
    this.botSettingsData = {
      id: 1,
      riskPercentage: "1.5",
      leverage: 10,
      maxTradesPerDay: 2,
      tradesUsedToday: 0,
      autoTradingEnabled: true,
      soundAlertsEnabled: true,
      emailNotificationsEnabled: false,
      accountBalance: "25000.00",
      updatedAt: new Date(),
    };

    // Add sample active trade
    const sampleTrade: Trade = {
      id: 1,
      symbol: "EUR/USD",
      type: "LONG",
      size: "0.025",
      entryPrice: "1.0829",
      exitPrice: null,
      stopLoss: "1.0814",
      takeProfit: "1.0859",
      pnl: "47.50",
      status: "OPEN",
      openedAt: new Date(Date.now() - 25 * 60 * 1000), // 25 minutes ago
      closedAt: null,
    };
    this.tradesMap.set(1, sampleTrade);

    // Add sample alerts
    const sampleAlerts: Alert[] = [
      {
        id: 1,
        type: "BREAKOUT",
        message: "EUR/USD approaching upper breakout zone (1.0865)",
        symbol: "EUR/USD",
        isRead: false,
        createdAt: new Date(Date.now() - 2 * 60 * 1000),
      },
      {
        id: 2,
        type: "POSITION_OPENED",
        message: "EUR/USD LONG at 1.0829",
        symbol: "EUR/USD",
        isRead: false,
        createdAt: new Date(Date.now() - 25 * 60 * 1000),
      },
      {
        id: 3,
        type: "SESSION_STARTED",
        message: "London session monitoring active",
        symbol: null,
        isRead: true,
        createdAt: new Date(Date.now() - 105 * 60 * 1000),
      },
    ];

    sampleAlerts.forEach(alert => {
      this.alertsMap.set(alert.id, alert);
    });

    this.currentId = 10;
  }

  async getCurrencyPairs(): Promise<CurrencyPair[]> {
    return Array.from(this.currencyPairsMap.values());
  }

  async getCurrencyPair(symbol: string): Promise<CurrencyPair | undefined> {
    return this.currencyPairsMap.get(symbol);
  }

  async updateCurrencyPair(symbol: string, data: Partial<InsertCurrencyPair>): Promise<CurrencyPair> {
    const existing = this.currencyPairsMap.get(symbol);
    if (!existing) {
      throw new Error(`Currency pair ${symbol} not found`);
    }

    const updated: CurrencyPair = {
      ...existing,
      ...data,
      updatedAt: new Date(),
    };

    this.currencyPairsMap.set(symbol, updated);
    return updated;
  }

  async getTrades(): Promise<Trade[]> {
    return Array.from(this.tradesMap.values()).sort((a, b) => 
      new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime()
    );
  }

  async getActiveTrades(): Promise<Trade[]> {
    return Array.from(this.tradesMap.values()).filter(trade => trade.status === "OPEN");
  }

  async getTradesBySymbol(symbol: string): Promise<Trade[]> {
    return Array.from(this.tradesMap.values()).filter(trade => trade.symbol === symbol);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = this.currentId++;
    const trade: Trade = {
      ...insertTrade,
      id,
      openedAt: new Date(),
      closedAt: null,
    };

    this.tradesMap.set(id, trade);
    
    // Update trades used today
    this.botSettingsData.tradesUsedToday += 1;
    
    return trade;
  }

  async updateTrade(id: number, data: Partial<InsertTrade>): Promise<Trade> {
    const existing = this.tradesMap.get(id);
    if (!existing) {
      throw new Error(`Trade ${id} not found`);
    }

    const updated: Trade = {
      ...existing,
      ...data,
    };

    if (data.status === "CLOSED" && !updated.closedAt) {
      updated.closedAt = new Date();
    }

    this.tradesMap.set(id, updated);
    return updated;
  }

  async getBotSettings(): Promise<BotSettings> {
    return this.botSettingsData;
  }

  async updateBotSettings(data: Partial<InsertBotSettings>): Promise<BotSettings> {
    this.botSettingsData = {
      ...this.botSettingsData,
      ...data,
      updatedAt: new Date(),
    };
    return this.botSettingsData;
  }

  async getAlerts(): Promise<Alert[]> {
    return Array.from(this.alertsMap.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getUnreadAlerts(): Promise<Alert[]> {
    return Array.from(this.alertsMap.values()).filter(alert => !alert.isRead);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentId++;
    const alert: Alert = {
      ...insertAlert,
      id,
      createdAt: new Date(),
    };

    this.alertsMap.set(id, alert);
    return alert;
  }

  async markAlertAsRead(id: number): Promise<Alert> {
    const existing = this.alertsMap.get(id);
    if (!existing) {
      throw new Error(`Alert ${id} not found`);
    }

    const updated: Alert = {
      ...existing,
      isRead: true,
    };

    this.alertsMap.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
