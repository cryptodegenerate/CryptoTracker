import TelegramBot from 'node-telegram-bot-api';

export class TelegramService {
  private bot: TelegramBot | null = null;
  private chatId: string | null = null;

  constructor() {
    // Clean the token by removing any "HTTP API:" prefix if present
    let token = process.env.TELEGRAM_BOT_TOKEN || "7871890240:AAENcoHCVanUMANwOjfJCCnNtBDA-QGREp8";
    if (token.startsWith("HTTP API:")) {
      token = token.replace("HTTP API:", "");
    }
    const chatId = process.env.TELEGRAM_CHAT_ID || "-1002734820754";

    if (token && chatId) {
      this.bot = new TelegramBot(token, { polling: false });
      this.chatId = chatId;
      console.log('Telegram service initialized with cleaned token and chat ID:', chatId);
    } else {
      console.log('Telegram credentials not found - notifications disabled');
    }
  }

  async sendAlert(type: string, message: string, symbol?: string) {
    if (!this.bot || !this.chatId) {
      console.log('Telegram not configured, skipping notification');
      return;
    }

    try {
      const emojis = {
        BREAKOUT: '🚨',
        POSITION_OPENED: '📈',
        POSITION_CLOSED: '📊',
        SESSION_STARTED: '🔔',
        PROFIT_TARGET: '💰',
        STOP_LOSS: '⚠️'
      };

      const emoji = emojis[type as keyof typeof emojis] || '📢';
      const symbolText = symbol ? ` (${symbol})` : '';
      
      const formattedMessage = `${emoji} *London Breakout Bot*${symbolText}\n\n${message}\n\n_${new Date().toLocaleString('en-GB', { timeZone: 'Europe/London' })} London Time_`;

      await this.bot.sendMessage(this.chatId, formattedMessage, {
        parse_mode: 'Markdown'
      });

      console.log(`Telegram alert sent: ${type} - ${message}`);
    } catch (error) {
      console.error('Failed to send Telegram message:', error);
    }
  }

  async sendTradeUpdate(trade: any, currentPrice: number, pnl: number) {
    if (!this.bot || !this.chatId) return;

    const emoji = pnl >= 0 ? '📈' : '📉';
    const pnlSymbol = pnl >= 0 ? '+' : '';
    
    const message = `${emoji} *Position Update*\n\n` +
      `Symbol: ${trade.symbol}\n` +
      `Type: ${trade.type}\n` +
      `Entry: ${trade.entryPrice}\n` +
      `Current: ${currentPrice.toFixed(trade.symbol === 'USD/JPY' ? 2 : 4)}\n` +
      `P&L: ${pnlSymbol}$${pnl.toFixed(2)}\n` +
      `Size: ${trade.size} lots`;

    try {
      await this.bot.sendMessage(this.chatId, message, {
        parse_mode: 'Markdown'
      });
    } catch (error) {
      console.error('Failed to send trade update:', error);
    }
  }

  async sendDailyReport(performance: any) {
    if (!this.bot || !this.chatId) return;

    const emoji = performance.todayPnL >= 0 ? '💰' : '📉';
    
    const message = `${emoji} *Daily Trading Report*\n\n` +
      `Today's P&L: ${performance.todayPnL >= 0 ? '+' : ''}$${performance.todayPnL.toFixed(2)}\n` +
      `Win Rate: ${performance.todayWinRate.toFixed(1)}%\n` +
      `Trades: ${performance.todayTrades}\n` +
      `Weekly P&L: ${performance.weeklyPnL >= 0 ? '+' : ''}$${performance.weeklyPnL.toFixed(2)}\n` +
      `Max Drawdown: ${performance.maxDrawdown.toFixed(1)}%`;

    try {
      await this.bot.sendMessage(this.chatId, message, {
        parse_mode: 'Markdown'
      });
    } catch (error) {
      console.error('Failed to send daily report:', error);
    }
  }
}

export const telegramService = new TelegramService();