import { SMA, EMA, RSI, MACD, BollingerBands } from 'technicalindicators';

export interface PriceData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface TechnicalSignals {
  sma20: number;
  sma50: number;
  ema12: number;
  ema26: number;
  rsi: number;
  macd: {
    MACD: number;
    signal: number;
    histogram: number;
  };
  bollingerBands: {
    upper: number;
    middle: number;
    lower: number;
  };
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  strength: number; // 0-100
  breakoutProbability: number; // 0-100
}

export class TechnicalAnalysisService {
  private priceHistory: Map<string, PriceData[]> = new Map();

  constructor() {
    // Initialize with some historical data for each pair
    this.initializeHistoricalData();
  }

  private initializeHistoricalData() {
    const pairs = ['EUR/USD', 'GBP/USD', 'USD/JPY'];
    const now = Date.now();
    const intervals = 288; // 24 hours of 5-minute data

    pairs.forEach(symbol => {
      const data: PriceData[] = [];
      let basePrice = symbol === 'USD/JPY' ? 149.50 : symbol === 'GBP/USD' ? 1.2620 : 1.0835;

      for (let i = intervals; i >= 0; i--) {
        const time = now - (i * 5 * 60 * 1000); // 5-minute intervals
        const variation = (Math.random() - 0.5) * 0.002;
        const open = basePrice;
        const close = basePrice + variation;
        const high = Math.max(open, close) + Math.random() * 0.0005;
        const low = Math.min(open, close) - Math.random() * 0.0005;

        data.push({
          time,
          open,
          high,
          low,
          close,
          volume: Math.floor(Math.random() * 1000) + 100
        });

        basePrice = close;
      }

      this.priceHistory.set(symbol, data);
    });
  }

  addPriceData(symbol: string, price: number) {
    let history = this.priceHistory.get(symbol) || [];
    const now = Date.now();
    const lastCandle = history[history.length - 1];

    // Create new 5-minute candle or update existing one
    if (!lastCandle || now - lastCandle.time > 5 * 60 * 1000) {
      // New candle
      history.push({
        time: now,
        open: price,
        high: price,
        low: price,
        close: price,
        volume: Math.floor(Math.random() * 1000) + 100
      });
    } else {
      // Update existing candle
      lastCandle.high = Math.max(lastCandle.high, price);
      lastCandle.low = Math.min(lastCandle.low, price);
      lastCandle.close = price;
    }

    // Keep only last 288 candles (24 hours)
    if (history.length > 288) {
      history = history.slice(-288);
    }

    this.priceHistory.set(symbol, history);
  }

  calculateTechnicalSignals(symbol: string): TechnicalSignals | null {
    const history = this.priceHistory.get(symbol);
    if (!history || history.length < 50) return null;

    const closes = history.map(h => h.close);
    const highs = history.map(h => h.high);
    const lows = history.map(h => h.low);

    try {
      // Simple Moving Averages
      const sma20Array = SMA.calculate({ period: 20, values: closes });
      const sma50Array = SMA.calculate({ period: 50, values: closes });
      const sma20 = sma20Array[sma20Array.length - 1] || closes[closes.length - 1];
      const sma50 = sma50Array[sma50Array.length - 1] || closes[closes.length - 1];

      // Exponential Moving Averages
      const ema12Array = EMA.calculate({ period: 12, values: closes });
      const ema26Array = EMA.calculate({ period: 26, values: closes });
      const ema12 = ema12Array[ema12Array.length - 1] || closes[closes.length - 1];
      const ema26 = ema26Array[ema26Array.length - 1] || closes[closes.length - 1];

      // RSI
      const rsiArray = RSI.calculate({ period: 14, values: closes });
      const rsi = rsiArray[rsiArray.length - 1] || 50;

      // Simple MACD calculation
      const ema12Recent = ema12Array.slice(-5);
      const ema26Recent = ema26Array.slice(-5);
      const macdValue = ema12Recent[ema12Recent.length - 1] - ema26Recent[ema26Recent.length - 1];
      const macdSignal = ema12Recent.reduce((a, b) => a + b, 0) / ema12Recent.length - 
                        ema26Recent.reduce((a, b) => a + b, 0) / ema26Recent.length;
      const macd = {
        MACD: macdValue,
        signal: macdSignal,
        histogram: macdValue - macdSignal
      };

      // Bollinger Bands
      const bbArray = BollingerBands.calculate({
        period: 20,
        stdDev: 2,
        values: closes
      });
      const bollingerBands = bbArray[bbArray.length - 1] || {
        upper: closes[closes.length - 1] * 1.002,
        middle: closes[closes.length - 1],
        lower: closes[closes.length - 1] * 0.998
      };

      // Determine trend
      const currentPrice = closes[closes.length - 1];
      let trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
      
      if (currentPrice > sma20 && sma20 > sma50 && ema12 > ema26) {
        trend = 'BULLISH';
      } else if (currentPrice < sma20 && sma20 < sma50 && ema12 < ema26) {
        trend = 'BEARISH';
      }

      // Calculate strength (0-100)
      const priceVsSMA = Math.abs((currentPrice - sma20) / sma20) * 10000;
      const rsiStrength = Math.abs(rsi - 50) / 50;
      const strength = Math.min(100, (priceVsSMA + rsiStrength * 50));

      // Calculate breakout probability
      const volatility = (bollingerBands.upper - bollingerBands.lower) / bollingerBands.middle;
      const pricePosition = (currentPrice - bollingerBands.lower) / (bollingerBands.upper - bollingerBands.lower);
      const breakoutProbability = Math.min(100, 
        (Math.abs(pricePosition - 0.5) * 2) * 100 + volatility * 500
      );

      return {
        sma20,
        sma50,
        ema12,
        ema26,
        rsi,
        macd,
        bollingerBands,
        trend,
        strength,
        breakoutProbability
      };
    } catch (error) {
      console.error('Error calculating technical indicators:', error);
      return null;
    }
  }

  detectBreakoutSignal(symbol: string, currentPrice: number, upperBreakout: number, lowerBreakout: number): {
    isBreakout: boolean;
    direction: 'UP' | 'DOWN' | null;
    confidence: number;
  } {
    const signals = this.calculateTechnicalSignals(symbol);
    if (!signals) {
      return { isBreakout: false, direction: null, confidence: 0 };
    }

    const isAboveUpperBreakout = currentPrice > upperBreakout;
    const isBelowLowerBreakout = currentPrice < lowerBreakout;
    
    if (isAboveUpperBreakout) {
      const confidence = Math.min(100, 
        signals.breakoutProbability + 
        (signals.trend === 'BULLISH' ? 20 : 0) +
        (signals.rsi > 60 ? 15 : 0) +
        (signals.macd.MACD > signals.macd.signal ? 15 : 0)
      );
      
      return {
        isBreakout: confidence > 60,
        direction: 'UP',
        confidence
      };
    }
    
    if (isBelowLowerBreakout) {
      const confidence = Math.min(100,
        signals.breakoutProbability +
        (signals.trend === 'BEARISH' ? 20 : 0) +
        (signals.rsi < 40 ? 15 : 0) +
        (signals.macd.MACD < signals.macd.signal ? 15 : 0)
      );
      
      return {
        isBreakout: confidence > 60,
        direction: 'DOWN',
        confidence
      };
    }

    return { isBreakout: false, direction: null, confidence: 0 };
  }

  getPriceHistory(symbol: string, count: number = 50): PriceData[] {
    const history = this.priceHistory.get(symbol) || [];
    return history.slice(-count);
  }
}

export const technicalAnalysis = new TechnicalAnalysisService();