import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTradeSchema, insertBotSettingsSchema } from "@shared/schema";
import { telegramService } from "./telegram-service";
import { technicalAnalysis } from "./technical-indicators";
import { backtestingService } from "./backtesting-service";
import { marketDataService } from "./market-data-service";
import { oandaService } from "./oanda-service";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all currency pairs
  app.get("/api/currency-pairs", async (req, res) => {
    try {
      const pairs = await storage.getCurrencyPairs();
      res.json(pairs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch currency pairs" });
    }
  });

  // Get specific currency pair
  app.get("/api/currency-pairs/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const pair = await storage.getCurrencyPair(decodeURIComponent(symbol));
      if (!pair) {
        return res.status(404).json({ message: "Currency pair not found" });
      }
      res.json(pair);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch currency pair" });
    }
  });

  // Update currency pair prices (for price simulation)
  app.patch("/api/currency-pairs/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const updateData = req.body;
      const updated = await storage.updateCurrencyPair(decodeURIComponent(symbol), updateData);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update currency pair" });
    }
  });

  // Get all trades
  app.get("/api/trades", async (req, res) => {
    try {
      const trades = await storage.getTrades();
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trades" });
    }
  });

  // Get active trades
  app.get("/api/trades/active", async (req, res) => {
    try {
      const trades = await storage.getActiveTrades();
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active trades" });
    }
  });

  // Create new trade
  app.post("/api/trades", async (req, res) => {
    try {
      const validatedData = insertTradeSchema.parse(req.body);
      const trade = await storage.createTrade(validatedData);
      
      // Create alert for new position
      await storage.createAlert({
        type: "POSITION_OPENED",
        message: `${trade.symbol} ${trade.type} at ${trade.entryPrice}`,
        symbol: trade.symbol,
        isRead: false,
      });

      // Send Telegram notification
      await telegramService.sendAlert(
        "POSITION_OPENED",
        `${trade.symbol} ${trade.type} position opened at ${trade.entryPrice}\nSize: ${trade.size} lots\nStop Loss: ${trade.stopLoss}\nTake Profit: ${trade.takeProfit}`,
        trade.symbol
      );
      
      res.json(trade);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid trade data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create trade" });
    }
  });

  // Update trade (e.g., close position)
  app.patch("/api/trades/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      const trade = await storage.updateTrade(id, updateData);
      res.json(trade);
    } catch (error) {
      res.status(500).json({ message: "Failed to update trade" });
    }
  });

  // Get bot settings
  app.get("/api/bot-settings", async (req, res) => {
    try {
      const settings = await storage.getBotSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bot settings" });
    }
  });

  // Update bot settings
  app.patch("/api/bot-settings", async (req, res) => {
    try {
      const updateData = req.body;
      const settings = await storage.updateBotSettings(updateData);
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to update bot settings" });
    }
  });

  // Get alerts
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  // Get unread alerts
  app.get("/api/alerts/unread", async (req, res) => {
    try {
      const alerts = await storage.getUnreadAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unread alerts" });
    }
  });

  // Mark alert as read
  app.patch("/api/alerts/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const alert = await storage.markAlertAsRead(id);
      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });

  // Trading action endpoints
  app.post("/api/trading/close-position/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trade = await storage.updateTrade(id, { 
        status: "CLOSED",
        exitPrice: req.body.exitPrice,
        pnl: req.body.pnl
      });
      res.json(trade);
    } catch (error) {
      res.status(500).json({ message: "Failed to close position" });
    }
  });

  app.post("/api/trading/close-all-positions", async (req, res) => {
    try {
      const activeTrades = await storage.getActiveTrades();
      const closedTrades = [];
      
      for (const trade of activeTrades) {
        const closed = await storage.updateTrade(trade.id, { 
          status: "CLOSED"
        });
        closedTrades.push(closed);
      }
      
      res.json(closedTrades);
    } catch (error) {
      res.status(500).json({ message: "Failed to close all positions" });
    }
  });

  // Market data update endpoint (supports both simulation and live data)
  app.post("/api/simulate-prices", async (req, res) => {
    try {
      const prices = await marketDataService.updatePricesAndCheckBreakouts();
      const updates = [];
      
      // Convert prices to the expected format for frontend
      for (const priceData of prices) {
        const pair = await storage.getCurrencyPair(priceData.symbol);
        if (pair) {
          updates.push(pair);
        }
      }
      
      res.json(updates);
    } catch (error) {
      res.status(500).json({ message: "Failed to update market data" });
    }
  });

  // Technical Analysis endpoints
  app.get("/api/technical-analysis/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const signals = technicalAnalysis.calculateTechnicalSignals(decodeURIComponent(symbol));
      if (!signals) {
        return res.status(404).json({ message: "Technical analysis data not available" });
      }
      res.json(signals);
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate technical analysis" });
    }
  });

  app.get("/api/price-history/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const count = parseInt(req.query.count as string) || 50;
      const history = technicalAnalysis.getPriceHistory(decodeURIComponent(symbol), count);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to get price history" });
    }
  });

  // Backtesting endpoints
  app.post("/api/backtest/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const settings = req.body;
      const result = await backtestingService.runBacktest(decodeURIComponent(symbol), settings);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to run backtest" });
    }
  });

  // Automated trading endpoints
  app.post("/api/auto-trade/start", async (req, res) => {
    try {
      await storage.updateBotSettings({ autoTradingEnabled: true });
      
      await telegramService.sendAlert(
        "SESSION_STARTED",
        "🤖 Automated trading has been enabled! The bot will now monitor for breakout opportunities during London session.",
        undefined
      );
      
      res.json({ message: "Auto-trading started" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start auto-trading" });
    }
  });

  app.post("/api/auto-trade/stop", async (req, res) => {
    try {
      await storage.updateBotSettings({ autoTradingEnabled: false });
      
      await telegramService.sendAlert(
        "SESSION_STARTED",
        "⏸️ Automated trading has been disabled. Manual trading mode is now active.",
        undefined
      );
      
      res.json({ message: "Auto-trading stopped" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop auto-trading" });
    }
  });

  // Telegram notification test endpoint
  app.post("/api/test-telegram", async (req, res) => {
    try {
      await telegramService.sendAlert(
        "SESSION_STARTED",
        "🧪 Test notification from London Breakout Bot. All systems operational!",
        undefined
      );
      res.json({ message: "Test notification sent" });
    } catch (error) {
      res.status(500).json({ message: "Failed to send test notification" });
    }
  });

  // Daily performance report
  app.post("/api/daily-report", async (req, res) => {
    try {
      const trades = await storage.getTrades();
      // Calculate performance metrics (simplified)
      const todayTrades = trades.filter(trade => {
        const today = new Date().toDateString();
        return new Date(trade.openedAt).toDateString() === today;
      });
      
      const performance = {
        todayPnL: todayTrades.reduce((sum, trade) => sum + parseFloat(trade.pnl || '0'), 0),
        todayWinRate: todayTrades.filter(t => parseFloat(t.pnl || '0') > 0).length / Math.max(todayTrades.length, 1) * 100,
        todayTrades: todayTrades.length,
        weeklyPnL: trades.reduce((sum, trade) => sum + parseFloat(trade.pnl || '0'), 0),
        weeklyWinRate: trades.filter(t => parseFloat(t.pnl || '0') > 0).length / Math.max(trades.length, 1) * 100,
        maxDrawdown: 2.1 // Mock value
      };
      
      await telegramService.sendDailyReport(performance);
      res.json({ message: "Daily report sent" });
    } catch (error) {
      res.status(500).json({ message: "Failed to send daily report" });
    }
  });

  // OANDA Integration endpoints
  app.get("/api/market-data-source", async (req, res) => {
    try {
      res.json({
        source: marketDataService.getDataSource(),
        isLive: marketDataService.isUsingRealData(),
        oandaConfigured: oandaService.isConfigured()
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get market data source info" });
    }
  });

  app.get("/api/oanda/prices", async (req, res) => {
    try {
      if (!oandaService.isConfigured()) {
        return res.status(400).json({ message: "OANDA not configured" });
      }
      
      const prices = await oandaService.getCurrentPrices();
      const formattedPrices = prices.map(price => oandaService.convertOandaPriceToInternal(price));
      res.json(formattedPrices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch OANDA prices" });
    }
  });

  app.get("/api/oanda/candles/:instrument", async (req, res) => {
    try {
      if (!oandaService.isConfigured()) {
        return res.status(400).json({ message: "OANDA not configured" });
      }
      
      const { instrument } = req.params;
      const granularity = req.query.granularity as string || 'M1';
      const count = parseInt(req.query.count as string) || 100;
      
      const candles = await oandaService.getHistoricalCandles(instrument, granularity, count);
      const formattedCandles = candles.map(candle => oandaService.convertOandaCandleToInternal(candle));
      res.json(formattedCandles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch OANDA candles" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
