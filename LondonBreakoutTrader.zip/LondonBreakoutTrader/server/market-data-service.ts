import { oandaService } from './oanda-service.js';
import { technicalAnalysis } from './technical-indicators.js';
import { telegramService } from './telegram-service.js';
import { storage } from './storage.js';

export interface MarketPrice {
  symbol: string;
  price: number;
  bid?: number;
  ask?: number;
  time: number;
  spread?: number;
}

export class MarketDataService {
  private useRealData: boolean;
  private lastAlertTime: Map<string, number> = new Map();
  private alertCooldown = 60000; // 1 minute cooldown between alerts

  constructor() {
    this.useRealData = oandaService.isConfigured();
    console.log(`Market data service initialized - ${this.useRealData ? 'OANDA Live Data' : 'Simulation Mode'}`);
  }

  async getCurrentPrices(): Promise<MarketPrice[]> {
    if (this.useRealData) {
      return this.getOandaPrices();
    } else {
      return this.getSimulatedPrices();
    }
  }

  private async getOandaPrices(): Promise<MarketPrice[]> {
    try {
      const oandaPrices = await oandaService.getCurrentPrices(['EUR_USD', 'GBP_USD', 'USD_JPY']);
      
      return oandaPrices.map(price => ({
        symbol: price.instrument.replace('_', '/'),
        price: (parseFloat(price.closeoutBid) + parseFloat(price.closeoutAsk)) / 2,
        bid: parseFloat(price.closeoutBid),
        ask: parseFloat(price.closeoutAsk),
        time: new Date(price.time).getTime(),
        spread: parseFloat(price.closeoutAsk) - parseFloat(price.closeoutBid)
      }));
    } catch (error) {
      // Silently fall back to simulation - OANDA credentials need verification
      return this.getSimulatedPrices();
    }
  }

  private async getSimulatedPrices(): Promise<MarketPrice[]> {
    const pairs = await storage.getCurrencyPairs();
    const now = Date.now();
    
    return pairs.map(pair => {
      // Simulate realistic price movements
      const basePrice = parseFloat(pair.currentPrice);
      const volatility = pair.symbol === 'USD/JPY' ? 0.5 : 0.0003;
      const randomChange = (Math.random() - 0.5) * volatility;
      const newPrice = basePrice + randomChange;
      
      // Add realistic spread
      const spread = pair.symbol === 'USD/JPY' ? 0.02 : 0.00015;
      const bid = newPrice - spread / 2;
      const ask = newPrice + spread / 2;

      return {
        symbol: pair.symbol,
        price: newPrice,
        bid,
        ask,
        time: now,
        spread
      };
    });
  }

  async updatePricesAndCheckBreakouts(): Promise<MarketPrice[]> {
    const prices = await this.getCurrentPrices();
    
    // Update database with new prices
    for (const priceData of prices) {
      await storage.updateCurrencyPair(priceData.symbol, {
        currentPrice: priceData.price.toString(),
        updatedAt: new Date()
      });

      // Add to technical analysis
      technicalAnalysis.addPriceData(priceData.symbol, priceData.price);

      // Check for breakouts with cooldown
      await this.checkBreakoutWithCooldown(priceData);
    }

    return prices;
  }

  private async checkBreakoutWithCooldown(priceData: MarketPrice) {
    const pair = await storage.getCurrencyPair(priceData.symbol);
    if (!pair) return;

    const upperBreakout = parseFloat(pair.upperBreakout);
    const lowerBreakout = parseFloat(pair.lowerBreakout);
    const lastAlertKey = priceData.symbol;
    const lastAlert = this.lastAlertTime.get(lastAlertKey) || 0;
    const now = Date.now();

    // Check cooldown
    if (now - lastAlert < this.alertCooldown) {
      return;
    }

    const breakoutSignal = technicalAnalysis.detectBreakoutSignal(
      priceData.symbol,
      priceData.price,
      upperBreakout,
      lowerBreakout
    );

    if (breakoutSignal.isBreakout) {
      // Update cooldown
      this.lastAlertTime.set(lastAlertKey, now);

      // Create alert in database
      await storage.createAlert({
        type: 'BREAKOUT',
        message: `${priceData.symbol} ${breakoutSignal.direction} breakout detected! Price: ${priceData.price.toFixed(priceData.symbol === 'USD/JPY' ? 2 : 4)} (Confidence: ${breakoutSignal.confidence.toFixed(1)}%)`,
        isRead: false,
        createdAt: new Date()
      });

      // Send Telegram notification with rate limiting protection
      try {
        await telegramService.sendAlert(
          'BREAKOUT',
          `${priceData.symbol} ${breakoutSignal.direction} breakout detected! Price: ${priceData.price.toFixed(priceData.symbol === 'USD/JPY' ? 2 : 4)} (Confidence: ${breakoutSignal.confidence.toFixed(1)}%)`,
          priceData.symbol
        );
      } catch (error) {
        console.error('Failed to send Telegram alert:', error);
      }
    }
  }

  async getHistoricalData(symbol: string, count: number = 100) {
    if (this.useRealData) {
      try {
        const oandaSymbol = symbol.replace('/', '_');
        const candles = await oandaService.getHistoricalCandles(oandaSymbol, 'M1', count);
        return candles.map(candle => oandaService.convertOandaCandleToInternal(candle));
      } catch (error) {
        console.error('Failed to fetch OANDA historical data:', error);
        return technicalAnalysis.getPriceHistory(symbol, count);
      }
    } else {
      return technicalAnalysis.getPriceHistory(symbol, count);
    }
  }

  isUsingRealData(): boolean {
    return this.useRealData;
  }

  getDataSource(): string {
    return this.useRealData ? 'OANDA Live' : 'Simulation';
  }
}

export const marketDataService = new MarketDataService();